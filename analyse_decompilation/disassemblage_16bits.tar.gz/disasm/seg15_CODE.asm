; ================================================================
; seg15_CODE  (21603 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	0f 00 52 0c          	lldt   WORD PTR [bp+si+0xc]
       4:	fb                   	sti
       5:	02 b1 00 00          	add    dh,BYTE PTR [bx+di+0x0]
       9:	00 9e 00 cd          	add    BYTE PTR [bp-0x3300],bl
       d:	04 fb                	add    al,0xfb
       f:	04 6c                	add    al,0x6c
      11:	0c 39                	or     al,0x39
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 7f 0c cb       	call   0xcb0c:0x7f1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 4c 1d             	adc    BYTE PTR [si+0x1d],cl
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 16                	sbb    al,0x16
      61:	0d e2 2f             	or     ax,0x2fe2
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	41                   	inc    cx
      a6:	52                   	push   dx
      a7:	47                   	inc    di
      a8:	5f                   	pop    di
      a9:	47                   	inc    di
      aa:	65 6e                	outs   dx,BYTE PTR gs:[si]
      ac:	65 72 61             	gs jb  0x110
      af:	75 78                	jne    0x129
      b1:	1e                   	push   ds
      b2:	00 4b 12             	add    BYTE PTR [bp+di+0x12],cl
      b5:	c8 00 0e 49          	enter  0xe00,0x49
      b9:	6d                   	ins    WORD PTR es:[di],dx
      ba:	70 72                	jo     0x12e
      bc:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      c1:	43                   	inc    bx
      c2:	6c                   	ins    BYTE PTR es:[di],dx
      c3:	69 63 6b f2 2a       	imul   sp,WORD PTR [bp+di+0x6b],0x2af2
      c8:	da 00                	fiadd  DWORD PTR [bx+si]
      ca:	0d 51 75             	or     ax,0x7551
      cd:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
      d2:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      d5:	69 63 6b 0a 2b       	imul   sp,WORD PTR [bp+di+0x6b],0x2b0a
      da:	f1                   	int1
      db:	00 12                	add    BYTE PTR [bp+si],dl
      dd:	42                   	inc    dx
      de:	61                   	popa
      df:	72 72                	jb     0x153
      e1:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
      e4:	75 74                	jne    0x15a
      e6:	69 6c 73 31 43       	imul   bp,WORD PTR [si+0x73],0x4331
      eb:	6c                   	ins    BYTE PTR es:[di],dx
      ec:	69 63 6b 45 4e       	imul   sp,WORD PTR [bp+di+0x6b],0x4e45
      f1:	01 01                	add    WORD PTR [bx+di],ax
      f3:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
      f6:	64 65 78 31          	fs gs js 0x12b
      fa:	43                   	inc    bx
      fb:	6c                   	ins    BYTE PTR es:[di],dx
      fc:	69 63 6b 64 4e       	imul   sp,WORD PTR [bp+di+0x6b],0x4e64
     101:	16                   	push   ss
     102:	01 10                	add    WORD PTR [bx+si],dx
     104:	52                   	push   dx
     105:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     109:	72 63                	jb     0x16e
     10b:	68 65 72             	push   0x7265
     10e:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     111:	69 63 6b 1f 2b       	imul   sp,WORD PTR [bp+di+0x6b],0x2b1f
     116:	2b 01                	sub    ax,WORD PTR [bx+di]
     118:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
     11b:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     121:	61                   	popa
     122:	6e                   	outs   dx,BYTE PTR ds:[si]
     123:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     126:	69 63 6b 85 4e       	imul   sp,WORD PTR [bp+di+0x6b],0x4e85
     12b:	43                   	inc    bx
     12c:	01 13                	add    WORD PTR [bp+di],dx
     12e:	55                   	push   bp
     12f:	74 69                	je     0x19a
     131:	6c                   	ins    BYTE PTR es:[di],dx
     132:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     137:	61                   	popa
     138:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     13d:	6c                   	ins    BYTE PTR es:[di],dx
     13e:	69 63 6b a4 4e       	imul   sp,WORD PTR [bp+di+0x6b],0x4ea4
     143:	55                   	push   bp
     144:	01 0d                	add    WORD PTR [di],cx
     146:	41                   	inc    cx
     147:	70 72                	jo     0x1bb
     149:	6f                   	outs   dx,WORD PTR ds:[si]
     14a:	70 6f                	jo     0x1bb
     14c:	73 31                	jae    0x17f
     14e:	43                   	inc    bx
     14f:	6c                   	ins    BYTE PTR es:[di],dx
     150:	69 63 6b f2 12       	imul   sp,WORD PTR [bp+di+0x6b],0x12f2
     155:	63 01                	arpl   WORD PTR [bx+di],ax
     157:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
     15a:	72 6d                	jb     0x1c9
     15c:	43                   	inc    bx
     15d:	6c                   	ins    BYTE PTR es:[di],dx
     15e:	6f                   	outs   dx,WORD PTR ds:[si]
     15f:	73 65                	jae    0x1c6
     161:	6d                   	ins    WORD PTR es:[di],dx
     162:	13 72 01             	adc    si,WORD PTR [bp+si+0x1]
     165:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     168:	72 6d                	jb     0x1d7
     16a:	43                   	inc    bx
     16b:	72 65                	jb     0x1d2
     16d:	61                   	popa
     16e:	74 65                	je     0x1d5
     170:	20 16 81 01          	and    BYTE PTR ds:0x181,dl
     174:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     177:	72 6d                	jb     0x1e6
     179:	52                   	push   dx
     17a:	65 73 69             	gs jae 0x1e6
     17d:	7a 65                	jp     0x1e4
     17f:	22 40 98             	and    al,BYTE PTR [bx+si-0x68]
     182:	01 12                	add    WORD PTR [bp+si],dx
     184:	54                   	push   sp
     185:	61                   	popa
     186:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     189:	45                   	inc    bp
     18a:	52                   	push   dx
     18b:	47                   	inc    di
     18c:	43                   	inc    bx
     18d:	61                   	popa
     18e:	6c                   	ins    BYTE PTR es:[di],dx
     18f:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     192:	65 6c                	gs ins BYTE PTR es:[di],dx
     194:	64 73 87             	fs jae 0x11e
     197:	2e aa                	cs stos BYTE PTR es:[di],al
     199:	01 0d                	add    WORD PTR [di],cx
     19b:	50                   	push   ax
     19c:	65 72 69             	gs jb  0x208
     19f:	6f                   	outs   dx,WORD PTR ds:[si]
     1a0:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     1a5:	69 63 6b 07 13       	imul   sp,WORD PTR [bp+di+0x6b],0x1307
     1aa:	b7 01                	mov    bh,0x1
     1ac:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
     1af:	72 6d                	jb     0x21e
     1b1:	53                   	push   bx
     1b2:	68 6f 77             	push   0x776f
     1b5:	85 4d c7             	test   WORD PTR [di-0x39],cx
     1b8:	01 0b                	add    WORD PTR [bp+di],cx
     1ba:	46                   	inc    si
     1bb:	6f                   	outs   dx,WORD PTR ds:[si]
     1bc:	72 6d                	jb     0x22b
     1be:	4b                   	dec    bx
     1bf:	65 79 44             	gs jns 0x206
     1c2:	6f                   	outs   dx,WORD PTR ds:[si]
     1c3:	77 6e                	ja     0x233
     1c5:	1a 4e d7             	sbb    cl,BYTE PTR [bp-0x29]
     1c8:	01 0b                	add    WORD PTR [bp+di],cx
     1ca:	46                   	inc    si
     1cb:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     1d0:	43                   	inc    bx
     1d1:	6c                   	ins    BYTE PTR es:[di],dx
     1d2:	69 63 6b 82 35       	imul   sp,WORD PTR [bp+di+0x6b],0x3582
     1d7:	e8 01 0c             	call   0xddb
     1da:	43                   	inc    bx
     1db:	6f                   	outs   dx,WORD PTR ds:[si]
     1dc:	70 69                	jo     0x247
     1de:	65 72 31             	gs jb  0x212
     1e1:	43                   	inc    bx
     1e2:	6c                   	ins    BYTE PTR es:[di],dx
     1e3:	69 63 6b 63 2b       	imul   sp,WORD PTR [bp+di+0x6b],0x2b63
     1e8:	f7 01 0a 4e          	test   WORD PTR [bx+di],0x4e0a
     1ec:	31 30                	xor    WORD PTR [bx+si],si
     1ee:	30 31                	xor    BYTE PTR [bx+di],dh
     1f0:	43                   	inc    bx
     1f1:	6c                   	ins    BYTE PTR es:[di],dx
     1f2:	69 63 6b c4 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2fc4
     1f7:	12 02                	adc    al,BYTE PTR [bp+si]
     1f9:	16                   	push   ss
     1fa:	49                   	dec    cx
     1fb:	6d                   	ins    WORD PTR es:[di],dx
     1fc:	70 72                	jo     0x270
     1fe:	65 73 73             	gs jae 0x274
     201:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     206:	70 69                	jo     0x271
     208:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     20d:	69 63 6b ed 4f       	imul   sp,WORD PTR [bp+di+0x6b],0x4fed
     212:	31 02                	xor    WORD PTR [bp+si],ax
     214:	1a 52 65             	sbb    dl,BYTE PTR [bp+si+0x65]
     217:	73 75                	jae    0x28e
     219:	6c                   	ins    BYTE PTR es:[di],dx
     21a:	74 61                	je     0x27d
     21c:	74 73                	je     0x291
     21e:	50                   	push   ax
     21f:	61                   	popa
     220:	72 50                	jb     0x272
     222:	72 6f                	jb     0x293
     224:	64 75 69             	fs jne 0x290
     227:	74 73                	je     0x29c
     229:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     22c:	69 63 6b 18 50       	imul   sp,WORD PTR [bp+di+0x6b],0x5018
     231:	4d                   	dec    bp
     232:	02 17                	add    dl,BYTE PTR [bx]
     234:	52                   	push   dx
     235:	65 73 75             	gs jae 0x2ad
     238:	6c                   	ins    BYTE PTR es:[di],dx
     239:	74 61                	je     0x29c
     23b:	74 73                	je     0x2b0
     23d:	47                   	inc    di
     23e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     240:	65 72 61             	gs jb  0x2a4
     243:	75 78                	jne    0x2bd
     245:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     248:	69 63 6b 43 50       	imul   sp,WORD PTR [bp+di+0x6b],0x5043
     24d:	61                   	popa
     24e:	02 0f                	add    cl,BYTE PTR [bx]
     250:	41                   	inc    cx
     251:	6e                   	outs   dx,BYTE PTR ds:[si]
     252:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     257:	75 72                	jne    0x2cb
     259:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     25c:	69 63 6b 5e 50       	imul   sp,WORD PTR [bp+di+0x6b],0x505e
     261:	77 02                	ja     0x265
     263:	11 45 6e             	adc    WORD PTR [di+0x6e],ax
     266:	74 72                	je     0x2da
     268:	65 70 72             	gs jo  0x2dd
     26b:	69 73 65 73 31       	imul   si,WORD PTR [bp+di+0x65],0x3173
     270:	43                   	inc    bx
     271:	6c                   	ins    BYTE PTR es:[di],dx
     272:	69 63 6b 7d 50       	imul   sp,WORD PTR [bp+di+0x6b],0x507d
     277:	8a 02                	mov    al,BYTE PTR [bp+si]
     279:	0e                   	push   cs
     27a:	43                   	inc    bx
     27b:	72 65                	jb     0x2e2
     27d:	61                   	popa
     27e:	74 69                	je     0x2e9
     280:	6f                   	outs   dx,WORD PTR ds:[si]
     281:	6e                   	outs   dx,BYTE PTR ds:[si]
     282:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     285:	69 63 6b b0 50       	imul   sp,WORD PTR [bp+di+0x6b],0x50b0
     28a:	9a 02 0b 43 6f       	call   0x6f43:0xb02
     28f:	75 72                	jne    0x303
     291:	74 31                	je     0x2c4
     293:	43                   	inc    bx
     294:	6c                   	ins    BYTE PTR es:[di],dx
     295:	69 63 6b 51 53       	imul   sp,WORD PTR [bp+di+0x6b],0x5351
     29a:	ad                   	lods   ax,WORD PTR ds:[si]
     29b:	02 0e 45 67          	add    cl,BYTE PTR ds:0x6745
     29f:	61                   	popa
     2a0:	6c                   	ins    BYTE PTR es:[di],dx
     2a1:	69 73 65 72 31       	imul   si,WORD PTR [bp+di+0x65],0x3172
     2a6:	43                   	inc    bx
     2a7:	6c                   	ins    BYTE PTR es:[di],dx
     2a8:	69 63 6b 21 4f       	imul   sp,WORD PTR [bp+di+0x6b],0x4f21
     2ad:	cd 02                	int    0x2
     2af:	1b 53 70             	sbb    dx,WORD PTR [bp+di+0x70]
     2b2:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     2b6:	6c                   	ins    BYTE PTR es:[di],dx
     2b7:	53                   	push   bx
     2b8:	74 72                	je     0x32c
     2ba:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     2bf:	69 64 31 4d 6f       	imul   sp,WORD PTR [si+0x31],0x6f4d
     2c4:	75 73                	jne    0x339
     2c6:	65 44                	gs inc sp
     2c8:	6f                   	outs   dx,WORD PTR ds:[si]
     2c9:	77 6e                	ja     0x339
     2cb:	59                   	pop    cx
     2cc:	16                   	push   ss
     2cd:	de 02                	fiadd  WORD PTR [bp+si]
     2cf:	0c 50                	or     al,0x50
     2d1:	61                   	popa
     2d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     2d3:	65 6c                	gs ins BYTE PTR es:[di],dx
     2d5:	30 52 65             	xor    BYTE PTR [bp+si+0x65],dl
     2d8:	73 69                	jae    0x343
     2da:	7a 65                	jp     0x341
     2dc:	77 16                	ja     0x2f4
     2de:	f0 02 0d             	lock add cl,BYTE PTR [di]
     2e1:	50                   	push   ax
     2e2:	61                   	popa
     2e3:	6e                   	outs   dx,BYTE PTR ds:[si]
     2e4:	65 6c                	gs ins BYTE PTR es:[di],dx
     2e6:	30 31                	xor    BYTE PTR [bx+di],dh
     2e8:	52                   	push   dx
     2e9:	65 73 69             	gs jae 0x355
     2ec:	7a 65                	jp     0x353
     2ee:	ce                   	into
     2ef:	2e 68 0c 08          	cs push 0x80c
     2f3:	4e                   	dec    si
     2f4:	31 31                	xor    WORD PTR [bx+di],si
     2f6:	43                   	inc    bx
     2f7:	6c                   	ins    BYTE PTR es:[di],dx
     2f8:	69 63 6b 92 00       	imul   sp,WORD PTR [bp+di+0x6b],0x92
     2fd:	1c 0c                	sbb    al,0xc
     2ff:	7c 01                	jl     0x302
     301:	00 00                	add    BYTE PTR [bx+si],al
     303:	06                   	push   es
     304:	50                   	push   ax
     305:	61                   	popa
     306:	6e                   	outs   dx,BYTE PTR ds:[si]
     307:	65 6c                	gs ins BYTE PTR es:[di],dx
     309:	30 80 01 04          	xor    BYTE PTR [bx+si+0x401],al
     30d:	00 09                	add    BYTE PTR [bx+di],cl
     30f:	4d                   	dec    bp
     310:	61                   	popa
     311:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     316:	75 31                	jne    0x349
     318:	84 01                	test   BYTE PTR [bx+di],al
     31a:	08 00                	or     BYTE PTR [bx+si],al
     31c:	08 46 69             	or     BYTE PTR [bp+0x69],al
     31f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     322:	65 72 31             	gs jb  0x356
     325:	88 01                	mov    BYTE PTR [bx+di],al
     327:	08 00                	or     BYTE PTR [bx+si],al
     329:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     32c:	70 72                	jo     0x3a0
     32e:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     333:	8c 01                	mov    WORD PTR [bx+di],es
     335:	08 00                	or     BYTE PTR [bx+si],al
     337:	02 4e 31             	add    cl,BYTE PTR [bp+0x31]
     33a:	90                   	nop
     33b:	01 08                	add    WORD PTR [bx+si],cx
     33d:	00 08                	add    BYTE PTR [bx+si],cl
     33f:	51                   	push   cx
     340:	75 69                	jne    0x3ab
     342:	74 74                	je     0x3b8
     344:	65 72 31             	gs jb  0x378
     347:	94                   	xchg   sp,ax
     348:	01 08                	add    WORD PTR [bx+si],cx
     34a:	00 0a                	add    BYTE PTR [bp+si],cl
     34c:	41                   	inc    cx
     34d:	66 66 69 63 68 61 67 	data32 imul esp,DWORD PTR [bp+di+0x68],0x31656761
     354:	65 31 
     356:	98                   	cbw
     357:	01 08                	add    WORD PTR [bx+si],cx
     359:	00 0d                	add    BYTE PTR [di],cl
     35b:	42                   	inc    dx
     35c:	61                   	popa
     35d:	72 72                	jb     0x3d1
     35f:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     362:	75 74                	jne    0x3d8
     364:	69 6c 73 31 9c       	imul   bp,WORD PTR [si+0x73],0x9c31
     369:	01 08                	add    WORD PTR [bx+si],cx
     36b:	00 0b                	add    BYTE PTR [bp+di],cl
     36d:	50                   	push   ax
     36e:	6c                   	ins    BYTE PTR es:[di],dx
     36f:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     375:	61                   	popa
     376:	6e                   	outs   dx,BYTE PTR ds:[si]
     377:	31 a0 01 08          	xor    WORD PTR [bx+si+0x801],sp
     37b:	00 02                	add    BYTE PTR [bp+si],al
     37d:	4e                   	dec    si
     37e:	32 a4 01 08          	xor    ah,BYTE PTR [si+0x801]
     382:	00 05                	add    BYTE PTR [di],al
     384:	5a                   	pop    dx
     385:	6f                   	outs   dx,WORD PTR ds:[si]
     386:	6f                   	outs   dx,WORD PTR ds:[si]
     387:	6d                   	ins    WORD PTR es:[di],dx
     388:	31 a8 01 08          	xor    WORD PTR [bx+si+0x801],bp
     38c:	00 05                	add    BYTE PTR [di],al
     38e:	41                   	inc    cx
     38f:	69 64 65 31 ac       	imul   sp,WORD PTR [si+0x65],0xac31
     394:	01 08                	add    WORD PTR [bx+si],cx
     396:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     39a:	64 65 78 31          	fs gs js 0x3cf
     39e:	b0 01                	mov    al,0x1
     3a0:	08 00                	or     BYTE PTR [bx+si],al
     3a2:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     3a5:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     3a8:	72 63                	jb     0x40d
     3aa:	68 65 72             	push   0x7265
     3ad:	31 b4 01 08          	xor    WORD PTR [si+0x801],si
     3b1:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     3b5:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     3ba:	72 6c                	jb     0x428
     3bc:	61                   	popa
     3bd:	69 64 65 31 b8       	imul   sp,WORD PTR [si+0x65],0xb831
     3c2:	01 08                	add    WORD PTR [bx+si],cx
     3c4:	00 08                	add    BYTE PTR [bx+si],cl
     3c6:	41                   	inc    cx
     3c7:	70 72                	jo     0x43b
     3c9:	6f                   	outs   dx,WORD PTR ds:[si]
     3ca:	70 6f                	jo     0x43b
     3cc:	73 31                	jae    0x3ff
     3ce:	bc 01 0c             	mov    sp,0xc01
     3d1:	00 08                	add    BYTE PTR [bx+si],cl
     3d3:	54                   	push   sp
     3d4:	61                   	popa
     3d5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3d8:	45                   	inc    bp
     3d9:	52                   	push   dx
     3da:	47                   	inc    di
     3db:	c0 01 10             	rol    BYTE PTR [bx+di],0x10
     3de:	00 15                	add    BYTE PTR [di],dl
     3e0:	54                   	push   sp
     3e1:	61                   	popa
     3e2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3e5:	45                   	inc    bp
     3e6:	52                   	push   dx
     3e7:	47                   	inc    di
     3e8:	45                   	inc    bp
     3e9:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ea:	64 65 74 74          	fs gs je 0x462
     3ee:	65 6d                	gs ins WORD PTR es:[di],dx
     3f0:	65 6e                	outs   dx,BYTE PTR gs:[si]
     3f2:	74 50                	je     0x444
     3f4:	43                   	inc    bx
     3f5:	c4 01                	les    ax,DWORD PTR [bx+di]
     3f7:	0c 00                	or     al,0x0
     3f9:	0d 54 61             	or     ax,0x6154
     3fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3ff:	45                   	inc    bp
     400:	52                   	push   dx
     401:	50                   	push   ax
     402:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     405:	6c                   	ins    BYTE PTR es:[di],dx
     406:	64 c8 01 0c 00       	fs enter 0xc01,0x0
     40b:	0d 54 61             	or     ax,0x6154
     40e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     411:	45                   	inc    bp
     412:	52                   	push   dx
     413:	50                   	push   ax
     414:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     417:	6c                   	ins    BYTE PTR es:[di],dx
     418:	64 cc                	fs int3
     41a:	01 0c                	add    WORD PTR [si],cx
     41c:	00 0c                	add    BYTE PTR [si],cl
     41e:	54                   	push   sp
     41f:	61                   	popa
     420:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     423:	45                   	inc    bp
     424:	52                   	push   dx
     425:	47                   	inc    di
     426:	5f                   	pop    di
     427:	4f                   	dec    di
     428:	6c                   	ins    BYTE PTR es:[di],dx
     429:	64 d0 01             	rol    BYTE PTR fs:[bx+di],1
     42c:	0c 00                	or     al,0x0
     42e:	09 54 61             	or     WORD PTR [si+0x61],dx
     431:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     434:	45                   	inc    bp
     435:	52                   	push   dx
     436:	50                   	push   ax
     437:	31 d4                	xor    sp,dx
     439:	01 0c                	add    WORD PTR [si],cx
     43b:	00 09                	add    BYTE PTR [bx+di],cl
     43d:	54                   	push   sp
     43e:	61                   	popa
     43f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     442:	45                   	inc    bp
     443:	52                   	push   dx
     444:	50                   	push   ax
     445:	32 d8                	xor    bl,al
     447:	01 0c                	add    WORD PTR [si],cx
     449:	00 08                	add    BYTE PTR [bx+si],cl
     44b:	54                   	push   sp
     44c:	61                   	popa
     44d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     450:	41                   	inc    cx
     451:	44                   	inc    sp
     452:	47                   	inc    di
     453:	dc 01                	fadd   QWORD PTR [bx+di]
     455:	0c 00                	or     al,0x0
     457:	09 54 61             	or     WORD PTR [si+0x61],dx
     45a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     45d:	41                   	inc    cx
     45e:	44                   	inc    sp
     45f:	50                   	push   ax
     460:	31 e0                	xor    ax,sp
     462:	01 0c                	add    WORD PTR [si],cx
     464:	00 09                	add    BYTE PTR [bx+di],cl
     466:	54                   	push   sp
     467:	61                   	popa
     468:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     46b:	41                   	inc    cx
     46c:	44                   	inc    sp
     46d:	50                   	push   ax
     46e:	32 e4                	xor    ah,ah
     470:	01 0c                	add    WORD PTR [si],cx
     472:	00 09                	add    BYTE PTR [bx+di],cl
     474:	54                   	push   sp
     475:	61                   	popa
     476:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     479:	45                   	inc    bp
     47a:	44                   	inc    sp
     47b:	50                   	push   ax
     47c:	31 e8                	xor    ax,bp
     47e:	01 0c                	add    WORD PTR [si],cx
     480:	00 09                	add    BYTE PTR [bx+di],cl
     482:	54                   	push   sp
     483:	61                   	popa
     484:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     487:	45                   	inc    bp
     488:	44                   	inc    sp
     489:	50                   	push   ax
     48a:	32 ec                	xor    ch,ah
     48c:	01 10                	add    WORD PTR [bx+si],dx
     48e:	00 15                	add    BYTE PTR [di],dl
     490:	54                   	push   sp
     491:	61                   	popa
     492:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     495:	45                   	inc    bp
     496:	52                   	push   dx
     497:	47                   	inc    di
     498:	56                   	push   si
     499:	61                   	popa
     49a:	6c                   	ins    BYTE PTR es:[di],dx
     49b:	65 75 72             	gs jne 0x510
     49e:	41                   	inc    cx
     49f:	6a 6f                	push   0x6f
     4a1:	75 74                	jne    0x517
     4a3:	65 65 f0 01 0c       	gs lock add WORD PTR gs:[si],cx
     4a8:	00 08                	add    BYTE PTR [bx+si],cl
     4aa:	54                   	push   sp
     4ab:	61                   	popa
     4ac:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4af:	45                   	inc    bp
     4b0:	44                   	inc    sp
     4b1:	47                   	inc    di
     4b2:	f4                   	hlt
     4b3:	01 10                	add    WORD PTR [bx+si],dx
     4b5:	00 0b                	add    BYTE PTR [bp+di],cl
     4b7:	54                   	push   sp
     4b8:	61                   	popa
     4b9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4bc:	45                   	inc    bp
     4bd:	52                   	push   dx
     4be:	47                   	inc    di
     4bf:	45                   	inc    bp
     4c0:	42                   	inc    dx
     4c1:	45                   	inc    bp
     4c2:	f8                   	clc
     4c3:	01 10                	add    WORD PTR [bx+si],dx
     4c5:	00 19                	add    BYTE PTR [bx+di],bl
     4c7:	54                   	push   sp
     4c8:	61                   	popa
     4c9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4cc:	45                   	inc    bp
     4cd:	52                   	push   dx
     4ce:	47                   	inc    di
     4cf:	52                   	push   dx
     4d0:	65 73 75             	gs jae 0x548
     4d3:	6c                   	ins    BYTE PTR es:[di],dx
     4d4:	74 61                	je     0x537
     4d6:	74 43                	je     0x51b
     4d8:	6f                   	outs   dx,WORD PTR ds:[si]
     4d9:	6d                   	ins    WORD PTR es:[di],dx
     4da:	70 74                	jo     0x550
     4dc:	61                   	popa
     4dd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4e0:	fc                   	cld
     4e1:	01 10                	add    WORD PTR [bx+si],dx
     4e3:	00 15                	add    BYTE PTR [di],dl
     4e5:	54                   	push   sp
     4e6:	61                   	popa
     4e7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4ea:	45                   	inc    bp
     4eb:	52                   	push   dx
     4ec:	47                   	inc    di
     4ed:	52                   	push   dx
     4ee:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4f0:	74 61                	je     0x553
     4f2:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     4f5:	69 74 65 43 70       	imul   si,WORD PTR [si+0x65],0x7043
     4fa:	00 02                	add    BYTE PTR [bp+si],al
     4fc:	10 00                	adc    BYTE PTR [bx+si],al
     4fe:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     501:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     504:	45                   	inc    bp
     505:	52                   	push   dx
     506:	47                   	inc    di
     507:	45                   	inc    bp
     508:	66 66 65 74 4c       	data32 data32 gs je 0x559
     50d:	65 76 69             	gs jbe 0x579
     510:	65 72 04             	gs jb  0x517
     513:	02 10                	add    dl,BYTE PTR [bx+si]
     515:	00 15                	add    BYTE PTR [di],dl
     517:	54                   	push   sp
     518:	61                   	popa
     519:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     51c:	45                   	inc    bp
     51d:	52                   	push   dx
     51e:	47                   	inc    di
     51f:	52                   	push   dx
     520:	6f                   	outs   dx,WORD PTR ds:[si]
     521:	74 61                	je     0x584
     523:	74 69                	je     0x58e
     525:	6f                   	outs   dx,WORD PTR ds:[si]
     526:	6e                   	outs   dx,BYTE PTR ds:[si]
     527:	41                   	inc    cx
     528:	63 74 69             	arpl   WORD PTR [si+0x69],si
     52b:	66 08 02             	data32 or BYTE PTR [bp+si],al
     52e:	08 00                	or     BYTE PTR [bx+si],al
     530:	08 50 65             	or     BYTE PTR [bx+si+0x65],dl
     533:	72 69                	jb     0x59e
     535:	6f                   	outs   dx,WORD PTR ds:[si]
     536:	64 65 31 0c          	fs xor WORD PTR gs:[si],cx
     53a:	02 14                	add    dl,BYTE PTR [si]
     53c:	00 0c                	add    BYTE PTR [si],cl
     53e:	50                   	push   ax
     53f:	72 69                	jb     0x5aa
     541:	6e                   	outs   dx,BYTE PTR ds:[si]
     542:	74 44                	je     0x588
     544:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     549:	31 10                	xor    WORD PTR [bx+si],dx
     54b:	02 18                	add    bl,BYTE PTR [bx+si]
     54d:	00 11                	add    BYTE PTR [bx+di],dl
     54f:	54                   	push   sp
     550:	61                   	popa
     551:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     554:	45                   	inc    bp
     555:	52                   	push   dx
     556:	47                   	inc    di
     557:	50                   	push   ax
     558:	65 72 69             	gs jb  0x5c4
     55b:	6f                   	outs   dx,WORD PTR ds:[si]
     55c:	64 65 4e             	fs gs dec si
     55f:	6f                   	outs   dx,WORD PTR ds:[si]
     560:	14 02                	adc    al,0x2
     562:	18 00                	sbb    BYTE PTR [bx+si],al
     564:	14 54                	adc    al,0x54
     566:	61                   	popa
     567:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     56a:	45                   	inc    bp
     56b:	52                   	push   dx
     56c:	47                   	inc    di
     56d:	45                   	inc    bp
     56e:	6e                   	outs   dx,BYTE PTR ds:[si]
     56f:	74 72                	je     0x5e3
     571:	65 70 72             	gs jo  0x5e6
     574:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     579:	18 02                	sbb    BYTE PTR [bp+si],al
     57b:	1c 00                	sbb    al,0x0
     57d:	15 54 61             	adc    ax,0x6154
     580:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     583:	45                   	inc    bp
     584:	52                   	push   dx
     585:	47                   	inc    di
     586:	43                   	inc    bx
     587:	61                   	popa
     588:	70 69                	jo     0x5f3
     58a:	74 61                	je     0x5ed
     58c:	6c                   	ins    BYTE PTR es:[di],dx
     58d:	53                   	push   bx
     58e:	6f                   	outs   dx,WORD PTR ds:[si]
     58f:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     592:	6c                   	ins    BYTE PTR es:[di],dx
     593:	1c 02                	sbb    al,0x2
     595:	1c 00                	sbb    al,0x0
     597:	10 54 61             	adc    BYTE PTR [si+0x61],dl
     59a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     59d:	45                   	inc    bp
     59e:	52                   	push   dx
     59f:	47                   	inc    di
     5a0:	52                   	push   dx
     5a1:	65 73 65             	gs jae 0x609
     5a4:	72 76                	jb     0x61c
     5a6:	65 73 20             	gs jae 0x5c9
     5a9:	02 1c                	add    bl,BYTE PTR [si]
     5ab:	00 13                	add    BYTE PTR [bp+di],dl
     5ad:	54                   	push   sp
     5ae:	61                   	popa
     5af:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5b2:	45                   	inc    bp
     5b3:	52                   	push   dx
     5b4:	47                   	inc    di
     5b5:	52                   	push   dx
     5b6:	65 73 75             	gs jae 0x62e
     5b9:	6c                   	ins    BYTE PTR es:[di],dx
     5ba:	74 61                	je     0x61d
     5bc:	74 4e                	je     0x60c
     5be:	65 74 24             	gs je  0x5e5
     5c1:	02 1c                	add    bl,BYTE PTR [si]
     5c3:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     5c7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ca:	45                   	inc    bp
     5cb:	52                   	push   dx
     5cc:	47                   	inc    di
     5cd:	53                   	push   bx
     5ce:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     5d3:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     5d8:	74 74                	je     0x64e
     5da:	65 28 02             	sub    BYTE PTR gs:[bp+si],al
     5dd:	1c 00                	sbb    al,0x0
     5df:	0b 54 61             	or     dx,WORD PTR [si+0x61]
     5e2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5e5:	45                   	inc    bp
     5e6:	52                   	push   dx
     5e7:	47                   	inc    di
     5e8:	43                   	inc    bx
     5e9:	41                   	inc    cx
     5ea:	46                   	inc    si
     5eb:	2c 02                	sub    al,0x2
     5ed:	1c 00                	sbb    al,0x0
     5ef:	0d 54 61             	or     ax,0x6154
     5f2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5f5:	45                   	inc    bp
     5f6:	52                   	push   dx
     5f7:	47                   	inc    di
     5f8:	49                   	dec    cx
     5f9:	6d                   	ins    WORD PTR es:[di],dx
     5fa:	70 6f                	jo     0x66b
     5fc:	74 30                	je     0x62e
     5fe:	02 1c                	add    bl,BYTE PTR [si]
     600:	00 0b                	add    BYTE PTR [bp+di],cl
     602:	54                   	push   sp
     603:	61                   	popa
     604:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     607:	45                   	inc    bp
     608:	52                   	push   dx
     609:	47                   	inc    di
     60a:	49                   	dec    cx
     60b:	46                   	inc    si
     60c:	41                   	inc    cx
     60d:	34 02                	xor    al,0x2
     60f:	1c 00                	sbb    al,0x0
     611:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     615:	6c                   	ins    BYTE PTR es:[di],dx
     616:	65 45                	gs inc bp
     618:	52                   	push   dx
     619:	47                   	inc    di
     61a:	43                   	inc    bx
     61b:	6c                   	ins    BYTE PTR es:[di],dx
     61c:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     621:	38 02                	cmp    BYTE PTR [bp+si],al
     623:	1c 00                	sbb    al,0x0
     625:	14 54                	adc    al,0x54
     627:	61                   	popa
     628:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     62b:	45                   	inc    bp
     62c:	52                   	push   dx
     62d:	47                   	inc    di
     62e:	46                   	inc    si
     62f:	6f                   	outs   dx,WORD PTR ds:[si]
     630:	75 72                	jne    0x6a4
     632:	6e                   	outs   dx,BYTE PTR ds:[si]
     633:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     638:	72 73                	jb     0x6ad
     63a:	3c 02                	cmp    al,0x2
     63c:	1c 00                	sbb    al,0x0
     63e:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     641:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     644:	45                   	inc    bp
     645:	52                   	push   dx
     646:	47                   	inc    di
     647:	54                   	push   sp
     648:	72 65                	jb     0x6af
     64a:	73 6f                	jae    0x6bb
     64c:	72 65                	jb     0x6b3
     64e:	72 69                	jb     0x6b9
     650:	65 40                	gs inc ax
     652:	02 1c                	add    bl,BYTE PTR [si]
     654:	00 0f                	add    BYTE PTR [bx],cl
     656:	54                   	push   sp
     657:	61                   	popa
     658:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     65b:	45                   	inc    bp
     65c:	52                   	push   dx
     65d:	47                   	inc    di
     65e:	45                   	inc    bp
     65f:	6d                   	ins    WORD PTR es:[di],dx
     660:	70 72                	jo     0x6d4
     662:	75 6e                	jne    0x6d2
     664:	74 44                	je     0x6aa
     666:	02 1c                	add    bl,BYTE PTR [si]
     668:	00 15                	add    BYTE PTR [di],dl
     66a:	54                   	push   sp
     66b:	61                   	popa
     66c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     66f:	45                   	inc    bp
     670:	52                   	push   dx
     671:	47                   	inc    di
     672:	44                   	inc    sp
     673:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     677:	76 65                	jbe    0x6de
     679:	72 74                	jb     0x6ef
     67b:	41                   	inc    cx
     67c:	75 74                	jne    0x6f2
     67e:	6f                   	outs   dx,WORD PTR ds:[si]
     67f:	48                   	dec    ax
     680:	02 1c                	add    bl,BYTE PTR [si]
     682:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     686:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     689:	45                   	inc    bp
     68a:	52                   	push   dx
     68b:	47                   	inc    di
     68c:	44                   	inc    sp
     68d:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     691:	76 65                	jbe    0x6f8
     693:	72 74                	jb     0x709
     695:	4e                   	dec    si
     696:	41                   	inc    cx
     697:	75 74                	jne    0x70d
     699:	6f                   	outs   dx,WORD PTR ds:[si]
     69a:	4c                   	dec    sp
     69b:	02 1c                	add    bl,BYTE PTR [si]
     69d:	00 15                	add    BYTE PTR [di],dl
     69f:	54                   	push   sp
     6a0:	61                   	popa
     6a1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a4:	45                   	inc    bp
     6a5:	52                   	push   dx
     6a6:	47                   	inc    di
     6a7:	41                   	inc    cx
     6a8:	6d                   	ins    WORD PTR es:[di],dx
     6a9:	6f                   	outs   dx,WORD PTR ds:[si]
     6aa:	72 74                	jb     0x720
     6ac:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     6b1:	65 6e                	outs   dx,BYTE PTR gs:[si]
     6b3:	74 50                	je     0x705
     6b5:	02 1c                	add    bl,BYTE PTR [si]
     6b7:	00 10                	add    BYTE PTR [bx+si],dl
     6b9:	54                   	push   sp
     6ba:	61                   	popa
     6bb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6be:	45                   	inc    bp
     6bf:	52                   	push   dx
     6c0:	47                   	inc    di
     6c1:	43                   	inc    bx
     6c2:	65 73 73             	gs jae 0x738
     6c5:	69 6f 6e 73 54       	imul   bp,WORD PTR [bx+0x6e],0x5473
     6ca:	02 18                	add    bl,BYTE PTR [bx+si]
     6cc:	00 10                	add    BYTE PTR [bx+si],dl
     6ce:	54                   	push   sp
     6cf:	61                   	popa
     6d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6d3:	45                   	inc    bp
     6d4:	52                   	push   dx
     6d5:	47                   	inc    di
     6d6:	4d                   	dec    bp
     6d7:	61                   	popa
     6d8:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     6db:	6e                   	outs   dx,BYTE PTR ds:[si]
     6dc:	65 73 58             	gs jae 0x737
     6df:	02 1c                	add    bl,BYTE PTR [si]
     6e1:	00 1d                	add    BYTE PTR [di],bl
     6e3:	54                   	push   sp
     6e4:	61                   	popa
     6e5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6e8:	45                   	inc    bp
     6e9:	52                   	push   dx
     6ea:	47                   	inc    di
     6eb:	49                   	dec    cx
     6ec:	6d                   	ins    WORD PTR es:[di],dx
     6ed:	6d                   	ins    WORD PTR es:[di],dx
     6ee:	6f                   	outs   dx,WORD PTR ds:[si]
     6ef:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     6f2:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     6f7:	6f                   	outs   dx,WORD PTR ds:[si]
     6f8:	6e                   	outs   dx,BYTE PTR ds:[si]
     6f9:	73 42                	jae    0x73d
     6fb:	72 75                	jb     0x772
     6fd:	74 65                	je     0x764
     6ff:	73 5c                	jae    0x75d
     701:	02 1c                	add    bl,BYTE PTR [si]
     703:	00 1c                	add    BYTE PTR [si],bl
     705:	54                   	push   sp
     706:	61                   	popa
     707:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     70a:	45                   	inc    bp
     70b:	52                   	push   dx
     70c:	47                   	inc    di
     70d:	43                   	inc    bx
     70e:	6f                   	outs   dx,WORD PTR ds:[si]
     70f:	75 74                	jne    0x785
     711:	73 46                	jae    0x759
     713:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     718:	72 6f                	jb     0x789
     71a:	64 75 63             	fs jne 0x780
     71d:	74 69                	je     0x788
     71f:	6f                   	outs   dx,WORD PTR ds:[si]
     720:	6e                   	outs   dx,BYTE PTR ds:[si]
     721:	60                   	pusha
     722:	02 18                	add    bl,BYTE PTR [bx+si]
     724:	00 12                	add    BYTE PTR [bp+si],dl
     726:	54                   	push   sp
     727:	61                   	popa
     728:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     72b:	45                   	inc    bp
     72c:	52                   	push   dx
     72d:	47                   	inc    di
     72e:	50                   	push   ax
     72f:	72 6f                	jb     0x7a0
     731:	64 75 63             	fs jne 0x797
     734:	74 69                	je     0x79f
     736:	66 73 64             	data32 jae 0x79d
     739:	02 18                	add    bl,BYTE PTR [bx+si]
     73b:	00 10                	add    BYTE PTR [bx+si],dl
     73d:	54                   	push   sp
     73e:	61                   	popa
     73f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     742:	45                   	inc    bp
     743:	52                   	push   dx
     744:	47                   	inc    di
     745:	56                   	push   si
     746:	65 6e                	outs   dx,BYTE PTR gs:[si]
     748:	64 65 75 72          	fs gs jne 0x7be
     74c:	73 68                	jae    0x7b6
     74e:	02 18                	add    bl,BYTE PTR [bx+si]
     750:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     754:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     757:	45                   	inc    bp
     758:	52                   	push   dx
     759:	47                   	inc    di
     75a:	43                   	inc    bx
     75b:	61                   	popa
     75c:	64 72 65             	fs jb  0x7c4
     75f:	73 6c                	jae    0x7cd
     761:	02 1c                	add    bl,BYTE PTR [si]
     763:	00 14                	add    BYTE PTR [si],dl
     765:	54                   	push   sp
     766:	61                   	popa
     767:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     76a:	45                   	inc    bp
     76b:	52                   	push   dx
     76c:	47                   	inc    di
     76d:	43                   	inc    bx
     76e:	6f                   	outs   dx,WORD PTR ds:[si]
     76f:	75 74                	jne    0x7e5
     771:	45                   	inc    bp
     772:	6d                   	ins    WORD PTR es:[di],dx
     773:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     776:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     779:	70 02                	jo     0x77d
     77b:	1c 00                	sbb    al,0x0
     77d:	14 54                	adc    al,0x54
     77f:	61                   	popa
     780:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     783:	45                   	inc    bp
     784:	52                   	push   dx
     785:	47                   	inc    di
     786:	43                   	inc    bx
     787:	6f                   	outs   dx,WORD PTR ds:[si]
     788:	75 74                	jne    0x7fe
     78a:	4c                   	dec    sp
     78b:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     790:	69 65 74 02 1c       	imul   sp,WORD PTR [di+0x74],0x1c02
     795:	00 15                	add    BYTE PTR [di],dl
     797:	54                   	push   sp
     798:	61                   	popa
     799:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     79c:	45                   	inc    bp
     79d:	52                   	push   dx
     79e:	47                   	inc    di
     79f:	43                   	inc    bx
     7a0:	6f                   	outs   dx,WORD PTR ds:[si]
     7a1:	75 74                	jne    0x817
     7a3:	46                   	inc    si
     7a4:	6f                   	outs   dx,WORD PTR ds:[si]
     7a5:	72 6d                	jb     0x814
     7a7:	61                   	popa
     7a8:	74 69                	je     0x813
     7aa:	6f                   	outs   dx,WORD PTR ds:[si]
     7ab:	6e                   	outs   dx,BYTE PTR ds:[si]
     7ac:	78 02                	js     0x7b0
     7ae:	1c 00                	sbb    al,0x0
     7b0:	15 54 61             	adc    ax,0x6154
     7b3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7b6:	45                   	inc    bp
     7b7:	52                   	push   dx
     7b8:	47                   	inc    di
     7b9:	44                   	inc    sp
     7ba:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     7bf:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     7c2:	69 6f 6e 73 7c       	imul   bp,WORD PTR [bx+0x6e],0x7c73
     7c7:	02 18                	add    bl,BYTE PTR [bx+si]
     7c9:	00 0f                	add    BYTE PTR [bx],cl
     7cb:	54                   	push   sp
     7cc:	61                   	popa
     7cd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7d0:	45                   	inc    bp
     7d1:	52                   	push   dx
     7d2:	47                   	inc    di
     7d3:	53                   	push   bx
     7d4:	70 65                	jo     0x83b
     7d6:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     7d9:	6c                   	ins    BYTE PTR es:[di],dx
     7da:	80 02 1c             	add    BYTE PTR [bp+si],0x1c
     7dd:	00 14                	add    BYTE PTR [si],dl
     7df:	54                   	push   sp
     7e0:	61                   	popa
     7e1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7e4:	45                   	inc    bp
     7e5:	52                   	push   dx
     7e6:	47                   	inc    di
     7e7:	54                   	push   sp
     7e8:	56                   	push   si
     7e9:	41                   	inc    cx
     7ea:	43                   	inc    bx
     7eb:	6f                   	outs   dx,WORD PTR ds:[si]
     7ec:	6c                   	ins    BYTE PTR es:[di],dx
     7ed:	6c                   	ins    BYTE PTR es:[di],dx
     7ee:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     7f2:	65 84 02             	test   BYTE PTR gs:[bp+si],al
     7f5:	1c 00                	sbb    al,0x0
     7f7:	15 54 61             	adc    ax,0x6154
     7fa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7fd:	45                   	inc    bp
     7fe:	52                   	push   dx
     7ff:	47                   	inc    di
     800:	54                   	push   sp
     801:	56                   	push   si
     802:	41                   	inc    cx
     803:	44                   	inc    sp
     804:	65 64 75 63          	gs fs jne 0x86b
     808:	74 69                	je     0x873
     80a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     80d:	88 02                	mov    BYTE PTR [bp+si],al
     80f:	1c 00                	sbb    al,0x0
     811:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     814:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     817:	45                   	inc    bp
     818:	52                   	push   dx
     819:	47                   	inc    di
     81a:	52                   	push   dx
     81b:	65 6d                	gs ins WORD PTR es:[di],dx
     81d:	75 6e                	jne    0x88d
     81f:	65 72 61             	gs jb  0x883
     822:	74 69                	je     0x88d
     824:	6f                   	outs   dx,WORD PTR ds:[si]
     825:	6e                   	outs   dx,BYTE PTR ds:[si]
     826:	43                   	inc    bx
     827:	61                   	popa
     828:	64 72 65             	fs jb  0x890
     82b:	73 8c                	jae    0x7b9
     82d:	02 08                	add    cl,BYTE PTR [bx+si]
     82f:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
     833:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     836:	31 90 02 08          	xor    WORD PTR [bx+si+0x802],dx
     83a:	00 02                	add    BYTE PTR [bp+si],al
     83c:	4e                   	dec    si
     83d:	33 94 02 00          	xor    dx,WORD PTR [si+0x2]
     841:	00 07                	add    BYTE PTR [bx],al
     843:	50                   	push   ax
     844:	61                   	popa
     845:	6e                   	outs   dx,BYTE PTR ds:[si]
     846:	65 6c                	gs ins BYTE PTR es:[di],dx
     848:	34 34                	xor    al,0x34
     84a:	98                   	cbw
     84b:	02 20                	add    ah,BYTE PTR [bx+si]
     84d:	00 07                	add    BYTE PTR [bx],al
     84f:	4c                   	dec    sp
     850:	61                   	popa
     851:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     854:	55                   	push   bp
     855:	30 9c 02 20          	xor    BYTE PTR [si+0x2002],bl
     859:	00 07                	add    BYTE PTR [bx],al
     85b:	4c                   	dec    sp
     85c:	61                   	popa
     85d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     860:	55                   	push   bp
     861:	31 a0 02 20          	xor    WORD PTR [bx+si+0x2002],sp
     865:	00 07                	add    BYTE PTR [bx],al
     867:	4c                   	dec    sp
     868:	61                   	popa
     869:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     86c:	55                   	push   bp
     86d:	32 a4 02 20          	xor    ah,BYTE PTR [si+0x2002]
     871:	00 07                	add    BYTE PTR [bx],al
     873:	4c                   	dec    sp
     874:	61                   	popa
     875:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     878:	55                   	push   bp
     879:	33 a8 02 08          	xor    bp,WORD PTR [bx+si+0x802]
     87d:	00 08                	add    BYTE PTR [bx+si],cl
     87f:	45                   	inc    bp
     880:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     886:	31 ac 02 08          	xor    WORD PTR [si+0x802],bp
     88a:	00 07                	add    BYTE PTR [bx],al
     88c:	43                   	inc    bx
     88d:	6f                   	outs   dx,WORD PTR ds:[si]
     88e:	70 69                	jo     0x8f9
     890:	65 72 31             	gs jb  0x8c4
     893:	b0 02                	mov    al,0x2
     895:	24 00                	and    al,0x0
     897:	05 4d 65             	add    ax,0x654d
     89a:	6d                   	ins    WORD PTR es:[di],dx
     89b:	6f                   	outs   dx,WORD PTR ds:[si]
     89c:	31 b4 02 10          	xor    WORD PTR [si+0x1002],si
     8a0:	00 1b                	add    BYTE PTR [bp+di],bl
     8a2:	54                   	push   sp
     8a3:	61                   	popa
     8a4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8a7:	45                   	inc    bp
     8a8:	52                   	push   dx
     8a9:	47                   	inc    di
     8aa:	54                   	push   sp
     8ab:	72 65                	jb     0x912
     8ad:	73 6f                	jae    0x91e
     8af:	72 65                	jb     0x916
     8b1:	72 69                	jb     0x91c
     8b3:	65 50                	gs push ax
     8b5:	6c                   	ins    BYTE PTR es:[di],dx
     8b6:	75 73                	jne    0x92b
     8b8:	4d                   	dec    bp
     8b9:	6f                   	outs   dx,WORD PTR ds:[si]
     8ba:	69 6e 73 b8 02       	imul   bp,WORD PTR [bp+0x73],0x2b8
     8bf:	1c 00                	sbb    al,0x0
     8c1:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     8c4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8c7:	45                   	inc    bp
     8c8:	52                   	push   dx
     8c9:	47                   	inc    di
     8ca:	41                   	inc    cx
     8cb:	67 65 4d             	addr32 gs dec bp
     8ce:	6f                   	outs   dx,WORD PTR ds:[si]
     8cf:	79 65                	jns    0x936
     8d1:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d2:	4d                   	dec    bp
     8d3:	61                   	popa
     8d4:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     8d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d8:	65 73 bc             	gs jae 0x897
     8db:	02 08                	add    cl,BYTE PTR [bx+si]
     8dd:	00 05                	add    BYTE PTR [di],al
     8df:	4e                   	dec    si
     8e0:	31 30                	xor    WORD PTR [bx+si],si
     8e2:	30 31                	xor    BYTE PTR [bx+di],dh
     8e4:	c0 02 08             	rol    BYTE PTR [bp+si],0x8
     8e7:	00 05                	add    BYTE PTR [di],al
     8e9:	4e                   	dec    si
     8ea:	31 35                	xor    WORD PTR [di],si
     8ec:	30 31                	xor    BYTE PTR [bx+di],dh
     8ee:	c4 02                	les    ax,DWORD PTR [bp+si]
     8f0:	08 00                	or     BYTE PTR [bx+si],al
     8f2:	05 4e 32             	add    ax,0x324e
     8f5:	30 30                	xor    BYTE PTR [bx+si],dh
     8f7:	31 c8                	xor    ax,cx
     8f9:	02 08                	add    cl,BYTE PTR [bx+si]
     8fb:	00 04                	add    BYTE PTR [si],al
     8fd:	4e                   	dec    si
     8fe:	37                   	aaa
     8ff:	35 31 cc             	xor    ax,0xcc31
     902:	02 08                	add    cl,BYTE PTR [bx+si]
     904:	00 04                	add    BYTE PTR [si],al
     906:	4e                   	dec    si
     907:	35 30 31             	xor    ax,0x3130
     90a:	d0 02                	rol    BYTE PTR [bp+si],1
     90c:	08 00                	or     BYTE PTR [bx+si],al
     90e:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
     911:	d4 02                	aam    0x2
     913:	08 00                	or     BYTE PTR [bx+si],al
     915:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     918:	70 72                	jo     0x98c
     91a:	65 73 73             	gs jae 0x990
     91d:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     922:	70 69                	jo     0x98d
     924:	64 65 31 d8          	fs gs xor ax,bx
     928:	02 08                	add    cl,BYTE PTR [bx+si]
     92a:	00 02                	add    BYTE PTR [bp+si],al
     92c:	4e                   	dec    si
     92d:	35 dc 02             	xor    ax,0x2dc
     930:	08 00                	or     BYTE PTR [bx+si],al
     932:	10 41 75             	adc    BYTE PTR [bx+di+0x75],al
     935:	74 72                	je     0x9a9
     937:	65 73 52             	gs jae 0x98c
     93a:	65 73 75             	gs jae 0x9b2
     93d:	6c                   	ins    BYTE PTR es:[di],dx
     93e:	74 61                	je     0x9a1
     940:	74 73                	je     0x9b5
     942:	31 e0                	xor    ax,sp
     944:	02 08                	add    cl,BYTE PTR [bx+si]
     946:	00 15                	add    BYTE PTR [di],dl
     948:	52                   	push   dx
     949:	65 73 75             	gs jae 0x9c1
     94c:	6c                   	ins    BYTE PTR es:[di],dx
     94d:	74 61                	je     0x9b0
     94f:	74 73                	je     0x9c4
     951:	50                   	push   ax
     952:	61                   	popa
     953:	72 50                	jb     0x9a5
     955:	72 6f                	jb     0x9c6
     957:	64 75 69             	fs jne 0x9c3
     95a:	74 73                	je     0x9cf
     95c:	31 e4                	xor    sp,sp
     95e:	02 08                	add    cl,BYTE PTR [bx+si]
     960:	00 12                	add    BYTE PTR [bp+si],dl
     962:	52                   	push   dx
     963:	65 73 75             	gs jae 0x9db
     966:	6c                   	ins    BYTE PTR es:[di],dx
     967:	74 61                	je     0x9ca
     969:	74 73                	je     0x9de
     96b:	47                   	inc    di
     96c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     96e:	65 72 61             	gs jb  0x9d2
     971:	75 78                	jne    0x9eb
     973:	31 e8                	xor    ax,bp
     975:	02 08                	add    cl,BYTE PTR [bx+si]
     977:	00 02                	add    BYTE PTR [bp+si],al
     979:	4e                   	dec    si
     97a:	36 ec                	ss in  al,dx
     97c:	02 08                	add    cl,BYTE PTR [bx+si]
     97e:	00 12                	add    BYTE PTR [bp+si],dl
     980:	52                   	push   dx
     981:	61                   	popa
     982:	70 70                	jo     0x9f4
     984:	65 6c                	gs ins BYTE PTR es:[di],dx
     986:	64 65 64 65 63 69 73 	fs gs fs arpl WORD PTR gs:[bx+di+0x73],bp
     98d:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     992:	f0 02 08             	lock add cl,BYTE PTR [bx+si]
     995:	00 0a                	add    BYTE PTR [bp+si],cl
     997:	41                   	inc    cx
     998:	6e                   	outs   dx,BYTE PTR ds:[si]
     999:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     99e:	75 72                	jne    0xa12
     9a0:	31 f4                	xor    sp,si
     9a2:	02 08                	add    cl,BYTE PTR [bx+si]
     9a4:	00 0c                	add    BYTE PTR [si],cl
     9a6:	45                   	inc    bp
     9a7:	6e                   	outs   dx,BYTE PTR ds:[si]
     9a8:	74 72                	je     0xa1c
     9aa:	65 70 72             	gs jo  0xa1f
     9ad:	69 73 65 73 31       	imul   si,WORD PTR [bp+di+0x65],0x3173
     9b2:	f8                   	clc
     9b3:	02 08                	add    cl,BYTE PTR [bx+si]
     9b5:	00 09                	add    BYTE PTR [bx+di],cl
     9b7:	43                   	inc    bx
     9b8:	72 65                	jb     0xa1f
     9ba:	61                   	popa
     9bb:	74 69                	je     0xa26
     9bd:	6f                   	outs   dx,WORD PTR ds:[si]
     9be:	6e                   	outs   dx,BYTE PTR ds:[si]
     9bf:	31 fc                	xor    sp,di
     9c1:	02 08                	add    cl,BYTE PTR [bx+si]
     9c3:	00 07                	add    BYTE PTR [bx],al
     9c5:	46                   	inc    si
     9c6:	6f                   	outs   dx,WORD PTR ds:[si]
     9c7:	72 6d                	jb     0xa36
     9c9:	61                   	popa
     9ca:	74 31                	je     0x9fd
     9cc:	00 03                	add    BYTE PTR [bp+di],al
     9ce:	08 00                	or     BYTE PTR [bx+si],al
     9d0:	06                   	push   es
     9d1:	53                   	push   bx
     9d2:	74 79                	je     0xa4d
     9d4:	6c                   	ins    BYTE PTR es:[di],dx
     9d5:	65 31 04             	xor    WORD PTR gs:[si],ax
     9d8:	03 08                	add    cx,WORD PTR [bx+si]
     9da:	00 05                	add    BYTE PTR [di],al
     9dc:	4c                   	dec    sp
     9dd:	6f                   	outs   dx,WORD PTR ds:[si]
     9de:	6e                   	outs   dx,BYTE PTR ds:[si]
     9df:	67 31 08             	xor    WORD PTR [eax],cx
     9e2:	03 08                	add    cx,WORD PTR [bx+si]
     9e4:	00 07                	add    BYTE PTR [bx],al
     9e6:	4e                   	dec    si
     9e7:	6f                   	outs   dx,WORD PTR ds:[si]
     9e8:	72 6d                	jb     0xa57
     9ea:	61                   	popa
     9eb:	6c                   	ins    BYTE PTR es:[di],dx
     9ec:	31 0c                	xor    WORD PTR [si],cx
     9ee:	03 08                	add    cx,WORD PTR [bx+si]
     9f0:	00 06 43 6f          	add    BYTE PTR ds:0x6f43,al
     9f4:	75 72                	jne    0xa68
     9f6:	74 31                	je     0xa29
     9f8:	10 03                	adc    BYTE PTR [bp+di],al
     9fa:	08 00                	or     BYTE PTR [bx+si],al
     9fc:	09 45 67             	or     WORD PTR [di+0x67],ax
     9ff:	61                   	popa
     a00:	6c                   	ins    BYTE PTR es:[di],dx
     a01:	69 73 65 72 31       	imul   si,WORD PTR [bp+di+0x65],0x3172
     a06:	14 03                	adc    al,0x3
     a08:	00 00                	add    BYTE PTR [bx+si],al
     a0a:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     a0d:	6e                   	outs   dx,BYTE PTR ds:[si]
     a0e:	65 6c                	gs ins BYTE PTR es:[di],dx
     a10:	4c                   	dec    sp
     a11:	6f                   	outs   dx,WORD PTR ds:[si]
     a12:	75 70                	jne    0xa84
     a14:	65 18 03             	sbb    BYTE PTR gs:[bp+di],al
     a17:	00 00                	add    BYTE PTR [bx+si],al
     a19:	07                   	pop    es
     a1a:	50                   	push   ax
     a1b:	61                   	popa
     a1c:	6e                   	outs   dx,BYTE PTR ds:[si]
     a1d:	65 6c                	gs ins BYTE PTR es:[di],dx
     a1f:	30 32                	xor    BYTE PTR [bp+si],dh
     a21:	1c 03                	sbb    al,0x3
     a23:	00 00                	add    BYTE PTR [bx+si],al
     a25:	07                   	pop    es
     a26:	50                   	push   ax
     a27:	61                   	popa
     a28:	6e                   	outs   dx,BYTE PTR ds:[si]
     a29:	65 6c                	gs ins BYTE PTR es:[di],dx
     a2b:	31 30                	xor    WORD PTR [bx+si],si
     a2d:	20 03                	and    BYTE PTR [bp+di],al
     a2f:	00 00                	add    BYTE PTR [bx+si],al
     a31:	07                   	pop    es
     a32:	50                   	push   ax
     a33:	61                   	popa
     a34:	6e                   	outs   dx,BYTE PTR ds:[si]
     a35:	65 6c                	gs ins BYTE PTR es:[di],dx
     a37:	31 31                	xor    WORD PTR [bx+di],si
     a39:	24 03                	and    al,0x3
     a3b:	00 00                	add    BYTE PTR [bx+si],al
     a3d:	07                   	pop    es
     a3e:	50                   	push   ax
     a3f:	61                   	popa
     a40:	6e                   	outs   dx,BYTE PTR ds:[si]
     a41:	65 6c                	gs ins BYTE PTR es:[di],dx
     a43:	31 32                	xor    WORD PTR [bp+si],si
     a45:	28 03                	sub    BYTE PTR [bp+di],al
     a47:	00 00                	add    BYTE PTR [bx+si],al
     a49:	06                   	push   es
     a4a:	50                   	push   ax
     a4b:	61                   	popa
     a4c:	6e                   	outs   dx,BYTE PTR ds:[si]
     a4d:	65 6c                	gs ins BYTE PTR es:[di],dx
     a4f:	32 2c                	xor    ch,BYTE PTR [si]
     a51:	03 00                	add    ax,WORD PTR [bx+si]
     a53:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     a57:	6e                   	outs   dx,BYTE PTR ds:[si]
     a58:	65 6c                	gs ins BYTE PTR es:[di],dx
     a5a:	35 30 03             	xor    ax,0x330
     a5d:	28 00                	sub    BYTE PTR [bx+si],al
     a5f:	12 53 70             	adc    dl,BYTE PTR [bp+di+0x70]
     a62:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     a66:	6c                   	ins    BYTE PTR es:[di],dx
     a67:	53                   	push   bx
     a68:	74 72                	je     0xadc
     a6a:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     a6f:	69 64 32 34 03       	imul   sp,WORD PTR [si+0x32],0x334
     a74:	00 00                	add    BYTE PTR [bx+si],al
     a76:	07                   	pop    es
     a77:	50                   	push   ax
     a78:	61                   	popa
     a79:	6e                   	outs   dx,BYTE PTR ds:[si]
     a7a:	65 6c                	gs ins BYTE PTR es:[di],dx
     a7c:	30 31                	xor    BYTE PTR [bx+di],dh
     a7e:	38 03                	cmp    BYTE PTR [bp+di],al
     a80:	00 00                	add    BYTE PTR [bx+si],al
     a82:	06                   	push   es
     a83:	50                   	push   ax
     a84:	61                   	popa
     a85:	6e                   	outs   dx,BYTE PTR ds:[si]
     a86:	65 6c                	gs ins BYTE PTR es:[di],dx
     a88:	31 3c                	xor    WORD PTR [si],di
     a8a:	03 00                	add    ax,WORD PTR [bx+si]
     a8c:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     a90:	6e                   	outs   dx,BYTE PTR ds:[si]
     a91:	65 6c                	gs ins BYTE PTR es:[di],dx
     a93:	37                   	aaa
     a94:	40                   	inc    ax
     a95:	03 2c                	add    bp,WORD PTR [si]
     a97:	00 05                	add    BYTE PTR [di],al
     a99:	45                   	inc    bp
     a9a:	64 69 74 31 44 03    	imul   si,WORD PTR fs:[si+0x31],0x344
     aa0:	00 00                	add    BYTE PTR [bx+si],al
     aa2:	06                   	push   es
     aa3:	50                   	push   ax
     aa4:	61                   	popa
     aa5:	6e                   	outs   dx,BYTE PTR ds:[si]
     aa6:	65 6c                	gs ins BYTE PTR es:[di],dx
     aa8:	39 48 03             	cmp    WORD PTR [bx+si+0x3],cx
     aab:	00 00                	add    BYTE PTR [bx+si],al
     aad:	06                   	push   es
     aae:	50                   	push   ax
     aaf:	61                   	popa
     ab0:	6e                   	outs   dx,BYTE PTR ds:[si]
     ab1:	65 6c                	gs ins BYTE PTR es:[di],dx
     ab3:	38 4c 03             	cmp    BYTE PTR [si+0x3],cl
     ab6:	00 00                	add    BYTE PTR [bx+si],al
     ab8:	06                   	push   es
     ab9:	50                   	push   ax
     aba:	61                   	popa
     abb:	6e                   	outs   dx,BYTE PTR ds:[si]
     abc:	65 6c                	gs ins BYTE PTR es:[di],dx
     abe:	33 50 03             	xor    dx,WORD PTR [bx+si+0x3]
     ac1:	28 00                	sub    BYTE PTR [bx+si],al
     ac3:	12 53 70             	adc    dl,BYTE PTR [bp+di+0x70]
     ac6:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     aca:	6c                   	ins    BYTE PTR es:[di],dx
     acb:	53                   	push   bx
     acc:	74 72                	je     0xb40
     ace:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     ad3:	69 64 31 54 03       	imul   sp,WORD PTR [si+0x31],0x354
     ad8:	30 00                	xor    BYTE PTR [bx+si],al
     ada:	08 4c 69             	or     BYTE PTR [si+0x69],cl
     add:	73 74                	jae    0xb53
     adf:	42                   	inc    dx
     ae0:	6f                   	outs   dx,WORD PTR ds:[si]
     ae1:	78 31                	js     0xb14
     ae3:	58                   	pop    ax
     ae4:	03 08                	add    cx,WORD PTR [bx+si]
     ae6:	00 05                	add    BYTE PTR [di],al
     ae8:	4e                   	dec    si
     ae9:	31 32                	xor    WORD PTR [bp+si],si
     aeb:	35 31 5c             	xor    ax,0x5c31
     aee:	03 08                	add    cx,WORD PTR [bx+si]
     af0:	00 08                	add    BYTE PTR [bx+si],cl
     af2:	50                   	push   ax
     af3:	65 72 69             	gs jb  0xb5f
     af6:	6f                   	outs   dx,WORD PTR ds:[si]
     af7:	64 65 32 60 03       	fs xor ah,BYTE PTR gs:[bx+si+0x3]
     afc:	08 00                	or     BYTE PTR [bx+si],al
     afe:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     b01:	31 64 03             	xor    WORD PTR [si+0x3],sp
     b04:	08 00                	or     BYTE PTR [bx+si],al
     b06:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     b09:	31 68 03             	xor    WORD PTR [bx+si+0x3],bp
     b0c:	08 00                	or     BYTE PTR [bx+si],al
     b0e:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     b11:	31 6c 03             	xor    WORD PTR [si+0x3],bp
     b14:	08 00                	or     BYTE PTR [bx+si],al
     b16:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     b19:	31 70 03             	xor    WORD PTR [bx+si+0x3],si
     b1c:	08 00                	or     BYTE PTR [bx+si],al
     b1e:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     b21:	31 74 03             	xor    WORD PTR [si+0x3],si
     b24:	08 00                	or     BYTE PTR [bx+si],al
     b26:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
     b29:	31 78 03             	xor    WORD PTR [bx+si+0x3],di
     b2c:	08 00                	or     BYTE PTR [bx+si],al
     b2e:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     b31:	31 7c 03             	xor    WORD PTR [si+0x3],di
     b34:	08 00                	or     BYTE PTR [bx+si],al
     b36:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     b39:	31 80 03 08          	xor    WORD PTR [bx+si+0x803],ax
     b3d:	00 03                	add    BYTE PTR [bp+di],al
     b3f:	4e                   	dec    si
     b40:	39 31                	cmp    WORD PTR [bx+di],si
     b42:	84 03                	test   BYTE PTR [bp+di],al
     b44:	08 00                	or     BYTE PTR [bx+si],al
     b46:	04 4e                	add    al,0x4e
     b48:	31 30                	xor    WORD PTR [bx+si],si
     b4a:	31 88 03 08          	xor    WORD PTR [bx+si+0x803],cx
     b4e:	00 04                	add    BYTE PTR [si],al
     b50:	4e                   	dec    si
     b51:	31 31                	xor    WORD PTR [bx+di],si
     b53:	31 8c 03 08          	xor    WORD PTR [si+0x803],cx
     b57:	00 04                	add    BYTE PTR [si],al
     b59:	4e                   	dec    si
     b5a:	31 32                	xor    WORD PTR [bp+si],si
     b5c:	31 90 03 08          	xor    WORD PTR [bx+si+0x803],dx
     b60:	00 04                	add    BYTE PTR [si],al
     b62:	4e                   	dec    si
     b63:	31 33                	xor    WORD PTR [bp+di],si
     b65:	31 94 03 08          	xor    WORD PTR [si+0x803],dx
     b69:	00 04                	add    BYTE PTR [si],al
     b6b:	4e                   	dec    si
     b6c:	31 34                	xor    WORD PTR [si],si
     b6e:	31 98 03 08          	xor    WORD PTR [bx+si+0x803],bx
     b72:	00 04                	add    BYTE PTR [si],al
     b74:	4e                   	dec    si
     b75:	31 35                	xor    WORD PTR [di],si
     b77:	31 9c 03 08          	xor    WORD PTR [si+0x803],bx
     b7b:	00 04                	add    BYTE PTR [si],al
     b7d:	4e                   	dec    si
     b7e:	31 36 31 a0          	xor    WORD PTR ds:0xa031,si
     b82:	03 08                	add    cx,WORD PTR [bx+si]
     b84:	00 04                	add    BYTE PTR [si],al
     b86:	4e                   	dec    si
     b87:	31 37                	xor    WORD PTR [bx],si
     b89:	31 a4 03 08          	xor    WORD PTR [si+0x803],sp
     b8d:	00 04                	add    BYTE PTR [si],al
     b8f:	4e                   	dec    si
     b90:	31 38                	xor    WORD PTR [bx+si],di
     b92:	31 a8 03 08          	xor    WORD PTR [bx+si+0x803],bp
     b96:	00 04                	add    BYTE PTR [si],al
     b98:	4e                   	dec    si
     b99:	31 39                	xor    WORD PTR [bx+di],di
     b9b:	31 ac 03 08          	xor    WORD PTR [si+0x803],bp
     b9f:	00 04                	add    BYTE PTR [si],al
     ba1:	4e                   	dec    si
     ba2:	32 30                	xor    dh,BYTE PTR [bx+si]
     ba4:	31 b0 03 08          	xor    WORD PTR [bx+si+0x803],si
     ba8:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
     bac:	74 72                	je     0xc20
     bae:	65 31 b4 03 1c       	xor    WORD PTR gs:[si+0x1c03],si
     bb3:	00 17                	add    BYTE PTR [bx],dl
     bb5:	54                   	push   sp
     bb6:	61                   	popa
     bb7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bba:	45                   	inc    bp
     bbb:	52                   	push   dx
     bbc:	47                   	inc    di
     bbd:	50                   	push   ax
     bbe:	72 69                	jb     0xc29
     bc0:	6d                   	ins    WORD PTR es:[di],dx
     bc1:	65 73 41             	gs jae 0xc05
     bc4:	73 73                	jae    0xc39
     bc6:	75 72                	jne    0xc3a
     bc8:	61                   	popa
     bc9:	6e                   	outs   dx,BYTE PTR ds:[si]
     bca:	63 65 b8             	arpl   WORD PTR [di-0x48],sp
     bcd:	03 1c                	add    bx,WORD PTR [si]
     bcf:	00 13                	add    BYTE PTR [bp+di],dl
     bd1:	54                   	push   sp
     bd2:	61                   	popa
     bd3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bd6:	45                   	inc    bp
     bd7:	52                   	push   dx
     bd8:	47                   	inc    di
     bd9:	52                   	push   dx
     bda:	65 70 61             	gs jo  0xc3e
     bdd:	72 61                	jb     0xc40
     bdf:	74 69                	je     0xc4a
     be1:	6f                   	outs   dx,WORD PTR ds:[si]
     be2:	6e                   	outs   dx,BYTE PTR ds:[si]
     be3:	73 bc                	jae    0xba1
     be5:	03 1c                	add    bx,WORD PTR [si]
     be7:	00 19                	add    BYTE PTR [bx+di],bl
     be9:	54                   	push   sp
     bea:	61                   	popa
     beb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bee:	45                   	inc    bp
     bef:	52                   	push   dx
     bf0:	47                   	inc    di
     bf1:	45                   	inc    bp
     bf2:	6e                   	outs   dx,BYTE PTR ds:[si]
     bf3:	74 72                	je     0xc67
     bf5:	65 74 69             	gs je  0xc61
     bf8:	65 6e                	outs   dx,BYTE PTR gs:[si]
     bfa:	4d                   	dec    bp
     bfb:	61                   	popa
     bfc:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     bff:	6e                   	outs   dx,BYTE PTR ds:[si]
     c00:	65 73 c0             	gs jae 0xbc3
     c03:	03 1c                	add    bx,WORD PTR [si]
     c05:	00 15                	add    BYTE PTR [di],dl
     c07:	54                   	push   sp
     c08:	61                   	popa
     c09:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c0c:	45                   	inc    bp
     c0d:	52                   	push   dx
     c0e:	47                   	inc    di
     c0f:	52                   	push   dx
     c10:	65 6d                	gs ins WORD PTR es:[di],dx
     c12:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
     c15:	72 73                	jb     0xc8a
     c17:	41                   	inc    cx
     c18:	73 73                	jae    0xc8d
     c1a:	75 72                	jne    0xc8e
     c1c:	0d 00 ad             	or     ax,0xad00
     c1f:	0d ff ff             	or     ax,0xffff
     c22:	ef                   	out    dx,ax
     c23:	02 28                	add    ch,BYTE PTR [bx+si]
     c25:	0c 94                	or     al,0x94
     c27:	00 12                	add    BYTE PTR [bp+si],dl
     c29:	14 38                	adc    al,0x38
     c2b:	01 30                	add    WORD PTR [bx+si],si
     c2d:	0c 58                	or     al,0x58
     c2f:	0a 38                	or     bh,BYTE PTR [bx+si]
     c31:	0c 7e                	or     al,0x7e
     c33:	08 66 12             	or     BYTE PTR [bp+0x12],ah
     c36:	c8 07 3c 0c          	enter  0x3c07,0xc
     c3a:	67 0c 3e             	addr32 or al,0x3e
     c3d:	15 17 06             	adc    ax,0x617
     c40:	44                   	inc    sp
     c41:	0c 91                	or     al,0x91
     c43:	12 4c 0c             	adc    cl,BYTE PTR [si+0xc]
     c46:	e7 18                	out    0x18,ax
     c48:	a2 16 90             	mov    ds:0x9016,al
     c4b:	0b 50 0c             	or     dx,WORD PTR [bx+si+0xc]
     c4e:	7d 32                	jge    0xc82
     c50:	37                   	aaa
     c51:	35 07 12             	xor    ax,0x1207
     c54:	54                   	push   sp
     c55:	46                   	inc    si
     c56:	6f                   	outs   dx,WORD PTR ds:[si]
     c57:	72 6d                	jb     0xcc6
     c59:	53                   	push   bx
     c5a:	41                   	inc    cx
     c5b:	52                   	push   dx
     c5c:	47                   	inc    di
     c5d:	5f                   	pop    di
     c5e:	47                   	inc    di
     c5f:	65 6e                	outs   dx,BYTE PTR gs:[si]
     c61:	65 72 61             	gs jb  0xcc5
     c64:	75 78                	jne    0xcde
     c66:	22 00                	and    al,BYTE PTR [bx+si]
     c68:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     c69:	0c 7b                	or     al,0x7b
     c6b:	06                   	push   es
     c6c:	97                   	xchg   di,ax
     c6d:	0c 38                	or     al,0x38
     c6f:	00 04                	add    BYTE PTR [si],al
     c71:	53                   	push   bx
     c72:	61                   	popa
     c73:	72 67                	jb     0xcdc
     c75:	00 00                	add    BYTE PTR [bx+si],al
     c77:	55                   	push   bp
     c78:	89 e5                	mov    bp,sp
     c7a:	31 c0                	xor    ax,ax
     c7c:	9a 44 04 b1 0c       	call   0xcb1:0x444
     c81:	6a 00                	push   0x0
     c83:	9a c2 38 01 11       	call   0x1101:0x38c2
     c88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c8b:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     c92:	06                   	push   es
     c93:	57                   	push   di
     c94:	9a 56 55 d5 0c       	call   0xcd5:0x5556
     c99:	9a c3 28 d2 14       	call   0x14d2:0x28c3
     c9e:	c9                   	leave
     c9f:	ca 04 00             	retf   0x4
     ca2:	00 00                	add    BYTE PTR [bx+si],al
     ca4:	3a 0d                	cmp    cl,BYTE PTR [di]
     ca6:	ce                   	into
     ca7:	0c 55                	or     al,0x55
     ca9:	89 e5                	mov    bp,sp
     cab:	b8 08 00             	mov    ax,0x8
     cae:	9a 44 04 60 0d       	call   0xd60:0x444
     cb3:	83 ec 08             	sub    sp,0x8
     cb6:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     cba:	7f 03                	jg     0xcbf
     cbc:	e9 86 00             	jmp    0xd45
     cbf:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     cc3:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     cc7:	b0 01                	mov    al,0x1
     cc9:	50                   	push   ax
     cca:	b8 22 00             	mov    ax,0x22
     ccd:	ba fb 0c             	mov    dx,0xcfb
     cd0:	52                   	push   dx
     cd1:	50                   	push   ax
     cd2:	9a 53 25 22 0d       	call   0xd22:0x2553
     cd7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cda:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     cdd:	b8 a2 0c             	mov    ax,0xca2
     ce0:	0e                   	push   cs
     ce1:	50                   	push   ax
     ce2:	55                   	push   bp
     ce3:	ff 36 58 18          	push   WORD PTR ds:0x1858
     ce7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     ceb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     cee:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     cf1:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     cf4:	6a 00                	push   0x0
     cf6:	06                   	push   es
     cf7:	57                   	push   di
     cf8:	9a 34 11 08 0d       	call   0xd08:0x1134
     cfd:	ff 76 06             	push   WORD PTR [bp+0x6]
     d00:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d03:	06                   	push   es
     d04:	57                   	push   di
     d05:	9a bc 16 55 0d       	call   0xd55:0x16bc
     d0a:	6a ff                	push   0xffff
     d0c:	6a f0                	push   0xfff0
     d0e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d11:	06                   	push   es
     d12:	57                   	push   di
     d13:	9a d5 1e ee 0d       	call   0xdee:0x1ed5
     d18:	6a 02                	push   0x2
     d1a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d1d:	06                   	push   es
     d1e:	57                   	push   di
     d1f:	9a 14 3a 2c 0d       	call   0xd2c:0x3a14
     d24:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d27:	06                   	push   es
     d28:	57                   	push   di
     d29:	9a 45 5d 42 0d       	call   0xd42:0x5d45
     d2e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     d32:	83 c4 06             	add    sp,0x6
     d35:	b8 45 0d             	mov    ax,0xd45
     d38:	0e                   	push   cs
     d39:	50                   	push   ax
     d3a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d3d:	06                   	push   es
     d3e:	57                   	push   di
     d3f:	9a 1d 5f ac 0d       	call   0xdac:0x5f1d
     d44:	cb                   	retf
     d45:	c9                   	leave
     d46:	ca 02 00             	retf   0x2
     d49:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     d4d:	ff                   	(bad)
     d4e:	7f 00                	jg     0xd50
     d50:	00 00                	add    BYTE PTR [bx+si],al
     d52:	00 25                	add    BYTE PTR [di],ah
     d54:	11 a5 0d 55          	adc    WORD PTR [di+0x550d],sp
     d58:	89 e5                	mov    bp,sp
     d5a:	b8 1a 00             	mov    ax,0x1a
     d5d:	9a 44 04 a2 0e       	call   0xea2:0x444
     d62:	83 ec 1a             	sub    sp,0x1a
     d65:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
     d69:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
     d6d:	7e 1e                	jle    0xd8d
     d6f:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     d73:	75 14                	jne    0xd89
     d75:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     d79:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
     d7f:	b0 00                	mov    al,0x0
     d81:	75 01                	jne    0xd84
     d83:	40                   	inc    ax
     d84:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     d87:	eb 04                	jmp    0xd8d
     d89:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
     d8d:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
     d91:	75 03                	jne    0xd96
     d93:	e9 9a 03             	jmp    0x1130
     d96:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     d9a:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     d9e:	b0 01                	mov    al,0x1
     da0:	50                   	push   ax
     da1:	b8 22 00             	mov    ax,0x22
     da4:	ba d2 0d             	mov    dx,0xdd2
     da7:	52                   	push   dx
     da8:	50                   	push   ax
     da9:	9a 53 25 fc 0d       	call   0xdfc:0x2553
     dae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     db1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     db4:	b8 51 0d             	mov    ax,0xd51
     db7:	0e                   	push   cs
     db8:	50                   	push   ax
     db9:	55                   	push   bp
     dba:	ff 36 58 18          	push   WORD PTR ds:0x1858
     dbe:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     dc2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dc5:	89 7e ee             	mov    WORD PTR [bp-0x12],di
     dc8:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
     dcb:	6a 01                	push   0x1
     dcd:	06                   	push   es
     dce:	57                   	push   di
     dcf:	9a 34 11 df 0d       	call   0xddf:0x1134
     dd4:	ff 76 08             	push   WORD PTR [bp+0x8]
     dd7:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     dda:	06                   	push   es
     ddb:	57                   	push   di
     ddc:	9a bc 16 82 0e       	call   0xe82:0x16bc
     de1:	68 ff 00             	push   0xff
     de4:	6a ff                	push   0xffff
     de6:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     de9:	06                   	push   es
     dea:	57                   	push   di
     deb:	9a d5 1e 2a 0e       	call   0xe2a:0x1ed5
     df0:	6a 00                	push   0x0
     df2:	6a 00                	push   0x0
     df4:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     df7:	06                   	push   es
     df8:	57                   	push   di
     df9:	9a b2 36 08 0e       	call   0xe08:0x36b2
     dfe:	6a 02                	push   0x2
     e00:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e03:	06                   	push   es
     e04:	57                   	push   di
     e05:	9a 14 3a 14 0e       	call   0xe14:0x3a14
     e0a:	6a 01                	push   0x1
     e0c:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e0f:	06                   	push   es
     e10:	57                   	push   di
     e11:	9a e5 34 72 0e       	call   0xe72:0x34e5
     e16:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
     e1a:	06                   	push   es
     e1b:	57                   	push   di
     e1c:	9a 9a 2a 0e 30       	call   0x300e:0x2a9a
     e21:	50                   	push   ax
     e22:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e25:	06                   	push   es
     e26:	57                   	push   di
     e27:	9a bf 17 56 0e       	call   0xe56:0x17bf
     e2c:	6a 00                	push   0x0
     e2e:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e31:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
     e36:	06                   	push   es
     e37:	57                   	push   di
     e38:	9a 4c 75 4c 0e       	call   0xe4c:0x754c
     e3d:	6a 00                	push   0x0
     e3f:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e42:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
     e47:	06                   	push   es
     e48:	57                   	push   di
     e49:	9a 4c 75 0f 0f       	call   0xf0f:0x754c
     e4e:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e51:	06                   	push   es
     e52:	57                   	push   di
     e53:	9a b9 62 63 11       	call   0x1163:0x62b9
     e58:	50                   	push   ax
     e59:	6a 04                	push   0x4
     e5b:	9a ff ff 00 00       	call   0x0:0xffff
     e60:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e63:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
     e68:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
     e6d:	06                   	push   es
     e6e:	57                   	push   di
     e6f:	9a d0 3f 90 0e       	call   0xe90:0x3fd0
     e74:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     e78:	74 0d                	je     0xe87
     e7a:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e7d:	06                   	push   es
     e7e:	57                   	push   di
     e7f:	9a 53 30 22 12       	call   0x1222:0x3053
     e84:	e9 92 02             	jmp    0x1119
     e87:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     e8b:	06                   	push   es
     e8c:	57                   	push   di
     e8d:	9a 03 73 17 11       	call   0x1117:0x7303
     e92:	a1 4e 01             	mov    ax,ds:0x14e
     e95:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e98:	26 03 85 c9 03       	add    ax,WORD PTR es:[di+0x3c9]
     e9d:	71 05                	jno    0xea4
     e9f:	9a 3e 04 ac 0e       	call   0xeac:0x43e
     ea4:	2d 01 00             	sub    ax,0x1
     ea7:	71 05                	jno    0xeae
     ea9:	9a 3e 04 d8 0e       	call   0xed8:0x43e
     eae:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     eb1:	99                   	cwd
     eb2:	26 f7 bd c9 03       	idiv   WORD PTR es:[di+0x3c9]
     eb7:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     eba:	b8 01 00             	mov    ax,0x1
     ebd:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
     ec0:	7e 03                	jle    0xec5
     ec2:	e9 49 02             	jmp    0x110e
     ec5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     ec8:	eb 03                	jmp    0xecd
     eca:	ff 46 f8             	inc    WORD PTR [bp-0x8]
     ecd:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ed0:	2d 01 00             	sub    ax,0x1
     ed3:	71 05                	jno    0xeda
     ed5:	9a 3e 04 e7 0e       	call   0xee7:0x43e
     eda:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     edd:	26 f7 ad c9 03       	imul   WORD PTR es:[di+0x3c9]
     ee2:	71 05                	jno    0xee9
     ee4:	9a 3e 04 f3 0e       	call   0xef3:0x43e
     ee9:	b9 01 00             	mov    cx,0x1
     eec:	f7 e9                	imul   cx
     eee:	71 05                	jno    0xef5
     ef0:	9a 3e 04 fd 0e       	call   0xefd:0x43e
     ef5:	05 01 00             	add    ax,0x1
     ef8:	71 05                	jno    0xeff
     efa:	9a 3e 04 4b 0f       	call   0xf4b:0x43e
     eff:	99                   	cwd
     f00:	52                   	push   dx
     f01:	50                   	push   ax
     f02:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     f05:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
     f0a:	06                   	push   es
     f0b:	57                   	push   di
     f0c:	9a 45 73 5a 0f       	call   0xf5a:0x7345
     f11:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     f14:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
     f19:	89 7e e8             	mov    WORD PTR [bp-0x18],di
     f1c:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
     f1f:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     f22:	26 8b 85 c9 03       	mov    ax,WORD PTR es:[di+0x3c9]
     f27:	99                   	cwd
     f28:	b9 02 00             	mov    cx,0x2
     f2b:	f7 f9                	idiv   cx
     f2d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     f30:	a1 4e 01             	mov    ax,ds:0x14e
     f33:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     f36:	7d 06                	jge    0xf3e
     f38:	a1 4e 01             	mov    ax,ds:0x14e
     f3b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     f3e:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     f41:	b9 03 00             	mov    cx,0x3
     f44:	f7 e9                	imul   cx
     f46:	71 05                	jno    0xf4d
     f48:	9a 3e 04 71 0f       	call   0xf71:0x43e
     f4d:	50                   	push   ax
     f4e:	6a 00                	push   0x0
     f50:	6a 00                	push   0x0
     f52:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
     f55:	06                   	push   es
     f56:	57                   	push   di
     f57:	9a 30 6e ca 0f       	call   0xfca:0x6e30
     f5c:	8b d0                	mov    dx,ax
     f5e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     f61:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
     f66:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
     f6a:	2b c2                	sub    ax,dx
     f6c:	71 05                	jno    0xf73
     f6e:	9a 3e 04 7b 0f       	call   0xf7b:0x43e
     f73:	5a                   	pop    dx
     f74:	2b c2                	sub    ax,dx
     f76:	71 05                	jno    0xf7d
     f78:	9a 3e 04 9c 0f       	call   0xf9c:0x43e
     f7d:	99                   	cwd
     f7e:	f7 7e f4             	idiv   WORD PTR [bp-0xc]
     f81:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     f84:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
     f87:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
     f8c:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
     f91:	2d 01 00             	sub    ax,0x1
     f94:	83 da 00             	sbb    dx,0x0
     f97:	71 05                	jno    0xf9e
     f99:	9a 3e 04 a4 0f       	call   0xfa4:0x43e
     f9e:	bf 49 0d             	mov    di,0xd49
     fa1:	9a 16 04 df 0f       	call   0xfdf:0x416
     fa6:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
     fa9:	b8 01 00             	mov    ax,0x1
     fac:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
     faf:	7f 23                	jg     0xfd4
     fb1:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     fb4:	eb 03                	jmp    0xfb9
     fb6:	ff 46 f2             	inc    WORD PTR [bp-0xe]
     fb9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
     fbc:	99                   	cwd
     fbd:	52                   	push   dx
     fbe:	50                   	push   ax
     fbf:	ff 76 f6             	push   WORD PTR [bp-0xa]
     fc2:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
     fc5:	06                   	push   es
     fc6:	57                   	push   di
     fc7:	9a c9 70 20 10       	call   0x1020:0x70c9
     fcc:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
     fcf:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
     fd2:	75 e2                	jne    0xfb6
     fd4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     fd7:	2d 01 00             	sub    ax,0x1
     fda:	71 05                	jno    0xfe1
     fdc:	9a 3e 04 ee 0f       	call   0xfee:0x43e
     fe1:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     fe4:	26 f7 ad c9 03       	imul   WORD PTR es:[di+0x3c9]
     fe9:	71 05                	jno    0xff0
     feb:	9a 3e 04 fa 0f       	call   0xffa:0x43e
     ff0:	b9 01 00             	mov    cx,0x1
     ff3:	f7 e9                	imul   cx
     ff5:	71 05                	jno    0xffc
     ff7:	9a 3e 04 04 10       	call   0x1004:0x43e
     ffc:	05 01 00             	add    ax,0x1
     fff:	71 05                	jno    0x1006
    1001:	9a 3e 04 0e 10       	call   0x100e:0x43e
    1006:	05 04 00             	add    ax,0x4
    1009:	71 05                	jno    0x1010
    100b:	9a 3e 04 5c 10       	call   0x105c:0x43e
    1010:	99                   	cwd
    1011:	52                   	push   dx
    1012:	50                   	push   ax
    1013:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1016:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    101b:	06                   	push   es
    101c:	57                   	push   di
    101d:	9a 45 73 6b 10       	call   0x106b:0x7345
    1022:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1025:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    102a:	89 7e e8             	mov    WORD PTR [bp-0x18],di
    102d:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
    1030:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1033:	26 8b 85 c9 03       	mov    ax,WORD PTR es:[di+0x3c9]
    1038:	99                   	cwd
    1039:	b9 02 00             	mov    cx,0x2
    103c:	f7 f9                	idiv   cx
    103e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1041:	a1 4e 01             	mov    ax,ds:0x14e
    1044:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1047:	7d 06                	jge    0x104f
    1049:	a1 4e 01             	mov    ax,ds:0x14e
    104c:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    104f:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1052:	b9 03 00             	mov    cx,0x3
    1055:	f7 e9                	imul   cx
    1057:	71 05                	jno    0x105e
    1059:	9a 3e 04 82 10       	call   0x1082:0x43e
    105e:	50                   	push   ax
    105f:	6a 00                	push   0x0
    1061:	6a 00                	push   0x0
    1063:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    1066:	06                   	push   es
    1067:	57                   	push   di
    1068:	9a 30 6e db 10       	call   0x10db:0x6e30
    106d:	8b d0                	mov    dx,ax
    106f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1072:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
    1077:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    107b:	2b c2                	sub    ax,dx
    107d:	71 05                	jno    0x1084
    107f:	9a 3e 04 8c 10       	call   0x108c:0x43e
    1084:	5a                   	pop    dx
    1085:	2b c2                	sub    ax,dx
    1087:	71 05                	jno    0x108e
    1089:	9a 3e 04 ad 10       	call   0x10ad:0x43e
    108e:	99                   	cwd
    108f:	f7 7e f4             	idiv   WORD PTR [bp-0xc]
    1092:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1095:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    1098:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    109d:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    10a2:	2d 01 00             	sub    ax,0x1
    10a5:	83 da 00             	sbb    dx,0x0
    10a8:	71 05                	jno    0x10af
    10aa:	9a 3e 04 b5 10       	call   0x10b5:0x43e
    10af:	bf 49 0d             	mov    di,0xd49
    10b2:	9a 16 04 3c 11       	call   0x113c:0x416
    10b7:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    10ba:	b8 01 00             	mov    ax,0x1
    10bd:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    10c0:	7f 23                	jg     0x10e5
    10c2:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    10c5:	eb 03                	jmp    0x10ca
    10c7:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    10ca:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    10cd:	99                   	cwd
    10ce:	52                   	push   dx
    10cf:	50                   	push   ax
    10d0:	ff 76 f6             	push   WORD PTR [bp-0xa]
    10d3:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    10d6:	06                   	push   es
    10d7:	57                   	push   di
    10d8:	9a c9 70 1f 19       	call   0x191f:0x70c9
    10dd:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    10e0:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    10e3:	75 e2                	jne    0x10c7
    10e5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10e8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    10eb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10ee:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    10f3:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    10f8:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    10fc:	06                   	push   es
    10fd:	57                   	push   di
    10fe:	9a 1a 31 7c 12       	call   0x127c:0x311a
    1103:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1106:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    1109:	74 03                	je     0x110e
    110b:	e9 bc fd             	jmp    0xeca
    110e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1112:	06                   	push   es
    1113:	57                   	push   di
    1114:	9a 03 73 2d 11       	call   0x112d:0x7303
    1119:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    111d:	83 c4 06             	add    sp,0x6
    1120:	b8 30 11             	mov    ax,0x1130
    1123:	0e                   	push   cs
    1124:	50                   	push   ax
    1125:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1128:	06                   	push   es
    1129:	57                   	push   di
    112a:	9a 1d 5f 78 11       	call   0x1178:0x5f1d
    112f:	cb                   	retf
    1130:	c9                   	leave
    1131:	ca 04 00             	retf   0x4
    1134:	55                   	push   bp
    1135:	89 e5                	mov    bp,sp
    1137:	31 c0                	xor    ax,ax
    1139:	9a 44 04 30 12       	call   0x1230:0x444
    113e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1141:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1144:	26 88 85 c6 03       	mov    BYTE PTR es:[di+0x3c6],al
    1149:	83 3e 4e 01 04       	cmp    WORD PTR ds:0x14e,0x4
    114e:	b0 00                	mov    al,0x0
    1150:	7e 01                	jle    0x1153
    1152:	40                   	inc    ax
    1153:	26 22 85 c6 03       	and    al,BYTE PTR es:[di+0x3c6]
    1158:	50                   	push   ax
    1159:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    115e:	06                   	push   es
    115f:	57                   	push   di
    1160:	9a 77 1c c4 11       	call   0x11c4:0x1c77
    1165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1168:	26 8a 85 c6 03       	mov    al,BYTE PTR es:[di+0x3c6]
    116d:	50                   	push   ax
    116e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1173:	06                   	push   es
    1174:	57                   	push   di
    1175:	9a 62 1e 8d 11       	call   0x118d:0x1e62
    117a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    117d:	26 8a 85 c6 03       	mov    al,BYTE PTR es:[di+0x3c6]
    1182:	50                   	push   ax
    1183:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1188:	06                   	push   es
    1189:	57                   	push   di
    118a:	9a 62 1e 9e 11       	call   0x119e:0x1e62
    118f:	6a 00                	push   0x0
    1191:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1194:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1199:	06                   	push   es
    119a:	57                   	push   di
    119b:	9a d0 1c af 11       	call   0x11af:0x1cd0
    11a0:	6a 00                	push   0x0
    11a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a5:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    11aa:	06                   	push   es
    11ab:	57                   	push   di
    11ac:	9a d0 1c 83 12       	call   0x1283:0x1cd0
    11b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11b4:	26 8a 85 c6 03       	mov    al,BYTE PTR es:[di+0x3c6]
    11b9:	50                   	push   ax
    11ba:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    11bf:	06                   	push   es
    11c0:	57                   	push   di
    11c1:	9a 77 1c fe 11       	call   0x11fe:0x1c77
    11c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11c9:	26 80 bd c6 03 00    	cmp    BYTE PTR es:[di+0x3c6],0x0
    11cf:	74 10                	je     0x11e1
    11d1:	26 c7 85 c9 03 08 00 	mov    WORD PTR es:[di+0x3c9],0x8
    11d8:	26 c7 85 cb 03 14 00 	mov    WORD PTR es:[di+0x3cb],0x14
    11df:	eb 30                	jmp    0x1211
    11e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e4:	26 c7 85 c9 03 08 00 	mov    WORD PTR es:[di+0x3c9],0x8
    11eb:	26 c7 85 cb 03 0f 00 	mov    WORD PTR es:[di+0x3cb],0xf
    11f2:	6a 05                	push   0x5
    11f4:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    11f9:	06                   	push   es
    11fa:	57                   	push   di
    11fb:	9a 72 16 0f 12       	call   0x120f:0x1672
    1200:	6a 05                	push   0x5
    1202:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1205:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    120a:	06                   	push   es
    120b:	57                   	push   di
    120c:	9a 72 16 3a 13       	call   0x133a:0x1672
    1211:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1214:	81 c7 50 03          	add    di,0x350
    1218:	06                   	push   es
    1219:	57                   	push   di
    121a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    121d:	06                   	push   es
    121e:	57                   	push   di
    121f:	9a 56 1b 3f 12       	call   0x123f:0x1b56
    1224:	c9                   	leave
    1225:	ca 06 00             	retf   0x6
    1228:	55                   	push   bp
    1229:	89 e5                	mov    bp,sp
    122b:	31 c0                	xor    ax,ax
    122d:	9a 44 04 54 12       	call   0x1254:0x444
    1232:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1235:	26 ff b5 c7 03       	push   WORD PTR es:[di+0x3c7]
    123a:	6a 00                	push   0x0
    123c:	9a 57 0d 49 12       	call   0x1249:0xd57
    1241:	c9                   	leave
    1242:	ca 08 00             	retf   0x8
    1245:	00 00                	add    BYTE PTR [bx+si],al
    1247:	e2 12                	loop   0x125b
    1249:	b6 12                	mov    dh,0x12
    124b:	55                   	push   bp
    124c:	89 e5                	mov    bp,sp
    124e:	b8 04 00             	mov    ax,0x4
    1251:	9a 44 04 fa 12       	call   0x12fa:0x444
    1256:	83 ec 04             	sub    sp,0x4
    1259:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    125c:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    1261:	06                   	push   es
    1262:	57                   	push   di
    1263:	9a 17 2f db 2f       	call   0x2fdb:0x2f17
    1268:	08 c0                	or     al,al
    126a:	75 03                	jne    0x126f
    126c:	e9 7f 00             	jmp    0x12ee
    126f:	ff 76 08             	push   WORD PTR [bp+0x8]
    1272:	ff 76 06             	push   WORD PTR [bp+0x6]
    1275:	b0 01                	mov    al,0x1
    1277:	50                   	push   ax
    1278:	b8 b4 25             	mov    ax,0x25b4
    127b:	ba ab 12             	mov    dx,0x12ab
    127e:	52                   	push   dx
    127f:	50                   	push   ax
    1280:	9a 53 25 d4 12       	call   0x12d4:0x2553
    1285:	a3 04 20             	mov    ds:0x2004,ax
    1288:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    128c:	b8 45 12             	mov    ax,0x1245
    128f:	0e                   	push   cs
    1290:	50                   	push   ax
    1291:	55                   	push   bp
    1292:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1296:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    129a:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    129e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    12a1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    12a4:	6a 01                	push   0x1
    12a6:	06                   	push   es
    12a7:	57                   	push   di
    12a8:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    12ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b0:	06                   	push   es
    12b1:	57                   	push   di
    12b2:	b8 28 12             	mov    ax,0x1228
    12b5:	ba 4a 13             	mov    dx,0x134a
    12b8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    12bb:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    12c0:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    12c5:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    12ca:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    12cf:	06                   	push   es
    12d0:	57                   	push   di
    12d1:	9a 45 5d eb 12       	call   0x12eb:0x5d45
    12d6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    12da:	83 c4 06             	add    sp,0x6
    12dd:	b8 ee 12             	mov    ax,0x12ee
    12e0:	0e                   	push   cs
    12e1:	50                   	push   ax
    12e2:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    12e6:	06                   	push   es
    12e7:	57                   	push   di
    12e8:	9a 1d 5f 57 13       	call   0x1357:0x5f1d
    12ed:	cb                   	retf
    12ee:	c9                   	leave
    12ef:	ca 08 00             	retf   0x8
    12f2:	55                   	push   bp
    12f3:	89 e5                	mov    bp,sp
    12f5:	31 c0                	xor    ax,ax
    12f7:	9a 44 04 10 13       	call   0x1310:0x444
    12fc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    12ff:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1303:	c9                   	leave
    1304:	ca 0c 00             	retf   0xc
    1307:	55                   	push   bp
    1308:	89 e5                	mov    bp,sp
    130a:	b8 04 00             	mov    ax,0x4
    130d:	9a 44 04 2f 13       	call   0x132f:0x444
    1312:	83 ec 04             	sub    sp,0x4
    1315:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1318:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    131d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1320:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1323:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1327:	05 01 00             	add    ax,0x1
    132a:	71 05                	jno    0x1331
    132c:	9a 3e 04 76 13       	call   0x1376:0x43e
    1331:	50                   	push   ax
    1332:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1335:	06                   	push   es
    1336:	57                   	push   di
    1337:	9a bf 17 ae 13       	call   0x13ae:0x17bf
    133c:	ff 76 08             	push   WORD PTR [bp+0x8]
    133f:	ff 76 06             	push   WORD PTR [bp+0x6]
    1342:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1345:	06                   	push   es
    1346:	57                   	push   di
    1347:	9a 59 16 53 16       	call   0x1653:0x1659
    134c:	6a fe                	push   0xfffe
    134e:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    1352:	06                   	push   es
    1353:	57                   	push   di
    1354:	9a a9 63 38 2a       	call   0x2a38:0x63a9
    1359:	c9                   	leave
    135a:	ca 08 00             	retf   0x8
    135d:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    1360:	6d                   	ins    WORD PTR es:[di],dx
    1361:	73 74                	jae    0x13d7
    1363:	72 61                	jb     0x13c6
    1365:	74 20                	je     0x1387
    1367:	2d 20 03             	sub    ax,0x320
    136a:	20 2d                	and    BYTE PTR [di],ch
    136c:	20 55 89             	and    BYTE PTR [di-0x77],dl
    136f:	e5 b8                	in     ax,0xb8
    1371:	02 03                	add    al,BYTE PTR [bp+di]
    1373:	9a 44 04 8a 13       	call   0x138a:0x444
    1378:	81 ec 02 03          	sub    sp,0x302
    137c:	8d be fe fe          	lea    di,[bp-0x102]
    1380:	16                   	push   ss
    1381:	57                   	push   di
    1382:	bf 5d 13             	mov    di,0x135d
    1385:	0e                   	push   cs
    1386:	57                   	push   di
    1387:	9a cd 17 94 13       	call   0x1394:0x17cd
    138c:	bf fa 1d             	mov    di,0x1dfa
    138f:	1e                   	push   ds
    1390:	57                   	push   di
    1391:	9a 4c 18 9e 13       	call   0x139e:0x184c
    1396:	bf 69 13             	mov    di,0x1369
    1399:	0e                   	push   cs
    139a:	57                   	push   di
    139b:	9a 4c 18 b3 13       	call   0x13b3:0x184c
    13a0:	8d be fe fd          	lea    di,[bp-0x202]
    13a4:	16                   	push   ss
    13a5:	57                   	push   di
    13a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13a9:	06                   	push   es
    13aa:	57                   	push   di
    13ab:	9a 53 1d 4e 14       	call   0x144e:0x1d53
    13b0:	9a 4c 18 c4 13       	call   0x13c4:0x184c
    13b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13b8:	81 c7 cd 03          	add    di,0x3cd
    13bc:	06                   	push   es
    13bd:	57                   	push   di
    13be:	68 ff 00             	push   0xff
    13c1:	9a e7 17 f0 13       	call   0x13f0:0x17e7
    13c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13c9:	26 c7 85 c4 03 64 00 	mov    WORD PTR es:[di+0x3c4],0x64
    13d0:	26 c4 bd 5c 03       	les    di,DWORD PTR es:[di+0x35c]
    13d5:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    13d8:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    13db:	31 c0                	xor    ax,ax
    13dd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    13e0:	eb 03                	jmp    0x13e5
    13e2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    13e5:	a1 4c 01             	mov    ax,ds:0x14c
    13e8:	2d 01 00             	sub    ax,0x1
    13eb:	71 05                	jno    0x13f2
    13ed:	9a 3e 04 ff 13       	call   0x13ff:0x43e
    13f2:	8b d0                	mov    dx,ax
    13f4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    13f7:	05 01 00             	add    ax,0x1
    13fa:	71 05                	jno    0x1401
    13fc:	9a 3e 04 30 14       	call   0x1430:0x43e
    1401:	3b c2                	cmp    ax,dx
    1403:	7e 1a                	jle    0x141f
    1405:	6a 00                	push   0x0
    1407:	ff 76 fe             	push   WORD PTR [bp-0x2]
    140a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    140d:	06                   	push   es
    140e:	57                   	push   di
    140f:	9a 53 13 1d 14       	call   0x141d:0x1353
    1414:	89 c7                	mov    di,ax
    1416:	8e c2                	mov    es,dx
    1418:	06                   	push   es
    1419:	57                   	push   di
    141a:	9a a5 13 43 16       	call   0x1643:0x13a5
    141f:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    1423:	75 bd                	jne    0x13e2
    1425:	a1 4c 01             	mov    ax,ds:0x14c
    1428:	2d 01 00             	sub    ax,0x1
    142b:	71 05                	jno    0x1432
    142d:	9a 3e 04 c7 14       	call   0x14c7:0x43e
    1432:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1435:	26 89 85 c7 03       	mov    WORD PTR es:[di+0x3c7],ax
    143a:	8d be fe fe          	lea    di,[bp-0x102]
    143e:	16                   	push   ss
    143f:	57                   	push   di
    1440:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1444:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    1449:	06                   	push   es
    144a:	57                   	push   di
    144b:	9a 53 1d 5d 14       	call   0x145d:0x1d53
    1450:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1453:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    1458:	06                   	push   es
    1459:	57                   	push   di
    145a:	9a 8c 1d 73 14       	call   0x1473:0x1d8c
    145f:	8d be fe fe          	lea    di,[bp-0x102]
    1463:	16                   	push   ss
    1464:	57                   	push   di
    1465:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1469:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    146e:	06                   	push   es
    146f:	57                   	push   di
    1470:	9a 53 1d 82 14       	call   0x1482:0x1d53
    1475:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1478:	26 c4 bd 9c 02       	les    di,DWORD PTR es:[di+0x29c]
    147d:	06                   	push   es
    147e:	57                   	push   di
    147f:	9a 8c 1d 98 14       	call   0x1498:0x1d8c
    1484:	8d be fe fe          	lea    di,[bp-0x102]
    1488:	16                   	push   ss
    1489:	57                   	push   di
    148a:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    148e:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    1493:	06                   	push   es
    1494:	57                   	push   di
    1495:	9a 53 1d a7 14       	call   0x14a7:0x1d53
    149a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    149d:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    14a2:	06                   	push   es
    14a3:	57                   	push   di
    14a4:	9a 8c 1d bd 14       	call   0x14bd:0x1d8c
    14a9:	8d be fe fe          	lea    di,[bp-0x102]
    14ad:	16                   	push   ss
    14ae:	57                   	push   di
    14af:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    14b3:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    14b8:	06                   	push   es
    14b9:	57                   	push   di
    14ba:	9a 53 1d 2a 15       	call   0x152a:0x1d53
    14bf:	bf 69 13             	mov    di,0x1369
    14c2:	0e                   	push   cs
    14c3:	57                   	push   di
    14c4:	9a 4c 18 e7 14       	call   0x14e7:0x184c
    14c9:	8d be fe fd          	lea    di,[bp-0x202]
    14cd:	16                   	push   ss
    14ce:	57                   	push   di
    14cf:	9a fe 15 e2 14       	call   0x14e2:0x15fe
    14d4:	83 ec 08             	sub    sp,0x8
    14d7:	89 e3                	mov    bx,sp
    14d9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    14dd:	90                   	nop
    14de:	9b                   	fwait
    14df:	9a bf 1c fc 14       	call   0x14fc:0x1cbf
    14e4:	9a 4c 18 f1 14       	call   0x14f1:0x184c
    14e9:	bf 69 13             	mov    di,0x1369
    14ec:	0e                   	push   cs
    14ed:	57                   	push   di
    14ee:	9a 4c 18 11 15       	call   0x1511:0x184c
    14f3:	8d be fe fc          	lea    di,[bp-0x302]
    14f7:	16                   	push   ss
    14f8:	57                   	push   di
    14f9:	9a fe 15 0c 15       	call   0x150c:0x15fe
    14fe:	83 ec 08             	sub    sp,0x8
    1501:	89 e3                	mov    bx,sp
    1503:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1507:	90                   	nop
    1508:	9b                   	fwait
    1509:	9a e4 1c 5a 17       	call   0x175a:0x1ce4
    150e:	9a 4c 18 1b 15       	call   0x151b:0x184c
    1513:	bf 69 13             	mov    di,0x1369
    1516:	0e                   	push   cs
    1517:	57                   	push   di
    1518:	9a 4c 18 28 16       	call   0x1628:0x184c
    151d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1520:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    1525:	06                   	push   es
    1526:	57                   	push   di
    1527:	9a 8c 1d 7e 17       	call   0x177e:0x1d8c
    152c:	bf 32 1e             	mov    di,0x1e32
    152f:	1e                   	push   ds
    1530:	57                   	push   di
    1531:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1534:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    1539:	06                   	push   es
    153a:	57                   	push   di
    153b:	9a 17 30 52 15       	call   0x1552:0x3017
    1540:	bf 40 1e             	mov    di,0x1e40
    1543:	1e                   	push   ds
    1544:	57                   	push   di
    1545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1548:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    154d:	06                   	push   es
    154e:	57                   	push   di
    154f:	9a 17 30 66 15       	call   0x1566:0x3017
    1554:	bf 40 1e             	mov    di,0x1e40
    1557:	1e                   	push   ds
    1558:	57                   	push   di
    1559:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    155c:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    1561:	06                   	push   es
    1562:	57                   	push   di
    1563:	9a 17 30 7a 15       	call   0x157a:0x3017
    1568:	bf 78 1e             	mov    di,0x1e78
    156b:	1e                   	push   ds
    156c:	57                   	push   di
    156d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1570:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    1575:	06                   	push   es
    1576:	57                   	push   di
    1577:	9a 17 30 8e 15       	call   0x158e:0x3017
    157c:	bf 86 1e             	mov    di,0x1e86
    157f:	1e                   	push   ds
    1580:	57                   	push   di
    1581:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1584:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    1589:	06                   	push   es
    158a:	57                   	push   di
    158b:	9a 17 30 a2 15       	call   0x15a2:0x3017
    1590:	bf 86 1e             	mov    di,0x1e86
    1593:	1e                   	push   ds
    1594:	57                   	push   di
    1595:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1598:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    159d:	06                   	push   es
    159e:	57                   	push   di
    159f:	9a 17 30 b6 15       	call   0x15b6:0x3017
    15a4:	bf 4e 1e             	mov    di,0x1e4e
    15a7:	1e                   	push   ds
    15a8:	57                   	push   di
    15a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15ac:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    15b1:	06                   	push   es
    15b2:	57                   	push   di
    15b3:	9a 17 30 ca 15       	call   0x15ca:0x3017
    15b8:	bf 5c 1e             	mov    di,0x1e5c
    15bb:	1e                   	push   ds
    15bc:	57                   	push   di
    15bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15c0:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    15c5:	06                   	push   es
    15c6:	57                   	push   di
    15c7:	9a 17 30 de 15       	call   0x15de:0x3017
    15cc:	bf 5c 1e             	mov    di,0x1e5c
    15cf:	1e                   	push   ds
    15d0:	57                   	push   di
    15d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15d4:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    15d9:	06                   	push   es
    15da:	57                   	push   di
    15db:	9a 17 30 f2 15       	call   0x15f2:0x3017
    15e0:	bf 78 1e             	mov    di,0x1e78
    15e3:	1e                   	push   ds
    15e4:	57                   	push   di
    15e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15e8:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    15ed:	06                   	push   es
    15ee:	57                   	push   di
    15ef:	9a 17 30 06 16       	call   0x1606:0x3017
    15f4:	bf 86 1e             	mov    di,0x1e86
    15f7:	1e                   	push   ds
    15f8:	57                   	push   di
    15f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15fc:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1601:	06                   	push   es
    1602:	57                   	push   di
    1603:	9a 17 30 1a 16       	call   0x161a:0x3017
    1608:	bf 86 1e             	mov    di,0x1e86
    160b:	1e                   	push   ds
    160c:	57                   	push   di
    160d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1610:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    1615:	06                   	push   es
    1616:	57                   	push   di
    1617:	9a 17 30 04 22       	call   0x2204:0x3017
    161c:	c9                   	leave
    161d:	ca 08 00             	retf   0x8
    1620:	55                   	push   bp
    1621:	89 e5                	mov    bp,sp
    1623:	31 c0                	xor    ax,ax
    1625:	9a 44 04 61 16       	call   0x1661:0x444
    162a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    162d:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    1633:	b0 00                	mov    al,0x0
    1635:	75 01                	jne    0x1638
    1637:	40                   	inc    ax
    1638:	50                   	push   ax
    1639:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    163e:	06                   	push   es
    163f:	57                   	push   di
    1640:	9a 75 12 c5 17       	call   0x17c5:0x1275
    1645:	ff 76 08             	push   WORD PTR [bp+0x8]
    1648:	ff 76 06             	push   WORD PTR [bp+0x6]
    164b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    164e:	06                   	push   es
    164f:	57                   	push   di
    1650:	9a 59 16 71 16       	call   0x1671:0x1659
    1655:	c9                   	leave
    1656:	ca 08 00             	retf   0x8
    1659:	55                   	push   bp
    165a:	89 e5                	mov    bp,sp
    165c:	31 c0                	xor    ax,ax
    165e:	9a 44 04 80 16       	call   0x1680:0x444
    1663:	ff 76 08             	push   WORD PTR [bp+0x8]
    1666:	ff 76 06             	push   WORD PTR [bp+0x6]
    1669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    166c:	06                   	push   es
    166d:	57                   	push   di
    166e:	9a 77 16 ac 16       	call   0x16ac:0x1677
    1673:	c9                   	leave
    1674:	ca 08 00             	retf   0x8
    1677:	55                   	push   bp
    1678:	89 e5                	mov    bp,sp
    167a:	b8 04 00             	mov    ax,0x4
    167d:	9a 44 04 c5 16       	call   0x16c5:0x444
    1682:	83 ec 04             	sub    sp,0x4
    1685:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1688:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    168d:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1691:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1695:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1698:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    169d:	06                   	push   es
    169e:	57                   	push   di
    169f:	9a fd 1a 42 4f       	call   0x4f42:0x1afd
    16a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16a7:	06                   	push   es
    16a8:	57                   	push   di
    16a9:	9a e4 17 e4 16       	call   0x16e4:0x17e4
    16ae:	c9                   	leave
    16af:	ca 08 00             	retf   0x8
    16b2:	01 23                	add    WORD PTR [bp+di],sp
    16b4:	00 00                	add    BYTE PTR [bx+si],al
    16b6:	00 00                	add    BYTE PTR [bx+si],al
    16b8:	ff 00                	inc    WORD PTR [bx+si]
    16ba:	00 00                	add    BYTE PTR [bx+si],al
    16bc:	55                   	push   bp
    16bd:	89 e5                	mov    bp,sp
    16bf:	b8 02 02             	mov    ax,0x202
    16c2:	9a 44 04 0f 17       	call   0x170f:0x444
    16c7:	81 ec 02 02          	sub    sp,0x202
    16cb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    16ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16d1:	26 89 85 c7 03       	mov    WORD PTR es:[di+0x3c7],ax
    16d6:	81 c7 50 03          	add    di,0x350
    16da:	06                   	push   es
    16db:	57                   	push   di
    16dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16df:	06                   	push   es
    16e0:	57                   	push   di
    16e1:	9a d6 21 ee 16       	call   0x16ee:0x21d6
    16e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e9:	06                   	push   es
    16ea:	57                   	push   di
    16eb:	9a e4 17 f8 16       	call   0x16f8:0x17e4
    16f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f3:	06                   	push   es
    16f4:	57                   	push   di
    16f5:	9a 4f 1a 80 24       	call   0x2480:0x1a4f
    16fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16fd:	81 c7 cd 03          	add    di,0x3cd
    1701:	06                   	push   es
    1702:	57                   	push   di
    1703:	8d be fe fe          	lea    di,[bp-0x102]
    1707:	16                   	push   ss
    1708:	57                   	push   di
    1709:	68 ff 00             	push   0xff
    170c:	9a e7 17 1f 17       	call   0x171f:0x17e7
    1711:	bf b2 16             	mov    di,0x16b2
    1714:	0e                   	push   cs
    1715:	57                   	push   di
    1716:	8d be fe fe          	lea    di,[bp-0x102]
    171a:	16                   	push   ss
    171b:	57                   	push   di
    171c:	9a 78 18 28 17       	call   0x1728:0x1878
    1721:	99                   	cwd
    1722:	bf b4 16             	mov    di,0x16b4
    1725:	9a 16 04 44 17       	call   0x1744:0x416
    172a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    172d:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1731:	76 3d                	jbe    0x1770
    1733:	8d be fe fe          	lea    di,[bp-0x102]
    1737:	16                   	push   ss
    1738:	57                   	push   di
    1739:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    173c:	30 e4                	xor    ah,ah
    173e:	50                   	push   ax
    173f:	6a 01                	push   0x1
    1741:	9a 75 19 6e 17       	call   0x176e:0x1975
    1746:	8d be fe fd          	lea    di,[bp-0x202]
    174a:	16                   	push   ss
    174b:	57                   	push   di
    174c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    174f:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    1754:	99                   	cwd
    1755:	52                   	push   dx
    1756:	50                   	push   ax
    1757:	9a a9 08 6c 1d       	call   0x1d6c:0x8a9
    175c:	8d be fe fe          	lea    di,[bp-0x102]
    1760:	16                   	push   ss
    1761:	57                   	push   di
    1762:	68 ff 00             	push   0xff
    1765:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1768:	30 e4                	xor    ah,ah
    176a:	50                   	push   ax
    176b:	9a 16 19 a6 17       	call   0x17a6:0x1916
    1770:	8d be fe fe          	lea    di,[bp-0x102]
    1774:	16                   	push   ss
    1775:	57                   	push   di
    1776:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1779:	06                   	push   es
    177a:	57                   	push   di
    177b:	9a 8c 1d 1e 18       	call   0x181e:0x1d8c
    1780:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1783:	26 c4 bd 5c 03       	les    di,DWORD PTR es:[di+0x35c]
    1788:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    178c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1790:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1794:	eb 03                	jmp    0x1799
    1796:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    1799:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    179c:	30 e4                	xor    ah,ah
    179e:	05 01 00             	add    ax,0x1
    17a1:	71 05                	jno    0x17a8
    17a3:	9a 3e 04 ed 17       	call   0x17ed:0x43e
    17a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17ab:	26 3b 85 c7 03       	cmp    ax,WORD PTR es:[di+0x3c7]
    17b0:	b0 00                	mov    al,0x0
    17b2:	75 01                	jne    0x17b5
    17b4:	40                   	inc    ax
    17b5:	50                   	push   ax
    17b6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    17b9:	30 e4                	xor    ah,ah
    17bb:	50                   	push   ax
    17bc:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    17c0:	06                   	push   es
    17c1:	57                   	push   di
    17c2:	9a 53 13 d0 17       	call   0x17d0:0x1353
    17c7:	89 c7                	mov    di,ax
    17c9:	8e c2                	mov    es,dx
    17cb:	06                   	push   es
    17cc:	57                   	push   di
    17cd:	9a 75 12 86 2b       	call   0x2b86:0x1275
    17d2:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    17d6:	75 be                	jne    0x1796
    17d8:	c9                   	leave
    17d9:	ca 06 00             	retf   0x6
    17dc:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    17e0:	ff                   	(bad)
    17e1:	7f 00                	jg     0x17e3
    17e3:	00 55 89             	add    BYTE PTR [di-0x77],dl
    17e6:	e5 b8                	in     ax,0xb8
    17e8:	08 01                	or     BYTE PTR [bx+di],al
    17ea:	9a 44 04 5d 19       	call   0x195d:0x444
    17ef:	81 ec 08 01          	sub    sp,0x108
    17f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17f6:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    17fb:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1800:	75 03                	jne    0x1805
    1802:	e9 3e 02             	jmp    0x1a43
    1805:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1808:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    180d:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1811:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1814:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    1819:	06                   	push   es
    181a:	57                   	push   di
    181b:	9a bf 17 39 18       	call   0x1839:0x17bf
    1820:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1823:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    1828:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    182c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    182f:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    1834:	06                   	push   es
    1835:	57                   	push   di
    1836:	9a e1 17 54 18       	call   0x1854:0x17e1
    183b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    183e:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
    1843:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1847:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    184a:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    184f:	06                   	push   es
    1850:	57                   	push   di
    1851:	9a bf 17 6f 18       	call   0x186f:0x17bf
    1856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1859:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
    185e:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1862:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1865:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    186a:	06                   	push   es
    186b:	57                   	push   di
    186c:	9a e1 17 92 18       	call   0x1892:0x17e1
    1871:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1874:	26 c4 bd 28 03       	les    di,DWORD PTR es:[di+0x328]
    1879:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    187c:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    187f:	8d be f8 fe          	lea    di,[bp-0x108]
    1883:	16                   	push   ss
    1884:	57                   	push   di
    1885:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1888:	26 c4 bd 4c 03       	les    di,DWORD PTR es:[di+0x34c]
    188d:	06                   	push   es
    188e:	57                   	push   di
    188f:	9a 53 1d 9c 18       	call   0x189c:0x1d53
    1894:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1897:	06                   	push   es
    1898:	57                   	push   di
    1899:	9a 8c 1d b2 18       	call   0x18b2:0x1d8c
    189e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18a1:	26 c4 bd 4c 03       	les    di,DWORD PTR es:[di+0x34c]
    18a6:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    18aa:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    18ad:	06                   	push   es
    18ae:	57                   	push   di
    18af:	9a bf 17 d5 18       	call   0x18d5:0x17bf
    18b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18b7:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    18bc:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    18bf:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    18c2:	8d be f8 fe          	lea    di,[bp-0x108]
    18c6:	16                   	push   ss
    18c7:	57                   	push   di
    18c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18cb:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    18d0:	06                   	push   es
    18d1:	57                   	push   di
    18d2:	9a 53 1d df 18       	call   0x18df:0x1d53
    18d7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    18da:	06                   	push   es
    18db:	57                   	push   di
    18dc:	9a 8c 1d f5 18       	call   0x18f5:0x1d8c
    18e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e4:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    18e9:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    18ed:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    18f0:	06                   	push   es
    18f1:	57                   	push   di
    18f2:	9a bf 17 bb 19       	call   0x19bb:0x17bf
    18f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18fa:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    18ff:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1902:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1905:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1908:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    190d:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    1912:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    1917:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    191a:	06                   	push   es
    191b:	57                   	push   di
    191c:	9a 1b 70 92 19       	call   0x1992:0x701b
    1921:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1924:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1929:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    192e:	26 ff 75 09          	push   WORD PTR es:[di+0x9]
    1932:	26 ff 75 07          	push   WORD PTR es:[di+0x7]
    1936:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1939:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    193e:	06                   	push   es
    193f:	57                   	push   di
    1940:	9a 99 20 68 1e       	call   0x1e68:0x2099
    1945:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1948:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    194d:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1952:	2d 01 00             	sub    ax,0x1
    1955:	83 da 00             	sbb    dx,0x0
    1958:	71 05                	jno    0x195f
    195a:	9a 3e 04 65 19       	call   0x1965:0x43e
    195f:	bf dc 17             	mov    di,0x17dc
    1962:	9a 16 04 d5 19       	call   0x19d5:0x416
    1967:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    196a:	31 c0                	xor    ax,ax
    196c:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    196f:	7f 36                	jg     0x19a7
    1971:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1974:	eb 03                	jmp    0x1979
    1976:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1979:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    197c:	99                   	cwd
    197d:	52                   	push   dx
    197e:	50                   	push   ax
    197f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1982:	99                   	cwd
    1983:	52                   	push   dx
    1984:	50                   	push   ax
    1985:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1988:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    198d:	06                   	push   es
    198e:	57                   	push   di
    198f:	9a 30 6e 9d 19       	call   0x199d:0x6e30
    1994:	50                   	push   ax
    1995:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1998:	06                   	push   es
    1999:	57                   	push   di
    199a:	9a c9 70 0a 1a       	call   0x1a0a:0x70c9
    199f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    19a2:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    19a5:	75 cf                	jne    0x1976
    19a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19aa:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    19af:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    19b3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    19b6:	06                   	push   es
    19b7:	57                   	push   di
    19b8:	9a bf 17 33 1a       	call   0x1a33:0x17bf
    19bd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    19c0:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    19c5:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    19ca:	2d 01 00             	sub    ax,0x1
    19cd:	83 da 00             	sbb    dx,0x0
    19d0:	71 05                	jno    0x19d7
    19d2:	9a 3e 04 dd 19       	call   0x19dd:0x43e
    19d7:	bf dc 17             	mov    di,0x17dc
    19da:	9a 16 04 58 1a       	call   0x1a58:0x416
    19df:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    19e2:	31 c0                	xor    ax,ax
    19e4:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    19e7:	7f 36                	jg     0x1a1f
    19e9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19ec:	eb 03                	jmp    0x19f1
    19ee:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    19f1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19f4:	99                   	cwd
    19f5:	52                   	push   dx
    19f6:	50                   	push   ax
    19f7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19fa:	99                   	cwd
    19fb:	52                   	push   dx
    19fc:	50                   	push   ax
    19fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a00:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1a05:	06                   	push   es
    1a06:	57                   	push   di
    1a07:	9a 8b 6e 15 1a       	call   0x1a15:0x6e8b
    1a0c:	50                   	push   ax
    1a0d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1a10:	06                   	push   es
    1a11:	57                   	push   di
    1a12:	9a a3 74 41 1a       	call   0x1a41:0x74a3
    1a17:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a1a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1a1d:	75 cf                	jne    0x19ee
    1a1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a22:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1a27:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1a2b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1a2e:	06                   	push   es
    1a2f:	57                   	push   di
    1a30:	9a e1 17 77 1b       	call   0x1b77:0x17e1
    1a35:	6a 00                	push   0x0
    1a37:	6a 05                	push   0x5
    1a39:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1a3c:	06                   	push   es
    1a3d:	57                   	push   di
    1a3e:	9a 45 73 98 1a       	call   0x1a98:0x7345
    1a43:	c9                   	leave
    1a44:	ca 04 00             	retf   0x4
    1a47:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1a4b:	ff                   	(bad)
    1a4c:	7f 00                	jg     0x1a4e
    1a4e:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1a51:	e5 b8                	in     ax,0xb8
    1a53:	0c 01                	or     al,0x1
    1a55:	9a 44 04 b2 1a       	call   0x1ab2:0x444
    1a5a:	81 ec 0c 01          	sub    sp,0x10c
    1a5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a61:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    1a66:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1a6b:	75 03                	jne    0x1a70
    1a6d:	e9 cd 00             	jmp    0x1b3d
    1a70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a73:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    1a78:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1a7b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1a7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a81:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1a86:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    1a8b:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    1a90:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1a93:	06                   	push   es
    1a94:	57                   	push   di
    1a95:	9a 1b 70 21 1b       	call   0x1b21:0x701b
    1a9a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1a9d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1aa2:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1aa7:	2d 01 00             	sub    ax,0x1
    1aaa:	83 da 00             	sbb    dx,0x0
    1aad:	71 05                	jno    0x1ab4
    1aaf:	9a 3e 04 ba 1a       	call   0x1aba:0x43e
    1ab4:	bf 47 1a             	mov    di,0x1a47
    1ab7:	9a 16 04 e6 1a       	call   0x1ae6:0x416
    1abc:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1abf:	31 c0                	xor    ax,ax
    1ac1:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1ac4:	7f 77                	jg     0x1b3d
    1ac6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ac9:	eb 03                	jmp    0x1ace
    1acb:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1ace:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ad1:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    1ad6:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    1adb:	2d 01 00             	sub    ax,0x1
    1ade:	83 da 00             	sbb    dx,0x0
    1ae1:	71 05                	jno    0x1ae8
    1ae3:	9a 3e 04 ee 1a       	call   0x1aee:0x43e
    1ae8:	bf 47 1a             	mov    di,0x1a47
    1aeb:	9a 16 04 5f 1b       	call   0x1b5f:0x416
    1af0:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1af3:	31 c0                	xor    ax,ax
    1af5:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1af8:	7f 3b                	jg     0x1b35
    1afa:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1afd:	eb 03                	jmp    0x1b02
    1aff:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1b02:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b05:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b08:	8d be f4 fe          	lea    di,[bp-0x10c]
    1b0c:	16                   	push   ss
    1b0d:	57                   	push   di
    1b0e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b11:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b17:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1b1c:	06                   	push   es
    1b1d:	57                   	push   di
    1b1e:	9a 68 9a 2b 1b       	call   0x1b2b:0x9a68
    1b23:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b26:	06                   	push   es
    1b27:	57                   	push   di
    1b28:	9a 08 9b a0 1b       	call   0x1ba0:0x9b08
    1b2d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b30:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1b33:	75 ca                	jne    0x1aff
    1b35:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b38:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1b3b:	75 8e                	jne    0x1acb
    1b3d:	c9                   	leave
    1b3e:	ca 04 00             	retf   0x4
    1b41:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1b45:	ff                   	(bad)
    1b46:	7f 00                	jg     0x1b48
    1b48:	00 03                	add    BYTE PTR [bp+di],al
    1b4a:	43                   	inc    bx
    1b4b:	2c 30                	sub    al,0x30
    1b4d:	03 23                	add    sp,WORD PTR [bp+di]
    1b4f:	41                   	inc    cx
    1b50:	63 01                	arpl   WORD PTR [bx+di],ax
    1b52:	20 02                	and    BYTE PTR [bp+si],al
    1b54:	30 2c                	xor    BYTE PTR [si],ch
    1b56:	55                   	push   bp
    1b57:	89 e5                	mov    bp,sp
    1b59:	b8 0e 03             	mov    ax,0x30e
    1b5c:	9a 44 04 93 1b       	call   0x1b93:0x444
    1b61:	81 ec 0e 03          	sub    sp,0x30e
    1b65:	bf fa 1d             	mov    di,0x1dfa
    1b68:	1e                   	push   ds
    1b69:	57                   	push   di
    1b6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b6d:	26 c4 bd 4c 03       	les    di,DWORD PTR es:[di+0x34c]
    1b72:	06                   	push   es
    1b73:	57                   	push   di
    1b74:	9a 8c 1d be 1b       	call   0x1bbe:0x1d8c
    1b79:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b7f:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1b82:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1b85:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    1b8a:	03 06 4e 01          	add    ax,WORD PTR ds:0x14e
    1b8e:	71 05                	jno    0x1b95
    1b90:	9a 3e 04 d8 1b       	call   0x1bd8:0x43e
    1b95:	99                   	cwd
    1b96:	52                   	push   dx
    1b97:	50                   	push   ax
    1b98:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1b9b:	06                   	push   es
    1b9c:	57                   	push   di
    1b9d:	9a 1b 70 3b 1c       	call   0x1c3b:0x701b
    1ba2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ba5:	26 80 bd c6 03 00    	cmp    BYTE PTR es:[di+0x3c6],0x0
    1bab:	b0 00                	mov    al,0x0
    1bad:	75 01                	jne    0x1bb0
    1baf:	40                   	inc    ax
    1bb0:	50                   	push   ax
    1bb1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1bb4:	26 c4 bd 96 01       	les    di,DWORD PTR es:[di+0x196]
    1bb9:	06                   	push   es
    1bba:	57                   	push   di
    1bbb:	9a 77 1c 5c 2e       	call   0x2e5c:0x1c77
    1bc0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1bc3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1bc8:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1bcd:	2d 01 00             	sub    ax,0x1
    1bd0:	83 da 00             	sbb    dx,0x0
    1bd3:	71 05                	jno    0x1bda
    1bd5:	9a 3e 04 e0 1b       	call   0x1be0:0x43e
    1bda:	bf 41 1b             	mov    di,0x1b41
    1bdd:	9a 16 04 0c 1c       	call   0x1c0c:0x416
    1be2:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1be5:	31 c0                	xor    ax,ax
    1be7:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1bea:	7f 61                	jg     0x1c4d
    1bec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1bef:	eb 03                	jmp    0x1bf4
    1bf1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1bf4:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1bf7:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    1bfc:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    1c01:	2d 01 00             	sub    ax,0x1
    1c04:	83 da 00             	sbb    dx,0x0
    1c07:	71 05                	jno    0x1c0e
    1c09:	9a 3e 04 14 1c       	call   0x1c14:0x43e
    1c0e:	bf 41 1b             	mov    di,0x1b41
    1c11:	9a 16 04 5f 1c       	call   0x1c5f:0x416
    1c16:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1c19:	31 c0                	xor    ax,ax
    1c1b:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1c1e:	7f 25                	jg     0x1c45
    1c20:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c23:	eb 03                	jmp    0x1c28
    1c25:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1c28:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c2b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c2e:	bf 41 1b             	mov    di,0x1b41
    1c31:	0e                   	push   cs
    1c32:	57                   	push   di
    1c33:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1c36:	06                   	push   es
    1c37:	57                   	push   di
    1c38:	9a 08 9b 7a 1c       	call   0x1c7a:0x9b08
    1c3d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1c40:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1c43:	75 e0                	jne    0x1c25
    1c45:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c48:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1c4b:	75 a4                	jne    0x1bf1
    1c4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c50:	26 8b 85 c9 03       	mov    ax,WORD PTR es:[di+0x3c9]
    1c55:	b9 01 00             	mov    cx,0x1
    1c58:	f7 e9                	imul   cx
    1c5a:	71 05                	jno    0x1c61
    1c5c:	9a 3e 04 69 1c       	call   0x1c69:0x43e
    1c61:	05 01 00             	add    ax,0x1
    1c64:	71 05                	jno    0x1c6b
    1c66:	9a 3e 04 8c 1c       	call   0x1c8c:0x43e
    1c6b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1c6e:	6a 00                	push   0x0
    1c70:	6a 00                	push   0x0
    1c72:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1c75:	06                   	push   es
    1c76:	57                   	push   di
    1c77:	9a 30 6e db 1c       	call   0x1cdb:0x6e30
    1c7c:	8b d0                	mov    dx,ax
    1c7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c81:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1c85:	2b c2                	sub    ax,dx
    1c87:	71 05                	jno    0x1c8e
    1c89:	9a 3e 04 ad 1c       	call   0x1cad:0x43e
    1c8e:	99                   	cwd
    1c8f:	f7 7e fa             	idiv   WORD PTR [bp-0x6]
    1c92:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1c95:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1c98:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1c9d:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1ca2:	2d 01 00             	sub    ax,0x1
    1ca5:	83 da 00             	sbb    dx,0x0
    1ca8:	71 05                	jno    0x1caf
    1caa:	9a 3e 04 b5 1c       	call   0x1cb5:0x43e
    1caf:	bf 41 1b             	mov    di,0x1b41
    1cb2:	9a 16 04 fd 1c       	call   0x1cfd:0x416
    1cb7:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1cba:	b8 01 00             	mov    ax,0x1
    1cbd:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1cc0:	7f 23                	jg     0x1ce5
    1cc2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1cc5:	eb 03                	jmp    0x1cca
    1cc7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1cca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ccd:	99                   	cwd
    1cce:	52                   	push   dx
    1ccf:	50                   	push   ax
    1cd0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1cd3:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1cd6:	06                   	push   es
    1cd7:	57                   	push   di
    1cd8:	9a c9 70 7b 1d       	call   0x1d7b:0x70c9
    1cdd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ce0:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1ce3:	75 e2                	jne    0x1cc7
    1ce5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1ce8:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1ced:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1cf2:	2d 01 00             	sub    ax,0x1
    1cf5:	83 da 00             	sbb    dx,0x0
    1cf8:	71 05                	jno    0x1cff
    1cfa:	9a 3e 04 05 1d       	call   0x1d05:0x43e
    1cff:	bf 41 1b             	mov    di,0x1b41
    1d02:	9a 16 04 2d 1d       	call   0x1d2d:0x416
    1d07:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1d0a:	b8 01 00             	mov    ax,0x1
    1d0d:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1d10:	7f 73                	jg     0x1d85
    1d12:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d15:	eb 03                	jmp    0x1d1a
    1d17:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d1a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1d1d:	6a 00                	push   0x0
    1d1f:	8d be f2 fd          	lea    di,[bp-0x20e]
    1d23:	16                   	push   ss
    1d24:	57                   	push   di
    1d25:	bf 4d 1b             	mov    di,0x1b4d
    1d28:	0e                   	push   cs
    1d29:	57                   	push   di
    1d2a:	9a cd 17 51 1d       	call   0x1d51:0x17cd
    1d2f:	8d be f2 fe          	lea    di,[bp-0x10e]
    1d33:	16                   	push   ss
    1d34:	57                   	push   di
    1d35:	bf 49 1b             	mov    di,0x1b49
    1d38:	0e                   	push   cs
    1d39:	57                   	push   di
    1d3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d3d:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    1d42:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1d47:	06                   	push   es
    1d48:	57                   	push   di
    1d49:	9a 19 15 fb 1d       	call   0x1dfb:0x1519
    1d4e:	9a 4c 18 5b 1d       	call   0x1d5b:0x184c
    1d53:	bf 51 1b             	mov    di,0x1b51
    1d56:	0e                   	push   cs
    1d57:	57                   	push   di
    1d58:	9a 4c 18 71 1d       	call   0x1d71:0x184c
    1d5d:	8d be f2 fc          	lea    di,[bp-0x30e]
    1d61:	16                   	push   ss
    1d62:	57                   	push   di
    1d63:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d66:	99                   	cwd
    1d67:	52                   	push   dx
    1d68:	50                   	push   ax
    1d69:	9a a9 08 e2 1d       	call   0x1de2:0x8a9
    1d6e:	9a 4c 18 a3 1d       	call   0x1da3:0x184c
    1d73:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1d76:	06                   	push   es
    1d77:	57                   	push   di
    1d78:	9a 08 9b 05 1e       	call   0x1e05:0x9b08
    1d7d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d80:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1d83:	75 92                	jne    0x1d17
    1d85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d88:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    1d8d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1d92:	06                   	push   es
    1d93:	57                   	push   di
    1d94:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d97:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1d9b:	2d 01 00             	sub    ax,0x1
    1d9e:	71 05                	jno    0x1da5
    1da0:	9a 3e 04 d1 1d       	call   0x1dd1:0x43e
    1da5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1da8:	b8 01 00             	mov    ax,0x1
    1dab:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1dae:	7f 5f                	jg     0x1e0f
    1db0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1db3:	eb 03                	jmp    0x1db8
    1db5:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1db8:	6a 00                	push   0x0
    1dba:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1dbd:	8d be f2 fc          	lea    di,[bp-0x30e]
    1dc1:	16                   	push   ss
    1dc2:	57                   	push   di
    1dc3:	8d be f2 fd          	lea    di,[bp-0x20e]
    1dc7:	16                   	push   ss
    1dc8:	57                   	push   di
    1dc9:	bf 53 1b             	mov    di,0x1b53
    1dcc:	0e                   	push   cs
    1dcd:	57                   	push   di
    1dce:	9a cd 17 e7 1d       	call   0x1de7:0x17cd
    1dd3:	8d be f2 fe          	lea    di,[bp-0x10e]
    1dd7:	16                   	push   ss
    1dd8:	57                   	push   di
    1dd9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ddc:	99                   	cwd
    1ddd:	52                   	push   dx
    1dde:	50                   	push   ax
    1ddf:	9a a9 08 67 20       	call   0x2067:0x8a9
    1de4:	9a 4c 18 40 1e       	call   0x1e40:0x184c
    1de9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dec:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    1df1:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1df6:	06                   	push   es
    1df7:	57                   	push   di
    1df8:	9a 19 15 86 25       	call   0x2586:0x1519
    1dfd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1e00:	06                   	push   es
    1e01:	57                   	push   di
    1e02:	9a 08 9b f2 1e       	call   0x1ef2:0x9b08
    1e07:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e0a:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1e0d:	75 a6                	jne    0x1db5
    1e0f:	c9                   	leave
    1e10:	ca 08 00             	retf   0x8
    1e13:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1e17:	ff                   	(bad)
    1e18:	7f 00                	jg     0x1e1a
    1e1a:	00 0a                	add    BYTE PTR [bp+si],cl
    1e1c:	45                   	inc    bp
    1e1d:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e1e:	74 72                	je     0x1e92
    1e20:	65 70 72             	gs jo  0x1e95
    1e23:	69 73 65 04 45       	imul   si,WORD PTR [bp+di+0x65],0x4504
    1e28:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e29:	74 2e                	je     0x1e59
    1e2b:	02 20                	add    ah,BYTE PTR [bx+si]
    1e2d:	35 02 45             	xor    ax,0x4502
    1e30:	2e 03 23             	add    sp,WORD PTR cs:[bp+di]
    1e33:	41                   	inc    cx
    1e34:	63 01                	arpl   WORD PTR [bx+di],ax
    1e36:	20 55 89             	and    BYTE PTR [di-0x77],dl
    1e39:	e5 b8                	in     ax,0xb8
    1e3b:	0c 05                	or     al,0x5
    1e3d:	9a 44 04 90 1e       	call   0x1e90:0x444
    1e42:	81 ec 0c 05          	sub    sp,0x50c
    1e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e49:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1e4e:	89 be f6 fc          	mov    WORD PTR [bp-0x30a],di
    1e52:	8c 86 f8 fc          	mov    WORD PTR [bp-0x308],es
    1e56:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1e5a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1e5e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1e63:	06                   	push   es
    1e64:	57                   	push   di
    1e65:	9a 99 20 84 1e       	call   0x1e84:0x2099
    1e6a:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    1e6e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1e73:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1e77:	89 be f2 fc          	mov    WORD PTR [bp-0x30e],di
    1e7b:	8c 86 f4 fc          	mov    WORD PTR [bp-0x30c],es
    1e7f:	06                   	push   es
    1e80:	57                   	push   di
    1e81:	9a cc 11 bd 1e       	call   0x1ebd:0x11cc
    1e86:	b9 0d 00             	mov    cx,0xd
    1e89:	f7 e9                	imul   cx
    1e8b:	71 05                	jno    0x1e92
    1e8d:	9a 3e 04 a9 1e       	call   0x1ea9:0x43e
    1e92:	99                   	cwd
    1e93:	b9 0a 00             	mov    cx,0xa
    1e96:	f7 f9                	idiv   cx
    1e98:	99                   	cwd
    1e99:	89 86 ee fc          	mov    WORD PTR [bp-0x312],ax
    1e9d:	89 96 f0 fc          	mov    WORD PTR [bp-0x310],dx
    1ea1:	9b db 86 ee fc       	fild   DWORD PTR [bp-0x312]
    1ea6:	9a 2f 10 b1 1e       	call   0x1eb1:0x102f
    1eab:	bf 13 1e             	mov    di,0x1e13
    1eae:	9a 16 04 0c 1f       	call   0x1f0c:0x416
    1eb3:	50                   	push   ax
    1eb4:	c4 be f2 fc          	les    di,DWORD PTR [bp-0x30e]
    1eb8:	06                   	push   es
    1eb9:	57                   	push   di
    1eba:	9a f5 11 c8 1e       	call   0x1ec8:0x11f5
    1ebf:	c4 be f2 fc          	les    di,DWORD PTR [bp-0x30e]
    1ec3:	06                   	push   es
    1ec4:	57                   	push   di
    1ec5:	9a 1a 12 d6 1e       	call   0x1ed6:0x121a
    1eca:	0c 01                	or     al,0x1
    1ecc:	50                   	push   ax
    1ecd:	c4 be f2 fc          	les    di,DWORD PTR [bp-0x30e]
    1ed1:	06                   	push   es
    1ed2:	57                   	push   di
    1ed3:	9a 33 12 e3 1e       	call   0x1ee3:0x1233
    1ed8:	6a 02                	push   0x2
    1eda:	c4 be f2 fc          	les    di,DWORD PTR [bp-0x30e]
    1ede:	06                   	push   es
    1edf:	57                   	push   di
    1ee0:	9a 78 12 5e 1f       	call   0x1f5e:0x1278
    1ee5:	6a 00                	push   0x0
    1ee7:	6a 01                	push   0x1
    1ee9:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    1eed:	06                   	push   es
    1eee:	57                   	push   di
    1eef:	9a 30 6e 77 20       	call   0x2077:0x6e30
    1ef4:	99                   	cwd
    1ef5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ef8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1efb:	bf 1b 1e             	mov    di,0x1e1b
    1efe:	0e                   	push   cs
    1eff:	57                   	push   di
    1f00:	8d be fa fe          	lea    di,[bp-0x106]
    1f04:	16                   	push   ss
    1f05:	57                   	push   di
    1f06:	68 ff 00             	push   0xff
    1f09:	9a e7 17 1f 1f       	call   0x1f1f:0x17e7
    1f0e:	bf 26 1e             	mov    di,0x1e26
    1f11:	0e                   	push   cs
    1f12:	57                   	push   di
    1f13:	8d be fa fd          	lea    di,[bp-0x206]
    1f17:	16                   	push   ss
    1f18:	57                   	push   di
    1f19:	68 ff 00             	push   0xff
    1f1c:	9a e7 17 33 1f       	call   0x1f33:0x17e7
    1f21:	8d be fa fe          	lea    di,[bp-0x106]
    1f25:	16                   	push   ss
    1f26:	57                   	push   di
    1f27:	8d be fa fc          	lea    di,[bp-0x306]
    1f2b:	16                   	push   ss
    1f2c:	57                   	push   di
    1f2d:	68 ff 00             	push   0xff
    1f30:	9a e7 17 44 1f       	call   0x1f44:0x17e7
    1f35:	8d be f6 fb          	lea    di,[bp-0x40a]
    1f39:	16                   	push   ss
    1f3a:	57                   	push   di
    1f3b:	8d be fa fe          	lea    di,[bp-0x106]
    1f3f:	16                   	push   ss
    1f40:	57                   	push   di
    1f41:	9a cd 17 4e 1f       	call   0x1f4e:0x17cd
    1f46:	bf 2b 1e             	mov    di,0x1e2b
    1f49:	0e                   	push   cs
    1f4a:	57                   	push   di
    1f4b:	9a 4c 18 76 1f       	call   0x1f76:0x184c
    1f50:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    1f54:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1f59:	06                   	push   es
    1f5a:	57                   	push   di
    1f5b:	9a 03 20 bf 1f       	call   0x1fbf:0x2003
    1f60:	99                   	cwd
    1f61:	8b c8                	mov    cx,ax
    1f63:	8b da                	mov    bx,dx
    1f65:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1f68:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1f6b:	2d 0a 00             	sub    ax,0xa
    1f6e:	83 da 00             	sbb    dx,0x0
    1f71:	71 05                	jno    0x1f78
    1f73:	9a 3e 04 94 1f       	call   0x1f94:0x43e
    1f78:	3b d3                	cmp    dx,bx
    1f7a:	7c 06                	jl     0x1f82
    1f7c:	7f 18                	jg     0x1f96
    1f7e:	3b c1                	cmp    ax,cx
    1f80:	73 14                	jae    0x1f96
    1f82:	8d be fa fd          	lea    di,[bp-0x206]
    1f86:	16                   	push   ss
    1f87:	57                   	push   di
    1f88:	8d be fa fc          	lea    di,[bp-0x306]
    1f8c:	16                   	push   ss
    1f8d:	57                   	push   di
    1f8e:	68 ff 00             	push   0xff
    1f91:	9a e7 17 a5 1f       	call   0x1fa5:0x17e7
    1f96:	8d be f6 fb          	lea    di,[bp-0x40a]
    1f9a:	16                   	push   ss
    1f9b:	57                   	push   di
    1f9c:	8d be fa fd          	lea    di,[bp-0x206]
    1fa0:	16                   	push   ss
    1fa1:	57                   	push   di
    1fa2:	9a cd 17 af 1f       	call   0x1faf:0x17cd
    1fa7:	bf 2b 1e             	mov    di,0x1e2b
    1faa:	0e                   	push   cs
    1fab:	57                   	push   di
    1fac:	9a 4c 18 d7 1f       	call   0x1fd7:0x184c
    1fb1:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    1fb5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1fba:	06                   	push   es
    1fbb:	57                   	push   di
    1fbc:	9a 03 20 81 2e       	call   0x2e81:0x2003
    1fc1:	99                   	cwd
    1fc2:	8b c8                	mov    cx,ax
    1fc4:	8b da                	mov    bx,dx
    1fc6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1fc9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1fcc:	2d 0a 00             	sub    ax,0xa
    1fcf:	83 da 00             	sbb    dx,0x0
    1fd2:	71 05                	jno    0x1fd9
    1fd4:	9a 3e 04 f4 1f       	call   0x1ff4:0x43e
    1fd9:	3b d3                	cmp    dx,bx
    1fdb:	7c 06                	jl     0x1fe3
    1fdd:	7f 17                	jg     0x1ff6
    1fdf:	3b c1                	cmp    ax,cx
    1fe1:	73 13                	jae    0x1ff6
    1fe3:	bf 2e 1e             	mov    di,0x1e2e
    1fe6:	0e                   	push   cs
    1fe7:	57                   	push   di
    1fe8:	8d be fa fc          	lea    di,[bp-0x306]
    1fec:	16                   	push   ss
    1fed:	57                   	push   di
    1fee:	68 ff 00             	push   0xff
    1ff1:	9a e7 17 0f 20       	call   0x200f:0x17e7
    1ff6:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    1ffa:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1fff:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2004:	2d 01 00             	sub    ax,0x1
    2007:	83 da 00             	sbb    dx,0x0
    200a:	71 05                	jno    0x2011
    200c:	9a 3e 04 17 20       	call   0x2017:0x43e
    2011:	bf 13 1e             	mov    di,0x1e13
    2014:	9a 16 04 41 20       	call   0x2041:0x416
    2019:	89 86 f4 fc          	mov    WORD PTR [bp-0x30c],ax
    201d:	b8 01 00             	mov    ax,0x1
    2020:	3b 86 f4 fc          	cmp    ax,WORD PTR [bp-0x30c]
    2024:	7f 5c                	jg     0x2082
    2026:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2029:	eb 03                	jmp    0x202e
    202b:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    202e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2031:	6a 00                	push   0x0
    2033:	8d be f4 fb          	lea    di,[bp-0x40c]
    2037:	16                   	push   ss
    2038:	57                   	push   di
    2039:	bf 31 1e             	mov    di,0x1e31
    203c:	0e                   	push   cs
    203d:	57                   	push   di
    203e:	9a cd 17 4c 20       	call   0x204c:0x17cd
    2043:	8d be fa fc          	lea    di,[bp-0x306]
    2047:	16                   	push   ss
    2048:	57                   	push   di
    2049:	9a 4c 18 56 20       	call   0x2056:0x184c
    204e:	bf 35 1e             	mov    di,0x1e35
    2051:	0e                   	push   cs
    2052:	57                   	push   di
    2053:	9a 4c 18 6c 20       	call   0x206c:0x184c
    2058:	8d be f4 fa          	lea    di,[bp-0x50c]
    205c:	16                   	push   ss
    205d:	57                   	push   di
    205e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2061:	99                   	cwd
    2062:	52                   	push   dx
    2063:	50                   	push   ax
    2064:	9a a9 08 ab 25       	call   0x25ab:0x8a9
    2069:	9a 4c 18 93 20       	call   0x2093:0x184c
    206e:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    2072:	06                   	push   es
    2073:	57                   	push   di
    2074:	9a 08 9b 2a 21       	call   0x212a:0x9b08
    2079:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    207c:	3b 86 f4 fc          	cmp    ax,WORD PTR [bp-0x30c]
    2080:	75 a9                	jne    0x202b
    2082:	c9                   	leave
    2083:	ca 04 00             	retf   0x4
    2086:	03 23                	add    sp,WORD PTR [bp+di]
    2088:	41                   	inc    cx
    2089:	64 55                	fs push bp
    208b:	89 e5                	mov    bp,sp
    208d:	b8 16 02             	mov    ax,0x216
    2090:	9a 44 04 c0 20       	call   0x20c0:0x444
    2095:	81 ec 16 02          	sub    sp,0x216
    2099:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    209c:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    20a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20a3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    20a6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    20a9:	ff 76 14             	push   WORD PTR [bp+0x14]
    20ac:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    20af:	26 ff 35             	push   WORD PTR es:[di]
    20b2:	8d be ea fd          	lea    di,[bp-0x216]
    20b6:	16                   	push   ss
    20b7:	57                   	push   di
    20b8:	bf 86 20             	mov    di,0x2086
    20bb:	0e                   	push   cs
    20bc:	57                   	push   di
    20bd:	9a cd 17 20 21       	call   0x2120:0x17cd
    20c2:	8d be ea fe          	lea    di,[bp-0x116]
    20c6:	16                   	push   ss
    20c7:	57                   	push   di
    20c8:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    20cb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    20cf:	26 ff b5 cb 03       	push   WORD PTR es:[di+0x3cb]
    20d4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    20d7:	06                   	push   es
    20d8:	57                   	push   di
    20d9:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    20dc:	06                   	push   es
    20dd:	57                   	push   di
    20de:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    20e1:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    20e5:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    20ea:	06                   	push   es
    20eb:	57                   	push   di
    20ec:	9a 9b 3b f8 21       	call   0x21f8:0x3b9b
    20f1:	89 c7                	mov    di,ax
    20f3:	8e c2                	mov    es,dx
    20f5:	06                   	push   es
    20f6:	57                   	push   di
    20f7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20fa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    20fe:	9b db 7e f2          	fstp   TBYTE PTR [bp-0xe]
    2102:	8d 46 f2             	lea    ax,[bp-0xe]
    2105:	8c d2                	mov    dx,ss
    2107:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    210a:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    210d:	c6 46 ee 03          	mov    BYTE PTR [bp-0x12],0x3
    2111:	8d 7e ea             	lea    di,[bp-0x16]
    2114:	16                   	push   ss
    2115:	57                   	push   di
    2116:	6a 00                	push   0x0
    2118:	9a 93 30 01 42       	call   0x4201:0x3093
    211d:	9a 4c 18 df 21       	call   0x21df:0x184c
    2122:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2125:	06                   	push   es
    2126:	57                   	push   di
    2127:	9a 08 9b bd 25       	call   0x25bd:0x9b08
    212c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    212f:	26 ff 05             	inc    WORD PTR es:[di]
    2132:	c9                   	leave
    2133:	ca 10 00             	retf   0x10
    2136:	03 30                	add    si,WORD PTR [bx+si]
    2138:	2c 30                	sub    al,0x30
    213a:	03 23                	add    sp,WORD PTR [bp+di]
    213c:	41                   	inc    cx
    213d:	63 01                	arpl   WORD PTR [bx+di],ax
    213f:	20 06 25 31          	and    BYTE PTR ds:0x3125,al
    2143:	30 2e 32 66          	xor    BYTE PTR ds:0x6632,ch
    2147:	13 54 72             	adc    dx,WORD PTR [si+0x72]
    214a:	65 73 6f             	gs jae 0x21bc
    214d:	72 65                	jb     0x21b4
    214f:	72 69                	jb     0x21ba
    2151:	65 50                	gs push ax
    2153:	6c                   	ins    BYTE PTR es:[di],dx
    2154:	75 73                	jne    0x21c9
    2156:	4d                   	dec    bp
    2157:	6f                   	outs   dx,WORD PTR ds:[si]
    2158:	69 6e 73 0d 45       	imul   bp,WORD PTR [bp+0x73],0x450d
    215d:	6e                   	outs   dx,BYTE PTR ds:[si]
    215e:	64 65 74 74          	fs gs je 0x21d6
    2162:	65 6d                	gs ins WORD PTR es:[di],dx
    2164:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2166:	74 50                	je     0x21b8
    2168:	63 0d                	arpl   WORD PTR [di],cx
    216a:	56                   	push   si
    216b:	61                   	popa
    216c:	6c                   	ins    BYTE PTR es:[di],dx
    216d:	65 75 72             	gs jne 0x21e2
    2170:	41                   	inc    cx
    2171:	6a 6f                	push   0x6f
    2173:	75 74                	jne    0x21e9
    2175:	65 65 03 45 42       	gs add ax,WORD PTR gs:[di+0x42]
    217a:	45                   	inc    bp
    217b:	03 43 41             	add    ax,WORD PTR [bp+di+0x41]
    217e:	46                   	inc    si
    217f:	11 52 65             	adc    WORD PTR [bp+si+0x65],dx
    2182:	73 75                	jae    0x21f9
    2184:	6c                   	ins    BYTE PTR es:[di],dx
    2185:	74 61                	je     0x21e8
    2187:	74 43                	je     0x21cc
    2189:	6f                   	outs   dx,WORD PTR ds:[si]
    218a:	6d                   	ins    WORD PTR es:[di],dx
    218b:	70 74                	jo     0x2201
    218d:	61                   	popa
    218e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    2191:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    2194:	73 75                	jae    0x220b
    2196:	6c                   	ins    BYTE PTR es:[di],dx
    2197:	74 61                	je     0x21fa
    2199:	74 4e                	je     0x21e9
    219b:	65 74 0d             	gs je  0x21ab
    219e:	52                   	push   dx
    219f:	65 6e                	outs   dx,BYTE PTR gs:[si]
    21a1:	74 61                	je     0x2204
    21a3:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    21a6:	69 74 65 43 70       	imul   si,WORD PTR [si+0x65],0x7043
    21ab:	0d 52 6f             	or     ax,0x6f52
    21ae:	74 61                	je     0x2211
    21b0:	74 69                	je     0x221b
    21b2:	6f                   	outs   dx,WORD PTR ds:[si]
    21b3:	6e                   	outs   dx,BYTE PTR ds:[si]
    21b4:	41                   	inc    cx
    21b5:	63 74 69             	arpl   WORD PTR [si+0x69],si
    21b8:	66 0b 45 66          	or     eax,DWORD PTR [di+0x66]
    21bc:	66 65 74 4c          	data32 gs je 0x220c
    21c0:	65 76 69             	gs jbe 0x222c
    21c3:	65 72 10             	gs jb  0x21d6
    21c6:	41                   	inc    cx
    21c7:	67 65 4d             	addr32 gs dec bp
    21ca:	6f                   	outs   dx,WORD PTR ds:[si]
    21cb:	79 65                	jns    0x2232
    21cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    21ce:	4d                   	dec    bp
    21cf:	61                   	popa
    21d0:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    21d3:	6e                   	outs   dx,BYTE PTR ds:[si]
    21d4:	65 73 55             	gs jae 0x222c
    21d7:	89 e5                	mov    bp,sp
    21d9:	b8 04 03             	mov    ax,0x304
    21dc:	9a 44 04 67 25       	call   0x2567:0x444
    21e1:	81 ec 04 03          	sub    sp,0x304
    21e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e8:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    21ed:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    21f0:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    21f3:	06                   	push   es
    21f4:	57                   	push   di
    21f5:	9a d2 31 1a 22       	call   0x221a:0x31d2
    21fa:	6a 01                	push   0x1
    21fc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    21ff:	06                   	push   es
    2200:	57                   	push   di
    2201:	9a fb 2f 10 22       	call   0x2210:0x2ffb
    2206:	6a 00                	push   0x0
    2208:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    220b:	06                   	push   es
    220c:	57                   	push   di
    220d:	9a d2 2e 3b 22       	call   0x223b:0x2ed2
    2212:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2215:	06                   	push   es
    2216:	57                   	push   di
    2217:	9a bf 31 2f 22       	call   0x222f:0x31bf
    221c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    221f:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    2224:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2227:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    222a:	06                   	push   es
    222b:	57                   	push   di
    222c:	9a d2 31 51 22       	call   0x2251:0x31d2
    2231:	6a 01                	push   0x1
    2233:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2236:	06                   	push   es
    2237:	57                   	push   di
    2238:	9a fb 2f 47 22       	call   0x2247:0x2ffb
    223d:	6a 00                	push   0x0
    223f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2242:	06                   	push   es
    2243:	57                   	push   di
    2244:	9a d2 2e 72 22       	call   0x2272:0x2ed2
    2249:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    224c:	06                   	push   es
    224d:	57                   	push   di
    224e:	9a bf 31 66 22       	call   0x2266:0x31bf
    2253:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2256:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    225b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    225e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2261:	06                   	push   es
    2262:	57                   	push   di
    2263:	9a d2 31 88 22       	call   0x2288:0x31d2
    2268:	6a 01                	push   0x1
    226a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    226d:	06                   	push   es
    226e:	57                   	push   di
    226f:	9a fb 2f 7e 22       	call   0x227e:0x2ffb
    2274:	6a 00                	push   0x0
    2276:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2279:	06                   	push   es
    227a:	57                   	push   di
    227b:	9a d2 2e a9 22       	call   0x22a9:0x2ed2
    2280:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2283:	06                   	push   es
    2284:	57                   	push   di
    2285:	9a bf 31 9d 22       	call   0x229d:0x31bf
    228a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    228d:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    2292:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2295:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2298:	06                   	push   es
    2299:	57                   	push   di
    229a:	9a d2 31 bf 22       	call   0x22bf:0x31d2
    229f:	6a 01                	push   0x1
    22a1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22a4:	06                   	push   es
    22a5:	57                   	push   di
    22a6:	9a fb 2f b5 22       	call   0x22b5:0x2ffb
    22ab:	6a 00                	push   0x0
    22ad:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22b0:	06                   	push   es
    22b1:	57                   	push   di
    22b2:	9a d2 2e e0 22       	call   0x22e0:0x2ed2
    22b7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22ba:	06                   	push   es
    22bb:	57                   	push   di
    22bc:	9a bf 31 d4 22       	call   0x22d4:0x31bf
    22c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c4:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    22c9:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    22cc:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    22cf:	06                   	push   es
    22d0:	57                   	push   di
    22d1:	9a d2 31 f6 22       	call   0x22f6:0x31d2
    22d6:	6a 01                	push   0x1
    22d8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22db:	06                   	push   es
    22dc:	57                   	push   di
    22dd:	9a fb 2f ec 22       	call   0x22ec:0x2ffb
    22e2:	6a 00                	push   0x0
    22e4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22e7:	06                   	push   es
    22e8:	57                   	push   di
    22e9:	9a d2 2e 17 23       	call   0x2317:0x2ed2
    22ee:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22f1:	06                   	push   es
    22f2:	57                   	push   di
    22f3:	9a bf 31 0b 23       	call   0x230b:0x31bf
    22f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fb:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    2300:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2303:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2306:	06                   	push   es
    2307:	57                   	push   di
    2308:	9a d2 31 2d 23       	call   0x232d:0x31d2
    230d:	6a 01                	push   0x1
    230f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2312:	06                   	push   es
    2313:	57                   	push   di
    2314:	9a fb 2f 23 23       	call   0x2323:0x2ffb
    2319:	6a 00                	push   0x0
    231b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    231e:	06                   	push   es
    231f:	57                   	push   di
    2320:	9a d2 2e 4e 23       	call   0x234e:0x2ed2
    2325:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2328:	06                   	push   es
    2329:	57                   	push   di
    232a:	9a bf 31 42 23       	call   0x2342:0x31bf
    232f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2332:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2337:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    233a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    233d:	06                   	push   es
    233e:	57                   	push   di
    233f:	9a d2 31 64 23       	call   0x2364:0x31d2
    2344:	6a 01                	push   0x1
    2346:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2349:	06                   	push   es
    234a:	57                   	push   di
    234b:	9a fb 2f 5a 23       	call   0x235a:0x2ffb
    2350:	6a 00                	push   0x0
    2352:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2355:	06                   	push   es
    2356:	57                   	push   di
    2357:	9a d2 2e 85 23       	call   0x2385:0x2ed2
    235c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    235f:	06                   	push   es
    2360:	57                   	push   di
    2361:	9a bf 31 79 23       	call   0x2379:0x31bf
    2366:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2369:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    236e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2371:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2374:	06                   	push   es
    2375:	57                   	push   di
    2376:	9a d2 31 9b 23       	call   0x239b:0x31d2
    237b:	6a 01                	push   0x1
    237d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2380:	06                   	push   es
    2381:	57                   	push   di
    2382:	9a fb 2f 91 23       	call   0x2391:0x2ffb
    2387:	6a 00                	push   0x0
    2389:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    238c:	06                   	push   es
    238d:	57                   	push   di
    238e:	9a d2 2e bc 23       	call   0x23bc:0x2ed2
    2393:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2396:	06                   	push   es
    2397:	57                   	push   di
    2398:	9a bf 31 b0 23       	call   0x23b0:0x31bf
    239d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23a0:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    23a5:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    23a8:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    23ab:	06                   	push   es
    23ac:	57                   	push   di
    23ad:	9a d2 31 d2 23       	call   0x23d2:0x31d2
    23b2:	6a 01                	push   0x1
    23b4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23b7:	06                   	push   es
    23b8:	57                   	push   di
    23b9:	9a fb 2f c8 23       	call   0x23c8:0x2ffb
    23be:	6a 00                	push   0x0
    23c0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23c3:	06                   	push   es
    23c4:	57                   	push   di
    23c5:	9a d2 2e f3 23       	call   0x23f3:0x2ed2
    23ca:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23cd:	06                   	push   es
    23ce:	57                   	push   di
    23cf:	9a bf 31 e7 23       	call   0x23e7:0x31bf
    23d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d7:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    23dc:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    23df:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    23e2:	06                   	push   es
    23e3:	57                   	push   di
    23e4:	9a d2 31 09 24       	call   0x2409:0x31d2
    23e9:	6a 01                	push   0x1
    23eb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23ee:	06                   	push   es
    23ef:	57                   	push   di
    23f0:	9a fb 2f ff 23       	call   0x23ff:0x2ffb
    23f5:	6a 00                	push   0x0
    23f7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23fa:	06                   	push   es
    23fb:	57                   	push   di
    23fc:	9a d2 2e 2a 24       	call   0x242a:0x2ed2
    2401:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2404:	06                   	push   es
    2405:	57                   	push   di
    2406:	9a bf 31 1e 24       	call   0x241e:0x31bf
    240b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240e:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    2413:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2416:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2419:	06                   	push   es
    241a:	57                   	push   di
    241b:	9a d2 31 40 24       	call   0x2440:0x31d2
    2420:	6a 01                	push   0x1
    2422:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2425:	06                   	push   es
    2426:	57                   	push   di
    2427:	9a fb 2f 36 24       	call   0x2436:0x2ffb
    242c:	6a 00                	push   0x0
    242e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2431:	06                   	push   es
    2432:	57                   	push   di
    2433:	9a d2 2e 72 24       	call   0x2472:0x2ed2
    2438:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    243b:	06                   	push   es
    243c:	57                   	push   di
    243d:	9a bf 31 31 25       	call   0x2531:0x31bf
    2442:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2445:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    244a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    244d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2450:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2453:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    2458:	99                   	cwd
    2459:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    245c:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    245f:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    2463:	8d 7e f0             	lea    di,[bp-0x10]
    2466:	16                   	push   ss
    2467:	57                   	push   di
    2468:	6a 00                	push   0x0
    246a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    246d:	06                   	push   es
    246e:	57                   	push   di
    246f:	9a 95 28 c0 24       	call   0x24c0:0x2895
    2474:	08 c0                	or     al,al
    2476:	75 0a                	jne    0x2482
    2478:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    247b:	06                   	push   es
    247c:	57                   	push   di
    247d:	9a 77 0c ce 24       	call   0x24ce:0xc77
    2482:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2485:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    248a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    248d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2490:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2493:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    2498:	99                   	cwd
    2499:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    249c:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    249f:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    24a3:	c7 46 f0 01 00       	mov    WORD PTR [bp-0x10],0x1
    24a8:	c7 46 f2 00 00       	mov    WORD PTR [bp-0xe],0x0
    24ad:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    24b1:	8d 7e e8             	lea    di,[bp-0x18]
    24b4:	16                   	push   ss
    24b5:	57                   	push   di
    24b6:	6a 01                	push   0x1
    24b8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    24bb:	06                   	push   es
    24bc:	57                   	push   di
    24bd:	9a 95 28 0e 25       	call   0x250e:0x2895
    24c2:	08 c0                	or     al,al
    24c4:	75 0a                	jne    0x24d0
    24c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c9:	06                   	push   es
    24ca:	57                   	push   di
    24cb:	9a 77 0c 1c 25       	call   0x251c:0xc77
    24d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d3:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    24d8:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    24db:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    24de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e1:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    24e6:	99                   	cwd
    24e7:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    24ea:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    24ed:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    24f1:	c7 46 f0 02 00       	mov    WORD PTR [bp-0x10],0x2
    24f6:	c7 46 f2 00 00       	mov    WORD PTR [bp-0xe],0x0
    24fb:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    24ff:	8d 7e e8             	lea    di,[bp-0x18]
    2502:	16                   	push   ss
    2503:	57                   	push   di
    2504:	6a 01                	push   0x1
    2506:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2509:	06                   	push   es
    250a:	57                   	push   di
    250b:	9a 95 28 3d 25       	call   0x253d:0x2895
    2510:	08 c0                	or     al,al
    2512:	75 0a                	jne    0x251e
    2514:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2517:	06                   	push   es
    2518:	57                   	push   di
    2519:	9a 77 0c 34 26       	call   0x2634:0xc77
    251e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2521:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2526:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2529:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    252c:	06                   	push   es
    252d:	57                   	push   di
    252e:	9a d2 31 53 25       	call   0x2553:0x31d2
    2533:	6a 01                	push   0x1
    2535:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2538:	06                   	push   es
    2539:	57                   	push   di
    253a:	9a fb 2f 49 25       	call   0x2549:0x2ffb
    253f:	6a 00                	push   0x0
    2541:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2544:	06                   	push   es
    2545:	57                   	push   di
    2546:	9a d2 2e 26 26       	call   0x2626:0x2ed2
    254b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    254e:	06                   	push   es
    254f:	57                   	push   di
    2550:	9a bf 31 47 2a       	call   0x2a47:0x31bf
    2555:	6a 00                	push   0x0
    2557:	6a 00                	push   0x0
    2559:	8d be fc fd          	lea    di,[bp-0x204]
    255d:	16                   	push   ss
    255e:	57                   	push   di
    255f:	bf 3a 21             	mov    di,0x213a
    2562:	0e                   	push   cs
    2563:	57                   	push   di
    2564:	9a cd 17 8b 25       	call   0x258b:0x17cd
    2569:	8d be fc fe          	lea    di,[bp-0x104]
    256d:	16                   	push   ss
    256e:	57                   	push   di
    256f:	bf 36 21             	mov    di,0x2136
    2572:	0e                   	push   cs
    2573:	57                   	push   di
    2574:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2577:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    257c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2581:	06                   	push   es
    2582:	57                   	push   di
    2583:	9a 19 15 ff ff       	call   0xffff:0x1519
    2588:	9a 4c 18 95 25       	call   0x2595:0x184c
    258d:	bf 3e 21             	mov    di,0x213e
    2590:	0e                   	push   cs
    2591:	57                   	push   di
    2592:	9a 4c 18 b0 25       	call   0x25b0:0x184c
    2597:	8d be fc fc          	lea    di,[bp-0x304]
    259b:	16                   	push   ss
    259c:	57                   	push   di
    259d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a0:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    25a5:	99                   	cwd
    25a6:	52                   	push   dx
    25a7:	50                   	push   ax
    25a8:	9a a9 08 7c 36       	call   0x367c:0x8a9
    25ad:	9a 4c 18 fc 25       	call   0x25fc:0x184c
    25b2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25b8:	06                   	push   es
    25b9:	57                   	push   di
    25ba:	9a 08 9b b2 2c       	call   0x2cb2:0x9b08
    25bf:	a1 4e 01             	mov    ax,ds:0x14e
    25c2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    25c5:	b8 01 00             	mov    ax,0x1
    25c8:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    25cb:	7e 03                	jle    0x25d0
    25cd:	e9 56 04             	jmp    0x2a26
    25d0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    25d3:	eb 03                	jmp    0x25d8
    25d5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    25d8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e1:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    25e6:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    25e9:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    25ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ef:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    25f4:	2d 01 00             	sub    ax,0x1
    25f7:	71 05                	jno    0x25fe
    25f9:	9a 3e 04 54 26       	call   0x2654:0x43e
    25fe:	99                   	cwd
    25ff:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    2602:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    2605:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    2609:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    260c:	99                   	cwd
    260d:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    2610:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    2613:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    2617:	8d 7e e2             	lea    di,[bp-0x1e]
    261a:	16                   	push   ss
    261b:	57                   	push   di
    261c:	6a 01                	push   0x1
    261e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2621:	06                   	push   es
    2622:	57                   	push   di
    2623:	9a 95 28 8c 26       	call   0x268c:0x2895
    2628:	08 c0                	or     al,al
    262a:	75 0a                	jne    0x2636
    262c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    262f:	06                   	push   es
    2630:	57                   	push   di
    2631:	9a 77 0c 9a 26       	call   0x269a:0xc77
    2636:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2639:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    263e:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    2641:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    2644:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2647:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    264c:	2d 01 00             	sub    ax,0x1
    264f:	71 05                	jno    0x2656
    2651:	9a 3e 04 ba 26       	call   0x26ba:0x43e
    2656:	99                   	cwd
    2657:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    265a:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    265d:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    2661:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2664:	99                   	cwd
    2665:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    2668:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    266b:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    266f:	c7 46 ea 01 00       	mov    WORD PTR [bp-0x16],0x1
    2674:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    2679:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    267d:	8d 7e da             	lea    di,[bp-0x26]
    2680:	16                   	push   ss
    2681:	57                   	push   di
    2682:	6a 02                	push   0x2
    2684:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2687:	06                   	push   es
    2688:	57                   	push   di
    2689:	9a 95 28 f2 26       	call   0x26f2:0x2895
    268e:	08 c0                	or     al,al
    2690:	75 0a                	jne    0x269c
    2692:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2695:	06                   	push   es
    2696:	57                   	push   di
    2697:	9a 77 0c 00 27       	call   0x2700:0xc77
    269c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    269f:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    26a4:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    26a7:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    26aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ad:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    26b2:	2d 01 00             	sub    ax,0x1
    26b5:	71 05                	jno    0x26bc
    26b7:	9a 3e 04 fa 2a       	call   0x2afa:0x43e
    26bc:	99                   	cwd
    26bd:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    26c0:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    26c3:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    26c7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    26ca:	99                   	cwd
    26cb:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    26ce:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    26d1:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    26d5:	c7 46 ea 02 00       	mov    WORD PTR [bp-0x16],0x2
    26da:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    26df:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    26e3:	8d 7e da             	lea    di,[bp-0x26]
    26e6:	16                   	push   ss
    26e7:	57                   	push   di
    26e8:	6a 02                	push   0x2
    26ea:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    26ed:	06                   	push   es
    26ee:	57                   	push   di
    26ef:	9a 95 28 40 27       	call   0x2740:0x2895
    26f4:	08 c0                	or     al,al
    26f6:	75 0a                	jne    0x2702
    26f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26fb:	06                   	push   es
    26fc:	57                   	push   di
    26fd:	9a 77 0c 4e 27       	call   0x274e:0xc77
    2702:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2705:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    270a:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    270d:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    2710:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2713:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    2718:	99                   	cwd
    2719:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    271c:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    271f:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    2723:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2726:	99                   	cwd
    2727:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    272a:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    272d:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    2731:	8d 7e e2             	lea    di,[bp-0x1e]
    2734:	16                   	push   ss
    2735:	57                   	push   di
    2736:	6a 01                	push   0x1
    2738:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    273b:	06                   	push   es
    273c:	57                   	push   di
    273d:	9a 95 28 9c 27       	call   0x279c:0x2895
    2742:	08 c0                	or     al,al
    2744:	75 0a                	jne    0x2750
    2746:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2749:	06                   	push   es
    274a:	57                   	push   di
    274b:	9a 77 0c aa 27       	call   0x27aa:0xc77
    2750:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2753:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    2758:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    275b:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    275e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2761:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    2766:	99                   	cwd
    2767:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    276a:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    276d:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    2771:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2774:	99                   	cwd
    2775:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    2778:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    277b:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    277f:	c7 46 ea 01 00       	mov    WORD PTR [bp-0x16],0x1
    2784:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    2789:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    278d:	8d 7e da             	lea    di,[bp-0x26]
    2790:	16                   	push   ss
    2791:	57                   	push   di
    2792:	6a 02                	push   0x2
    2794:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2797:	06                   	push   es
    2798:	57                   	push   di
    2799:	9a 95 28 f8 27       	call   0x27f8:0x2895
    279e:	08 c0                	or     al,al
    27a0:	75 0a                	jne    0x27ac
    27a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a5:	06                   	push   es
    27a6:	57                   	push   di
    27a7:	9a 77 0c 06 28       	call   0x2806:0xc77
    27ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27af:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    27b4:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    27b7:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    27ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27bd:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    27c2:	99                   	cwd
    27c3:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    27c6:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    27c9:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    27cd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    27d0:	99                   	cwd
    27d1:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    27d4:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    27d7:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    27db:	c7 46 ea 02 00       	mov    WORD PTR [bp-0x16],0x2
    27e0:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    27e5:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    27e9:	8d 7e da             	lea    di,[bp-0x26]
    27ec:	16                   	push   ss
    27ed:	57                   	push   di
    27ee:	6a 02                	push   0x2
    27f0:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    27f3:	06                   	push   es
    27f4:	57                   	push   di
    27f5:	9a 95 28 54 28       	call   0x2854:0x2895
    27fa:	08 c0                	or     al,al
    27fc:	75 0a                	jne    0x2808
    27fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2801:	06                   	push   es
    2802:	57                   	push   di
    2803:	9a 77 0c 62 28       	call   0x2862:0xc77
    2808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    280b:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    2810:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    2813:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    2816:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2819:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    281e:	99                   	cwd
    281f:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    2822:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    2825:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    2829:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    282c:	99                   	cwd
    282d:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    2830:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    2833:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    2837:	c7 46 ea 01 00       	mov    WORD PTR [bp-0x16],0x1
    283c:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    2841:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    2845:	8d 7e da             	lea    di,[bp-0x26]
    2848:	16                   	push   ss
    2849:	57                   	push   di
    284a:	6a 02                	push   0x2
    284c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    284f:	06                   	push   es
    2850:	57                   	push   di
    2851:	9a 95 28 b0 28       	call   0x28b0:0x2895
    2856:	08 c0                	or     al,al
    2858:	75 0a                	jne    0x2864
    285a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    285d:	06                   	push   es
    285e:	57                   	push   di
    285f:	9a 77 0c be 28       	call   0x28be:0xc77
    2864:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2867:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    286c:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    286f:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    2872:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2875:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    287a:	99                   	cwd
    287b:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    287e:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    2881:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    2885:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2888:	99                   	cwd
    2889:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    288c:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    288f:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    2893:	c7 46 ea 02 00       	mov    WORD PTR [bp-0x16],0x2
    2898:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    289d:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    28a1:	8d 7e da             	lea    di,[bp-0x26]
    28a4:	16                   	push   ss
    28a5:	57                   	push   di
    28a6:	6a 02                	push   0x2
    28a8:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    28ab:	06                   	push   es
    28ac:	57                   	push   di
    28ad:	9a 95 28 fe 28       	call   0x28fe:0x2895
    28b2:	08 c0                	or     al,al
    28b4:	75 0a                	jne    0x28c0
    28b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b9:	06                   	push   es
    28ba:	57                   	push   di
    28bb:	9a 77 0c 0c 29       	call   0x290c:0xc77
    28c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c3:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    28c8:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    28cb:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    28ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d1:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    28d6:	99                   	cwd
    28d7:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    28da:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    28dd:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    28e1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    28e4:	99                   	cwd
    28e5:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    28e8:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    28eb:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    28ef:	8d 7e e2             	lea    di,[bp-0x1e]
    28f2:	16                   	push   ss
    28f3:	57                   	push   di
    28f4:	6a 01                	push   0x1
    28f6:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    28f9:	06                   	push   es
    28fa:	57                   	push   di
    28fb:	9a 95 28 3b 40       	call   0x403b:0x2895
    2900:	08 c0                	or     al,al
    2902:	75 0a                	jne    0x290e
    2904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2907:	06                   	push   es
    2908:	57                   	push   di
    2909:	9a 77 0c 29 29       	call   0x2929:0xc77
    290e:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2913:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2916:	8d 7e fc             	lea    di,[bp-0x4]
    2919:	16                   	push   ss
    291a:	57                   	push   di
    291b:	bf 40 21             	mov    di,0x2140
    291e:	0e                   	push   cs
    291f:	57                   	push   di
    2920:	bf 47 21             	mov    di,0x2147
    2923:	0e                   	push   cs
    2924:	57                   	push   di
    2925:	55                   	push   bp
    2926:	9a 8a 20 41 29       	call   0x2941:0x208a
    292b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    292e:	8d 7e fc             	lea    di,[bp-0x4]
    2931:	16                   	push   ss
    2932:	57                   	push   di
    2933:	bf 40 21             	mov    di,0x2140
    2936:	0e                   	push   cs
    2937:	57                   	push   di
    2938:	bf 5b 21             	mov    di,0x215b
    293b:	0e                   	push   cs
    293c:	57                   	push   di
    293d:	55                   	push   bp
    293e:	9a 8a 20 59 29       	call   0x2959:0x208a
    2943:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2946:	8d 7e fc             	lea    di,[bp-0x4]
    2949:	16                   	push   ss
    294a:	57                   	push   di
    294b:	bf 40 21             	mov    di,0x2140
    294e:	0e                   	push   cs
    294f:	57                   	push   di
    2950:	bf 69 21             	mov    di,0x2169
    2953:	0e                   	push   cs
    2954:	57                   	push   di
    2955:	55                   	push   bp
    2956:	9a 8a 20 71 29       	call   0x2971:0x208a
    295b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    295e:	8d 7e fc             	lea    di,[bp-0x4]
    2961:	16                   	push   ss
    2962:	57                   	push   di
    2963:	bf 40 21             	mov    di,0x2140
    2966:	0e                   	push   cs
    2967:	57                   	push   di
    2968:	bf 77 21             	mov    di,0x2177
    296b:	0e                   	push   cs
    296c:	57                   	push   di
    296d:	55                   	push   bp
    296e:	9a 8a 20 89 29       	call   0x2989:0x208a
    2973:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2976:	8d 7e fc             	lea    di,[bp-0x4]
    2979:	16                   	push   ss
    297a:	57                   	push   di
    297b:	bf 40 21             	mov    di,0x2140
    297e:	0e                   	push   cs
    297f:	57                   	push   di
    2980:	bf 7b 21             	mov    di,0x217b
    2983:	0e                   	push   cs
    2984:	57                   	push   di
    2985:	55                   	push   bp
    2986:	9a 8a 20 a1 29       	call   0x29a1:0x208a
    298b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    298e:	8d 7e fc             	lea    di,[bp-0x4]
    2991:	16                   	push   ss
    2992:	57                   	push   di
    2993:	bf 40 21             	mov    di,0x2140
    2996:	0e                   	push   cs
    2997:	57                   	push   di
    2998:	bf 7f 21             	mov    di,0x217f
    299b:	0e                   	push   cs
    299c:	57                   	push   di
    299d:	55                   	push   bp
    299e:	9a 8a 20 b9 29       	call   0x29b9:0x208a
    29a3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29a6:	8d 7e fc             	lea    di,[bp-0x4]
    29a9:	16                   	push   ss
    29aa:	57                   	push   di
    29ab:	bf 40 21             	mov    di,0x2140
    29ae:	0e                   	push   cs
    29af:	57                   	push   di
    29b0:	bf 91 21             	mov    di,0x2191
    29b3:	0e                   	push   cs
    29b4:	57                   	push   di
    29b5:	55                   	push   bp
    29b6:	9a 8a 20 d1 29       	call   0x29d1:0x208a
    29bb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29be:	8d 7e fc             	lea    di,[bp-0x4]
    29c1:	16                   	push   ss
    29c2:	57                   	push   di
    29c3:	bf 40 21             	mov    di,0x2140
    29c6:	0e                   	push   cs
    29c7:	57                   	push   di
    29c8:	bf 9d 21             	mov    di,0x219d
    29cb:	0e                   	push   cs
    29cc:	57                   	push   di
    29cd:	55                   	push   bp
    29ce:	9a 8a 20 e9 29       	call   0x29e9:0x208a
    29d3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29d6:	8d 7e fc             	lea    di,[bp-0x4]
    29d9:	16                   	push   ss
    29da:	57                   	push   di
    29db:	bf 40 21             	mov    di,0x2140
    29de:	0e                   	push   cs
    29df:	57                   	push   di
    29e0:	bf ab 21             	mov    di,0x21ab
    29e3:	0e                   	push   cs
    29e4:	57                   	push   di
    29e5:	55                   	push   bp
    29e6:	9a 8a 20 01 2a       	call   0x2a01:0x208a
    29eb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29ee:	8d 7e fc             	lea    di,[bp-0x4]
    29f1:	16                   	push   ss
    29f2:	57                   	push   di
    29f3:	bf 40 21             	mov    di,0x2140
    29f6:	0e                   	push   cs
    29f7:	57                   	push   di
    29f8:	bf b9 21             	mov    di,0x21b9
    29fb:	0e                   	push   cs
    29fc:	57                   	push   di
    29fd:	55                   	push   bp
    29fe:	9a 8a 20 19 2a       	call   0x2a19:0x208a
    2a03:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a06:	8d 7e fc             	lea    di,[bp-0x4]
    2a09:	16                   	push   ss
    2a0a:	57                   	push   di
    2a0b:	bf 40 21             	mov    di,0x2140
    2a0e:	0e                   	push   cs
    2a0f:	57                   	push   di
    2a10:	bf c5 21             	mov    di,0x21c5
    2a13:	0e                   	push   cs
    2a14:	57                   	push   di
    2a15:	55                   	push   bp
    2a16:	9a 8a 20 c8 2e       	call   0x2ec8:0x208a
    2a1b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a1e:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    2a21:	74 03                	je     0x2a26
    2a23:	e9 af fb             	jmp    0x25d5
    2a26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a29:	26 ff b5 52 03       	push   WORD PTR es:[di+0x352]
    2a2e:	26 ff b5 50 03       	push   WORD PTR es:[di+0x350]
    2a33:	06                   	push   es
    2a34:	57                   	push   di
    2a35:	9a d0 3f 04 2b       	call   0x2b04:0x3fd0
    2a3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a3d:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    2a42:	06                   	push   es
    2a43:	57                   	push   di
    2a44:	9a d2 31 56 2a       	call   0x2a56:0x31d2
    2a49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4c:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    2a51:	06                   	push   es
    2a52:	57                   	push   di
    2a53:	9a d2 31 65 2a       	call   0x2a65:0x31d2
    2a58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a5b:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2a60:	06                   	push   es
    2a61:	57                   	push   di
    2a62:	9a d2 31 74 2a       	call   0x2a74:0x31d2
    2a67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a6a:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    2a6f:	06                   	push   es
    2a70:	57                   	push   di
    2a71:	9a d2 31 83 2a       	call   0x2a83:0x31d2
    2a76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a79:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2a7e:	06                   	push   es
    2a7f:	57                   	push   di
    2a80:	9a d2 31 92 2a       	call   0x2a92:0x31d2
    2a85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a88:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    2a8d:	06                   	push   es
    2a8e:	57                   	push   di
    2a8f:	9a d2 31 a1 2a       	call   0x2aa1:0x31d2
    2a94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a97:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2a9c:	06                   	push   es
    2a9d:	57                   	push   di
    2a9e:	9a d2 31 b0 2a       	call   0x2ab0:0x31d2
    2aa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa6:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    2aab:	06                   	push   es
    2aac:	57                   	push   di
    2aad:	9a d2 31 bf 2a       	call   0x2abf:0x31d2
    2ab2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ab5:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    2aba:	06                   	push   es
    2abb:	57                   	push   di
    2abc:	9a d2 31 ce 2a       	call   0x2ace:0x31d2
    2ac1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac4:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2ac9:	06                   	push   es
    2aca:	57                   	push   di
    2acb:	9a d2 31 dd 2a       	call   0x2add:0x31d2
    2ad0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad3:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    2ad8:	06                   	push   es
    2ad9:	57                   	push   di
    2ada:	9a d2 31 ec 2a       	call   0x2aec:0x31d2
    2adf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae2:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    2ae7:	06                   	push   es
    2ae8:	57                   	push   di
    2ae9:	9a d2 31 5e 40       	call   0x405e:0x31d2
    2aee:	c9                   	leave
    2aef:	ca 08 00             	retf   0x8
    2af2:	55                   	push   bp
    2af3:	89 e5                	mov    bp,sp
    2af5:	31 c0                	xor    ax,ax
    2af7:	9a 44 04 12 2b       	call   0x2b12:0x444
    2afc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aff:	06                   	push   es
    2b00:	57                   	push   di
    2b01:	9a 56 55 3b 2b       	call   0x2b3b:0x5556
    2b06:	c9                   	leave
    2b07:	ca 08 00             	retf   0x8
    2b0a:	55                   	push   bp
    2b0b:	89 e5                	mov    bp,sp
    2b0d:	31 c0                	xor    ax,ax
    2b0f:	9a 44 04 27 2b       	call   0x2b27:0x444
    2b14:	6a 00                	push   0x0
    2b16:	9a ff ff 00 00       	call   0x0:0xffff
    2b1b:	c9                   	leave
    2b1c:	ca 08 00             	retf   0x8
    2b1f:	55                   	push   bp
    2b20:	89 e5                	mov    bp,sp
    2b22:	31 c0                	xor    ax,ax
    2b24:	9a 44 04 6c 2b       	call   0x2b6c:0x444
    2b29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b2c:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    2b32:	75 0b                	jne    0x2b3f
    2b34:	6a 00                	push   0x0
    2b36:	06                   	push   es
    2b37:	57                   	push   di
    2b38:	9a 14 3a 49 2b       	call   0x2b49:0x3a14
    2b3d:	eb 0c                	jmp    0x2b4b
    2b3f:	6a 02                	push   0x2
    2b41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b44:	06                   	push   es
    2b45:	57                   	push   di
    2b46:	9a 14 3a 14 4e       	call   0x4e14:0x3a14
    2b4b:	c9                   	leave
    2b4c:	ca 08 00             	retf   0x8
    2b4f:	ce                   	into
    2b50:	2b d5                	sub    dx,bp
    2b52:	2b dc                	sub    bx,sp
    2b54:	2b e3                	sub    sp,bx
    2b56:	2b ea                	sub    bp,dx
    2b58:	2b f1                	sub    si,cx
    2b5a:	2b 00                	sub    ax,WORD PTR [bx+si]
    2b5c:	80 ff ff             	cmp    bh,0xff
    2b5f:	ff                   	(bad)
    2b60:	7f 00                	jg     0x2b62
    2b62:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2b65:	e5 b8                	in     ax,0xb8
    2b67:	18 00                	sbb    BYTE PTR [bx+si],al
    2b69:	9a 44 04 8d 2b       	call   0x2b8d:0x444
    2b6e:	83 ec 18             	sub    sp,0x18
    2b71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b74:	26 8b 85 c4 03       	mov    ax,WORD PTR es:[di+0x3c4]
    2b79:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2b7c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b7f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b82:	bf 94 00             	mov    di,0x94
    2b85:	b8 a0 2b             	mov    ax,0x2ba0
    2b88:	50                   	push   ax
    2b89:	57                   	push   di
    2b8a:	9a 55 22 a7 2b       	call   0x2ba7:0x2255
    2b8f:	08 c0                	or     al,al
    2b91:	75 03                	jne    0x2b96
    2b93:	e9 bf 00             	jmp    0x2c55
    2b96:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b99:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b9c:	bf 94 00             	mov    di,0x94
    2b9f:	b8 b8 2b             	mov    ax,0x2bb8
    2ba2:	50                   	push   ax
    2ba3:	57                   	push   di
    2ba4:	9a 73 22 15 2c       	call   0x2c15:0x2273
    2ba9:	52                   	push   dx
    2baa:	50                   	push   ax
    2bab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bae:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2bb3:	06                   	push   es
    2bb4:	57                   	push   di
    2bb5:	9a 2b 16 0b 2c       	call   0x2c0b:0x162b
    2bba:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2bbd:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2bc0:	3d 05 00             	cmp    ax,0x5
    2bc3:	77 33                	ja     0x2bf8
    2bc5:	89 c3                	mov    bx,ax
    2bc7:	d1 e3                	shl    bx,1
    2bc9:	2e ff a7 4f 2b       	jmp    WORD PTR cs:[bx+0x2b4f]
    2bce:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    2bd3:	eb 23                	jmp    0x2bf8
    2bd5:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    2bda:	eb 1c                	jmp    0x2bf8
    2bdc:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    2be1:	eb 15                	jmp    0x2bf8
    2be3:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    2be8:	eb 0e                	jmp    0x2bf8
    2bea:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    2bef:	eb 07                	jmp    0x2bf8
    2bf1:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    2bf6:	eb 00                	jmp    0x2bf8
    2bf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bfb:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2c00:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    2c03:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    2c06:	06                   	push   es
    2c07:	57                   	push   di
    2c08:	9a 26 13 40 2c       	call   0x2c40:0x1326
    2c0d:	2d 01 00             	sub    ax,0x1
    2c10:	71 05                	jno    0x2c17
    2c12:	9a 3e 04 85 2c       	call   0x2c85:0x43e
    2c17:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2c1a:	31 c0                	xor    ax,ax
    2c1c:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2c1f:	7f 34                	jg     0x2c55
    2c21:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2c24:	eb 03                	jmp    0x2c29
    2c26:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    2c29:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2c2c:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    2c2f:	b0 00                	mov    al,0x0
    2c31:	75 01                	jne    0x2c34
    2c33:	40                   	inc    ax
    2c34:	50                   	push   ax
    2c35:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2c38:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2c3b:	06                   	push   es
    2c3c:	57                   	push   di
    2c3d:	9a 53 13 4b 2c       	call   0x2c4b:0x1353
    2c42:	89 c7                	mov    di,ax
    2c44:	8e c2                	mov    es,dx
    2c46:	06                   	push   es
    2c47:	57                   	push   di
    2c48:	9a 75 12 0c 2e       	call   0x2e0c:0x1275
    2c4d:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2c50:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2c53:	75 d1                	jne    0x2c26
    2c55:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c5b:	26 3b 85 c4 03       	cmp    ax,WORD PTR es:[di+0x3c4]
    2c60:	75 03                	jne    0x2c65
    2c62:	e9 1e 02             	jmp    0x2e83
    2c65:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    2c6a:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    2c6d:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    2c70:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2c75:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2c7a:	2d 01 00             	sub    ax,0x1
    2c7d:	83 da 00             	sbb    dx,0x0
    2c80:	71 05                	jno    0x2c87
    2c82:	9a 3e 04 8d 2c       	call   0x2c8d:0x43e
    2c87:	bf 5b 2b             	mov    di,0x2b5b
    2c8a:	9a 16 04 d4 2c       	call   0x2cd4:0x416
    2c8f:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2c92:	31 c0                	xor    ax,ax
    2c94:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2c97:	7e 03                	jle    0x2c9c
    2c99:	e9 85 00             	jmp    0x2d21
    2c9c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c9f:	eb 03                	jmp    0x2ca4
    2ca1:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2ca4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2ca7:	99                   	cwd
    2ca8:	52                   	push   dx
    2ca9:	50                   	push   ax
    2caa:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2cad:	06                   	push   es
    2cae:	57                   	push   di
    2caf:	9a 30 6e 17 2d       	call   0x2d17:0x6e30
    2cb4:	99                   	cwd
    2cb5:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2cb8:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2cbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbe:	26 8b 85 c4 03       	mov    ax,WORD PTR es:[di+0x3c4]
    2cc3:	99                   	cwd
    2cc4:	52                   	push   dx
    2cc5:	50                   	push   ax
    2cc6:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2cc9:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    2ccc:	b9 64 00             	mov    cx,0x64
    2ccf:	31 db                	xor    bx,bx
    2cd1:	9a 5c 17 db 2c       	call   0x2cdb:0x175c
    2cd6:	59                   	pop    cx
    2cd7:	5b                   	pop    bx
    2cd8:	9a 70 16 e8 2c       	call   0x2ce8:0x1670
    2cdd:	8b c8                	mov    cx,ax
    2cdf:	8b da                	mov    bx,dx
    2ce1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ce4:	99                   	cwd
    2ce5:	9a 5c 17 f2 2c       	call   0x2cf2:0x175c
    2cea:	b9 64 00             	mov    cx,0x64
    2ced:	31 db                	xor    bx,bx
    2cef:	9a 70 16 0c 2d       	call   0x2d0c:0x1670
    2cf4:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2cf7:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2cfa:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cfd:	99                   	cwd
    2cfe:	52                   	push   dx
    2cff:	50                   	push   ax
    2d00:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2d03:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    2d06:	bf 5b 2b             	mov    di,0x2b5b
    2d09:	9a 16 04 39 2d       	call   0x2d39:0x416
    2d0e:	50                   	push   ax
    2d0f:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2d12:	06                   	push   es
    2d13:	57                   	push   di
    2d14:	9a c9 70 66 2d       	call   0x2d66:0x70c9
    2d19:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d1c:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2d1f:	75 80                	jne    0x2ca1
    2d21:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2d24:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    2d29:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    2d2e:	2d 01 00             	sub    ax,0x1
    2d31:	83 da 00             	sbb    dx,0x0
    2d34:	71 05                	jno    0x2d3b
    2d36:	9a 3e 04 41 2d       	call   0x2d41:0x43e
    2d3b:	bf 5b 2b             	mov    di,0x2b5b
    2d3e:	9a 16 04 88 2d       	call   0x2d88:0x416
    2d43:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2d46:	31 c0                	xor    ax,ax
    2d48:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2d4b:	7e 03                	jle    0x2d50
    2d4d:	e9 85 00             	jmp    0x2dd5
    2d50:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2d53:	eb 03                	jmp    0x2d58
    2d55:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2d58:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2d5b:	99                   	cwd
    2d5c:	52                   	push   dx
    2d5d:	50                   	push   ax
    2d5e:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2d61:	06                   	push   es
    2d62:	57                   	push   di
    2d63:	9a 8b 6e cb 2d       	call   0x2dcb:0x6e8b
    2d68:	99                   	cwd
    2d69:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2d6c:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2d6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d72:	26 8b 85 c4 03       	mov    ax,WORD PTR es:[di+0x3c4]
    2d77:	99                   	cwd
    2d78:	52                   	push   dx
    2d79:	50                   	push   ax
    2d7a:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2d7d:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    2d80:	b9 64 00             	mov    cx,0x64
    2d83:	31 db                	xor    bx,bx
    2d85:	9a 5c 17 8f 2d       	call   0x2d8f:0x175c
    2d8a:	59                   	pop    cx
    2d8b:	5b                   	pop    bx
    2d8c:	9a 70 16 9c 2d       	call   0x2d9c:0x1670
    2d91:	8b c8                	mov    cx,ax
    2d93:	8b da                	mov    bx,dx
    2d95:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d98:	99                   	cwd
    2d99:	9a 5c 17 a6 2d       	call   0x2da6:0x175c
    2d9e:	b9 64 00             	mov    cx,0x64
    2da1:	31 db                	xor    bx,bx
    2da3:	9a 70 16 c0 2d       	call   0x2dc0:0x1670
    2da8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2dab:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2dae:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2db1:	99                   	cwd
    2db2:	52                   	push   dx
    2db3:	50                   	push   ax
    2db4:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2db7:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    2dba:	bf 5b 2b             	mov    di,0x2b5b
    2dbd:	9a 16 04 16 2e       	call   0x2e16:0x416
    2dc2:	50                   	push   ax
    2dc3:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2dc6:	06                   	push   es
    2dc7:	57                   	push   di
    2dc8:	9a a3 74 e5 2d       	call   0x2de5:0x74a3
    2dcd:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2dd0:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2dd3:	75 80                	jne    0x2d55
    2dd5:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2dd8:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    2ddd:	99                   	cwd
    2dde:	52                   	push   dx
    2ddf:	50                   	push   ax
    2de0:	06                   	push   es
    2de1:	57                   	push   di
    2de2:	9a 45 73 f7 2d       	call   0x2df7:0x7345
    2de7:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2dea:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    2def:	99                   	cwd
    2df0:	52                   	push   dx
    2df1:	50                   	push   ax
    2df2:	06                   	push   es
    2df3:	57                   	push   di
    2df4:	9a dd 75 2e 37       	call   0x372e:0x75dd
    2df9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dfc:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    2e01:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    2e04:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    2e07:	06                   	push   es
    2e08:	57                   	push   di
    2e09:	9a 26 13 37 2e       	call   0x2e37:0x1326
    2e0e:	2d 01 00             	sub    ax,0x1
    2e11:	71 05                	jno    0x2e18
    2e13:	9a 3e 04 90 2e       	call   0x2e90:0x43e
    2e18:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2e1b:	31 c0                	xor    ax,ax
    2e1d:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2e20:	7f 2a                	jg     0x2e4c
    2e22:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2e25:	eb 03                	jmp    0x2e2a
    2e27:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    2e2a:	6a 00                	push   0x0
    2e2c:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2e2f:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2e32:	06                   	push   es
    2e33:	57                   	push   di
    2e34:	9a 53 13 42 2e       	call   0x2e42:0x1353
    2e39:	89 c7                	mov    di,ax
    2e3b:	8e c2                	mov    es,dx
    2e3d:	06                   	push   es
    2e3e:	57                   	push   di
    2e3f:	9a 75 12 e6 2e       	call   0x2ee6:0x1275
    2e44:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2e47:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    2e4a:	75 db                	jne    0x2e27
    2e4c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e52:	26 ff b5 c4 03       	push   WORD PTR es:[di+0x3c4]
    2e57:	06                   	push   es
    2e58:	57                   	push   di
    2e59:	9a f4 5d 30 33       	call   0x3330:0x5df4
    2e5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e64:	26 89 85 c4 03       	mov    WORD PTR es:[di+0x3c4],ax
    2e69:	26 83 bd c4 03 64    	cmp    WORD PTR es:[di+0x3c4],0x64
    2e6f:	7d 12                	jge    0x2e83
    2e71:	6a 18                	push   0x18
    2e73:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    2e78:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2e7c:	06                   	push   es
    2e7d:	57                   	push   di
    2e7e:	9a f5 11 19 30       	call   0x3019:0x11f5
    2e83:	c9                   	leave
    2e84:	ca 08 00             	retf   0x8
    2e87:	55                   	push   bp
    2e88:	89 e5                	mov    bp,sp
    2e8a:	b8 02 00             	mov    ax,0x2
    2e8d:	9a 44 04 a0 2e       	call   0x2ea0:0x444
    2e92:	83 ec 02             	sub    sp,0x2
    2e95:	a1 4c 01             	mov    ax,ds:0x14c
    2e98:	2d 01 00             	sub    ax,0x1
    2e9b:	71 05                	jno    0x2ea2
    2e9d:	9a 3e 04 d7 2e       	call   0x2ed7:0x43e
    2ea2:	50                   	push   ax
    2ea3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea6:	26 ff b5 c7 03       	push   WORD PTR es:[di+0x3c7]
    2eab:	9a 32 3e a4 2f       	call   0x2fa4:0x3e32
    2eb0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2eb3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2eb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb9:	26 3b 85 c7 03       	cmp    ax,WORD PTR es:[di+0x3c7]
    2ebe:	74 0a                	je     0x2eca
    2ec0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ec3:	06                   	push   es
    2ec4:	57                   	push   di
    2ec5:	9a bc 16 be 2f       	call   0x2fbe:0x16bc
    2eca:	c9                   	leave
    2ecb:	ca 08 00             	retf   0x8
    2ece:	55                   	push   bp
    2ecf:	89 e5                	mov    bp,sp
    2ed1:	b8 08 00             	mov    ax,0x8
    2ed4:	9a 44 04 ed 2e       	call   0x2eed:0x444
    2ed9:	83 ec 08             	sub    sp,0x8
    2edc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2edf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ee2:	bf 94 00             	mov    di,0x94
    2ee5:	b8 00 2f             	mov    ax,0x2f00
    2ee8:	50                   	push   ax
    2ee9:	57                   	push   di
    2eea:	9a 55 22 07 2f       	call   0x2f07:0x2255
    2eef:	08 c0                	or     al,al
    2ef1:	75 03                	jne    0x2ef6
    2ef3:	e9 ca 00             	jmp    0x2fc0
    2ef6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ef9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2efc:	bf 94 00             	mov    di,0x94
    2eff:	b8 22 2f             	mov    ax,0x2f22
    2f02:	50                   	push   ax
    2f03:	57                   	push   di
    2f04:	9a 73 22 29 2f       	call   0x2f29:0x2273
    2f09:	89 c7                	mov    di,ax
    2f0b:	8e c2                	mov    es,dx
    2f0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f10:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    2f15:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f18:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f1b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2f1e:	bf 94 00             	mov    di,0x94
    2f21:	b8 3a 2f             	mov    ax,0x2f3a
    2f24:	50                   	push   ax
    2f25:	57                   	push   di
    2f26:	9a 73 22 4a 2f       	call   0x2f4a:0x2273
    2f2b:	52                   	push   dx
    2f2c:	50                   	push   ax
    2f2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f30:	26 c4 bd 5c 03       	les    di,DWORD PTR es:[di+0x35c]
    2f35:	06                   	push   es
    2f36:	57                   	push   di
    2f37:	9a 2b 16 c8 50       	call   0x50c8:0x162b
    2f3c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2f3f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f42:	05 01 00             	add    ax,0x1
    2f45:	71 05                	jno    0x2f4c
    2f47:	9a 3e 04 7e 2f       	call   0x2f7e:0x43e
    2f4c:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    2f50:	b0 00                	mov    al,0x0
    2f52:	7d 01                	jge    0x2f55
    2f54:	40                   	inc    ax
    2f55:	8a c8                	mov    cl,al
    2f57:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2f5b:	b0 00                	mov    al,0x0
    2f5d:	7d 01                	jge    0x2f60
    2f5f:	40                   	inc    ax
    2f60:	8a d0                	mov    dl,al
    2f62:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2f66:	b0 00                	mov    al,0x0
    2f68:	7c 01                	jl     0x2f6b
    2f6a:	40                   	inc    ax
    2f6b:	22 c2                	and    al,dl
    2f6d:	22 c1                	and    al,cl
    2f6f:	08 c0                	or     al,al
    2f71:	74 12                	je     0x2f85
    2f73:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f76:	05 01 00             	add    ax,0x1
    2f79:	71 05                	jno    0x2f80
    2f7b:	9a 3e 04 96 2f       	call   0x2f96:0x43e
    2f80:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f83:	eb 24                	jmp    0x2fa9
    2f85:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2f89:	75 1e                	jne    0x2fa9
    2f8b:	a1 4c 01             	mov    ax,ds:0x14c
    2f8e:	2d 01 00             	sub    ax,0x1
    2f91:	71 05                	jno    0x2f98
    2f93:	9a 3e 04 cc 2f       	call   0x2fcc:0x43e
    2f98:	50                   	push   ax
    2f99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f9c:	26 ff b5 c7 03       	push   WORD PTR es:[di+0x3c7]
    2fa1:	9a 32 3e ff ff       	call   0xffff:0x3e32
    2fa6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2fa9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2fac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2faf:	26 3b 85 c7 03       	cmp    ax,WORD PTR es:[di+0x3c7]
    2fb4:	74 0a                	je     0x2fc0
    2fb6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2fb9:	06                   	push   es
    2fba:	57                   	push   di
    2fbb:	9a bc 16 e9 2f       	call   0x2fe9:0x16bc
    2fc0:	c9                   	leave
    2fc1:	ca 08 00             	retf   0x8
    2fc4:	55                   	push   bp
    2fc5:	89 e5                	mov    bp,sp
    2fc7:	31 c0                	xor    ax,ax
    2fc9:	9a 44 04 00 30       	call   0x3000:0x444
    2fce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd1:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    2fd6:	06                   	push   es
    2fd7:	57                   	push   di
    2fd8:	9a 17 2f ff ff       	call   0xffff:0x2f17
    2fdd:	08 c0                	or     al,al
    2fdf:	74 0a                	je     0x2feb
    2fe1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fe4:	06                   	push   es
    2fe5:	57                   	push   di
    2fe6:	9a 53 30 51 30       	call   0x3051:0x3053
    2feb:	c9                   	leave
    2fec:	ca 08 00             	retf   0x8
    2fef:	00 00                	add    BYTE PTR [bx+si],al
    2ff1:	00 00                	add    BYTE PTR [bx+si],al
    2ff3:	ff                   	(bad)
    2ff4:	ff 00                	inc    WORD PTR [bx+si]
    2ff6:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2ff9:	e5 b8                	in     ax,0xb8
    2ffb:	22 00                	and    al,BYTE PTR [bx+si]
    2ffd:	9a 44 04 30 30       	call   0x3030:0x444
    3002:	83 ec 22             	sub    sp,0x22
    3005:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3009:	06                   	push   es
    300a:	57                   	push   di
    300b:	9a 04 2a 8e 30       	call   0x308e:0x2a04
    3010:	89 c7                	mov    di,ax
    3012:	8e c2                	mov    es,dx
    3014:	06                   	push   es
    3015:	57                   	push   di
    3016:	9a d2 21 df 30       	call   0x30df:0x21d2
    301b:	50                   	push   ax
    301c:	8d 7e de             	lea    di,[bp-0x22]
    301f:	16                   	push   ss
    3020:	57                   	push   di
    3021:	9a ff ff 00 00       	call   0x0:0xffff
    3026:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    3029:	99                   	cwd
    302a:	bf ef 2f             	mov    di,0x2fef
    302d:	9a 16 04 5c 30       	call   0x305c:0x416
    3032:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3035:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3038:	c9                   	leave
    3039:	ca 02 00             	retf   0x2
    303c:	00 01                	add    BYTE PTR [bx+di],al
    303e:	09 01                	or     WORD PTR [bx+di],ax
    3040:	20 03                	and    BYTE PTR [bp+di],al
    3042:	20 20                	and    BYTE PTR [bx+si],ah
    3044:	20 00                	and    BYTE PTR [bx+si],al
    3046:	80 ff ff             	cmp    bh,0xff
    3049:	ff                   	(bad)
    304a:	7f 00                	jg     0x304c
    304c:	00 00                	add    BYTE PTR [bx+si],al
    304e:	00 1a                	add    BYTE PTR [bp+si],bl
    3050:	35 83 30             	xor    ax,0x3083
    3053:	55                   	push   bp
    3054:	89 e5                	mov    bp,sp
    3056:	b8 18 04             	mov    ax,0x418
    3059:	9a 44 04 99 30       	call   0x3099:0x444
    305e:	81 ec 18 04          	sub    sp,0x418
    3062:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3065:	26 8b 85 cb 03       	mov    ax,WORD PTR es:[di+0x3cb]
    306a:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    306e:	26 c7 85 cb 03 14 00 	mov    WORD PTR es:[di+0x3cb],0x14
    3075:	81 c7 50 03          	add    di,0x350
    3079:	06                   	push   es
    307a:	57                   	push   di
    307b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    307e:	06                   	push   es
    307f:	57                   	push   di
    3080:	9a d6 21 3d 31       	call   0x313d:0x21d6
    3085:	8d be fa fe          	lea    di,[bp-0x106]
    3089:	16                   	push   ss
    308a:	57                   	push   di
    308b:	9a 4e 20 b7 30       	call   0x30b7:0x204e
    3090:	8d be fa fe          	lea    di,[bp-0x106]
    3094:	16                   	push   ss
    3095:	57                   	push   di
    3096:	9a f5 09 9e 30       	call   0x309e:0x9f5
    309b:	9a 08 04 fd 30       	call   0x30fd:0x408
    30a0:	b8 4d 30             	mov    ax,0x304d
    30a3:	0e                   	push   cs
    30a4:	50                   	push   ax
    30a5:	55                   	push   bp
    30a6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    30aa:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    30ae:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    30b2:	06                   	push   es
    30b3:	57                   	push   di
    30b4:	9a 04 2a 4a 31       	call   0x314a:0x2a04
    30b9:	89 c7                	mov    di,ax
    30bb:	8e c2                	mov    es,dx
    30bd:	89 be ea fd          	mov    WORD PTR [bp-0x216],di
    30c1:	8c 86 ec fd          	mov    WORD PTR [bp-0x214],es
    30c5:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    30c9:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    30ce:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    30d2:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    30d6:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    30da:	06                   	push   es
    30db:	57                   	push   di
    30dc:	9a 99 20 59 31       	call   0x3159:0x2099
    30e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e4:	26 8b 85 c9 03       	mov    ax,WORD PTR es:[di+0x3c9]
    30e9:	99                   	cwd
    30ea:	b9 02 00             	mov    cx,0x2
    30ed:	f7 f9                	idiv   cx
    30ef:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    30f2:	a1 4e 01             	mov    ax,ds:0x14e
    30f5:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    30f8:	71 05                	jno    0x30ff
    30fa:	9a 3e 04 07 31       	call   0x3107:0x43e
    30ff:	2d 01 00             	sub    ax,0x1
    3102:	71 05                	jno    0x3109
    3104:	9a 3e 04 91 31       	call   0x3191:0x43e
    3109:	99                   	cwd
    310a:	f7 7e fa             	idiv   WORD PTR [bp-0x6]
    310d:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    3111:	8b 86 f0 fd          	mov    ax,WORD PTR [bp-0x210]
    3115:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    3119:	b8 01 00             	mov    ax,0x1
    311c:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    3120:	7e 03                	jle    0x3125
    3122:	e9 e9 03             	jmp    0x350e
    3125:	89 86 ee fd          	mov    WORD PTR [bp-0x212],ax
    3129:	eb 04                	jmp    0x312f
    312b:	ff 86 ee fd          	inc    WORD PTR [bp-0x212]
    312f:	6a 01                	push   0x1
    3131:	ff b6 ee fd          	push   WORD PTR [bp-0x212]
    3135:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3138:	06                   	push   es
    3139:	57                   	push   di
    313a:	9a b2 39 f3 32       	call   0x32f3:0x39b2
    313f:	6a 08                	push   0x8
    3141:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3145:	06                   	push   es
    3146:	57                   	push   di
    3147:	9a 04 2a 66 31       	call   0x3166:0x2a04
    314c:	89 c7                	mov    di,ax
    314e:	8e c2                	mov    es,dx
    3150:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3154:	06                   	push   es
    3155:	57                   	push   di
    3156:	9a f5 11 75 31       	call   0x3175:0x11f5
    315b:	6a 02                	push   0x2
    315d:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3161:	06                   	push   es
    3162:	57                   	push   di
    3163:	9a 04 2a c2 32       	call   0x32c2:0x2a04
    3168:	89 c7                	mov    di,ax
    316a:	8e c2                	mov    es,dx
    316c:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3170:	06                   	push   es
    3171:	57                   	push   di
    3172:	9a 78 12 d1 32       	call   0x32d1:0x1278
    3177:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    317c:	eb 03                	jmp    0x3181
    317e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3181:	8d be fa fe          	lea    di,[bp-0x106]
    3185:	16                   	push   ss
    3186:	57                   	push   di
    3187:	bf 3c 30             	mov    di,0x303c
    318a:	0e                   	push   cs
    318b:	57                   	push   di
    318c:	6a 00                	push   0x0
    318e:	9a b5 0d 96 31       	call   0x3196:0xdb5
    3193:	9a 78 0c 9b 31       	call   0x319b:0xc78
    3198:	9a 08 04 c9 31       	call   0x31c9:0x408
    319d:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    31a1:	75 db                	jne    0x317e
    31a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31a6:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    31ab:	89 be e8 fd          	mov    WORD PTR [bp-0x218],di
    31af:	8c 86 ea fd          	mov    WORD PTR [bp-0x216],es
    31b3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    31b8:	06                   	push   es
    31b9:	57                   	push   di
    31ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31bd:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    31c1:	2d 01 00             	sub    ax,0x1
    31c4:	71 05                	jno    0x31cb
    31c6:	9a 3e 04 09 32       	call   0x3209:0x43e
    31cb:	89 86 e6 fd          	mov    WORD PTR [bp-0x21a],ax
    31cf:	31 c0                	xor    ax,ax
    31d1:	3b 86 e6 fd          	cmp    ax,WORD PTR [bp-0x21a]
    31d5:	7e 03                	jle    0x31da
    31d7:	e9 c8 00             	jmp    0x32a2
    31da:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    31dd:	eb 03                	jmp    0x31e2
    31df:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    31e2:	8d be e6 fc          	lea    di,[bp-0x31a]
    31e6:	16                   	push   ss
    31e7:	57                   	push   di
    31e8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    31eb:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    31ef:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    31f4:	06                   	push   es
    31f5:	57                   	push   di
    31f6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31f9:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    31fd:	8d be fa fd          	lea    di,[bp-0x206]
    3201:	16                   	push   ss
    3202:	57                   	push   di
    3203:	68 ff 00             	push   0xff
    3206:	9a e7 17 19 32       	call   0x3219:0x17e7
    320b:	bf 3d 30             	mov    di,0x303d
    320e:	0e                   	push   cs
    320f:	57                   	push   di
    3210:	8d be fa fd          	lea    di,[bp-0x206]
    3214:	16                   	push   ss
    3215:	57                   	push   di
    3216:	9a 78 18 32 32       	call   0x3232:0x1878
    321b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    321e:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3222:	7e 26                	jle    0x324a
    3224:	8d be fa fd          	lea    di,[bp-0x206]
    3228:	16                   	push   ss
    3229:	57                   	push   di
    322a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    322d:	6a 01                	push   0x1
    322f:	9a 75 19 48 32       	call   0x3248:0x1975
    3234:	bf 3f 30             	mov    di,0x303f
    3237:	0e                   	push   cs
    3238:	57                   	push   di
    3239:	8d be fa fd          	lea    di,[bp-0x206]
    323d:	16                   	push   ss
    323e:	57                   	push   di
    323f:	68 ff 00             	push   0xff
    3242:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3245:	9a 16 19 5e 32       	call   0x325e:0x1916
    324a:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    324e:	75 bb                	jne    0x320b
    3250:	8d be e6 fc          	lea    di,[bp-0x31a]
    3254:	16                   	push   ss
    3255:	57                   	push   di
    3256:	bf 41 30             	mov    di,0x3041
    3259:	0e                   	push   cs
    325a:	57                   	push   di
    325b:	9a cd 17 69 32       	call   0x3269:0x17cd
    3260:	8d be fa fd          	lea    di,[bp-0x206]
    3264:	16                   	push   ss
    3265:	57                   	push   di
    3266:	9a 4c 18 77 32       	call   0x3277:0x184c
    326b:	8d be fa fd          	lea    di,[bp-0x206]
    326f:	16                   	push   ss
    3270:	57                   	push   di
    3271:	68 ff 00             	push   0xff
    3274:	9a e7 17 8a 32       	call   0x328a:0x17e7
    3279:	8d be fa fe          	lea    di,[bp-0x106]
    327d:	16                   	push   ss
    327e:	57                   	push   di
    327f:	8d be fa fd          	lea    di,[bp-0x206]
    3283:	16                   	push   ss
    3284:	57                   	push   di
    3285:	6a 00                	push   0x0
    3287:	9a b5 0d 8f 32       	call   0x328f:0xdb5
    328c:	9a 78 0c 94 32       	call   0x3294:0xc78
    3291:	9a 08 04 fd 32       	call   0x32fd:0x408
    3296:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3299:	3b 86 e6 fd          	cmp    ax,WORD PTR [bp-0x21a]
    329d:	74 03                	je     0x32a2
    329f:	e9 3d ff             	jmp    0x31df
    32a2:	8b 86 ee fd          	mov    ax,WORD PTR [bp-0x212]
    32a6:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    32aa:	74 03                	je     0x32af
    32ac:	e9 52 02             	jmp    0x3501
    32af:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    32b3:	89 be e8 fd          	mov    WORD PTR [bp-0x218],di
    32b7:	8c 86 ea fd          	mov    WORD PTR [bp-0x216],es
    32bb:	6a 06                	push   0x6
    32bd:	06                   	push   es
    32be:	57                   	push   di
    32bf:	9a 04 2a de 32       	call   0x32de:0x2a04
    32c4:	89 c7                	mov    di,ax
    32c6:	8e c2                	mov    es,dx
    32c8:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    32cc:	06                   	push   es
    32cd:	57                   	push   di
    32ce:	9a f5 11 ed 32       	call   0x32ed:0x11f5
    32d3:	6a 00                	push   0x0
    32d5:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    32d9:	06                   	push   es
    32da:	57                   	push   di
    32db:	9a 04 2a 61 33       	call   0x3361:0x2a04
    32e0:	89 c7                	mov    di,ax
    32e2:	8e c2                	mov    es,dx
    32e4:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    32e8:	06                   	push   es
    32e9:	57                   	push   di
    32ea:	9a 78 12 88 33       	call   0x3388:0x1278
    32ef:	55                   	push   bp
    32f0:	9a f7 2f 53 35       	call   0x3553:0x2ff7
    32f5:	05 02 00             	add    ax,0x2
    32f8:	73 05                	jae    0x32ff
    32fa:	9a 3e 04 07 33       	call   0x3307:0x43e
    32ff:	31 d2                	xor    dx,dx
    3301:	bf 45 30             	mov    di,0x3045
    3304:	9a 16 04 1b 33       	call   0x331b:0x416
    3309:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    330d:	8d be e8 fb          	lea    di,[bp-0x418]
    3311:	16                   	push   ss
    3312:	57                   	push   di
    3313:	bf 41 30             	mov    di,0x3041
    3316:	0e                   	push   cs
    3317:	57                   	push   di
    3318:	9a cd 17 35 33       	call   0x3335:0x17cd
    331d:	8d be e8 fc          	lea    di,[bp-0x318]
    3321:	16                   	push   ss
    3322:	57                   	push   di
    3323:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3326:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    332b:	06                   	push   es
    332c:	57                   	push   di
    332d:	9a 53 1d ad 33       	call   0x33ad:0x1d53
    3332:	9a 4c 18 43 33       	call   0x3343:0x184c
    3337:	8d be fa fd          	lea    di,[bp-0x206]
    333b:	16                   	push   ss
    333c:	57                   	push   di
    333d:	68 ff 00             	push   0xff
    3340:	9a e7 17 55 33       	call   0x3355:0x17e7
    3345:	6a 00                	push   0x0
    3347:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    334b:	b9 05 00             	mov    cx,0x5
    334e:	f7 e9                	imul   cx
    3350:	71 05                	jno    0x3357
    3352:	9a 3e 04 6b 33       	call   0x336b:0x43e
    3357:	50                   	push   ax
    3358:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    335c:	06                   	push   es
    335d:	57                   	push   di
    335e:	9a 72 2a 7d 33       	call   0x337d:0x2a72
    3363:	5a                   	pop    dx
    3364:	2b c2                	sub    ax,dx
    3366:	71 05                	jno    0x336d
    3368:	9a 3e 04 98 33       	call   0x3398:0x43e
    336d:	50                   	push   ax
    336e:	8d be fa fd          	lea    di,[bp-0x206]
    3372:	16                   	push   ss
    3373:	57                   	push   di
    3374:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    3378:	06                   	push   es
    3379:	57                   	push   di
    337a:	9a 04 2a de 33       	call   0x33de:0x2a04
    337f:	89 c7                	mov    di,ax
    3381:	8e c2                	mov    es,dx
    3383:	06                   	push   es
    3384:	57                   	push   di
    3385:	9a 09 1f 05 34       	call   0x3405:0x1f09
    338a:	8d be e8 fb          	lea    di,[bp-0x418]
    338e:	16                   	push   ss
    338f:	57                   	push   di
    3390:	bf 41 30             	mov    di,0x3041
    3393:	0e                   	push   cs
    3394:	57                   	push   di
    3395:	9a cd 17 b2 33       	call   0x33b2:0x17cd
    339a:	8d be e8 fc          	lea    di,[bp-0x318]
    339e:	16                   	push   ss
    339f:	57                   	push   di
    33a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a3:	26 c4 bd 9c 02       	les    di,DWORD PTR es:[di+0x29c]
    33a8:	06                   	push   es
    33a9:	57                   	push   di
    33aa:	9a 53 1d 2a 34       	call   0x342a:0x1d53
    33af:	9a 4c 18 c0 33       	call   0x33c0:0x184c
    33b4:	8d be fa fd          	lea    di,[bp-0x206]
    33b8:	16                   	push   ss
    33b9:	57                   	push   di
    33ba:	68 ff 00             	push   0xff
    33bd:	9a e7 17 d2 33       	call   0x33d2:0x17e7
    33c2:	6a 00                	push   0x0
    33c4:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    33c8:	b9 04 00             	mov    cx,0x4
    33cb:	f7 e9                	imul   cx
    33cd:	71 05                	jno    0x33d4
    33cf:	9a 3e 04 e8 33       	call   0x33e8:0x43e
    33d4:	50                   	push   ax
    33d5:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    33d9:	06                   	push   es
    33da:	57                   	push   di
    33db:	9a 72 2a fa 33       	call   0x33fa:0x2a72
    33e0:	5a                   	pop    dx
    33e1:	2b c2                	sub    ax,dx
    33e3:	71 05                	jno    0x33ea
    33e5:	9a 3e 04 15 34       	call   0x3415:0x43e
    33ea:	50                   	push   ax
    33eb:	8d be fa fd          	lea    di,[bp-0x206]
    33ef:	16                   	push   ss
    33f0:	57                   	push   di
    33f1:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    33f5:	06                   	push   es
    33f6:	57                   	push   di
    33f7:	9a 04 2a 5b 34       	call   0x345b:0x2a04
    33fc:	89 c7                	mov    di,ax
    33fe:	8e c2                	mov    es,dx
    3400:	06                   	push   es
    3401:	57                   	push   di
    3402:	9a 09 1f 82 34       	call   0x3482:0x1f09
    3407:	8d be e8 fb          	lea    di,[bp-0x418]
    340b:	16                   	push   ss
    340c:	57                   	push   di
    340d:	bf 41 30             	mov    di,0x3041
    3410:	0e                   	push   cs
    3411:	57                   	push   di
    3412:	9a cd 17 2f 34       	call   0x342f:0x17cd
    3417:	8d be e8 fc          	lea    di,[bp-0x318]
    341b:	16                   	push   ss
    341c:	57                   	push   di
    341d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3420:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    3425:	06                   	push   es
    3426:	57                   	push   di
    3427:	9a 53 1d a7 34       	call   0x34a7:0x1d53
    342c:	9a 4c 18 3d 34       	call   0x343d:0x184c
    3431:	8d be fa fd          	lea    di,[bp-0x206]
    3435:	16                   	push   ss
    3436:	57                   	push   di
    3437:	68 ff 00             	push   0xff
    343a:	9a e7 17 4f 34       	call   0x344f:0x17e7
    343f:	6a 00                	push   0x0
    3441:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    3445:	b9 03 00             	mov    cx,0x3
    3448:	f7 e9                	imul   cx
    344a:	71 05                	jno    0x3451
    344c:	9a 3e 04 65 34       	call   0x3465:0x43e
    3451:	50                   	push   ax
    3452:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    3456:	06                   	push   es
    3457:	57                   	push   di
    3458:	9a 72 2a 77 34       	call   0x3477:0x2a72
    345d:	5a                   	pop    dx
    345e:	2b c2                	sub    ax,dx
    3460:	71 05                	jno    0x3467
    3462:	9a 3e 04 92 34       	call   0x3492:0x43e
    3467:	50                   	push   ax
    3468:	8d be fa fd          	lea    di,[bp-0x206]
    346c:	16                   	push   ss
    346d:	57                   	push   di
    346e:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    3472:	06                   	push   es
    3473:	57                   	push   di
    3474:	9a 04 2a d8 34       	call   0x34d8:0x2a04
    3479:	89 c7                	mov    di,ax
    347b:	8e c2                	mov    es,dx
    347d:	06                   	push   es
    347e:	57                   	push   di
    347f:	9a 09 1f ff 34       	call   0x34ff:0x1f09
    3484:	8d be e8 fb          	lea    di,[bp-0x418]
    3488:	16                   	push   ss
    3489:	57                   	push   di
    348a:	bf 41 30             	mov    di,0x3041
    348d:	0e                   	push   cs
    348e:	57                   	push   di
    348f:	9a cd 17 ac 34       	call   0x34ac:0x17cd
    3494:	8d be e8 fc          	lea    di,[bp-0x318]
    3498:	16                   	push   ss
    3499:	57                   	push   di
    349a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    349d:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    34a2:	06                   	push   es
    34a3:	57                   	push   di
    34a4:	9a 53 1d 42 36       	call   0x3642:0x1d53
    34a9:	9a 4c 18 ba 34       	call   0x34ba:0x184c
    34ae:	8d be fa fd          	lea    di,[bp-0x206]
    34b2:	16                   	push   ss
    34b3:	57                   	push   di
    34b4:	68 ff 00             	push   0xff
    34b7:	9a e7 17 cc 34       	call   0x34cc:0x17e7
    34bc:	6a 00                	push   0x0
    34be:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    34c2:	b9 02 00             	mov    cx,0x2
    34c5:	f7 e9                	imul   cx
    34c7:	71 05                	jno    0x34ce
    34c9:	9a 3e 04 e2 34       	call   0x34e2:0x43e
    34ce:	50                   	push   ax
    34cf:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    34d3:	06                   	push   es
    34d4:	57                   	push   di
    34d5:	9a 72 2a f4 34       	call   0x34f4:0x2a72
    34da:	5a                   	pop    dx
    34db:	2b c2                	sub    ax,dx
    34dd:	71 05                	jno    0x34e4
    34df:	9a 3e 04 23 35       	call   0x3523:0x43e
    34e4:	50                   	push   ax
    34e5:	8d be fa fd          	lea    di,[bp-0x206]
    34e9:	16                   	push   ss
    34ea:	57                   	push   di
    34eb:	c4 be e8 fd          	les    di,DWORD PTR [bp-0x218]
    34ef:	06                   	push   es
    34f0:	57                   	push   di
    34f1:	9a 04 2a ff ff       	call   0xffff:0x2a04
    34f6:	89 c7                	mov    di,ax
    34f8:	8e c2                	mov    es,dx
    34fa:	06                   	push   es
    34fb:	57                   	push   di
    34fc:	9a 09 1f ff ff       	call   0xffff:0x1f09
    3501:	8b 86 ee fd          	mov    ax,WORD PTR [bp-0x212]
    3505:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    3509:	74 03                	je     0x350e
    350b:	e9 1d fc             	jmp    0x312b
    350e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3512:	83 c4 06             	add    sp,0x6
    3515:	b8 56 35             	mov    ax,0x3556
    3518:	0e                   	push   cs
    3519:	50                   	push   ax
    351a:	8d be fa fe          	lea    di,[bp-0x106]
    351e:	16                   	push   ss
    351f:	57                   	push   di
    3520:	9a 4f 0a 28 35       	call   0x3528:0xa4f
    3525:	9a 08 04 8b 35       	call   0x358b:0x408
    352a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    352d:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    3532:	06                   	push   es
    3533:	57                   	push   di
    3534:	9a e3 49 26 3a       	call   0x3a26:0x49e3
    3539:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    353d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3540:	26 89 85 cb 03       	mov    WORD PTR es:[di+0x3cb],ax
    3545:	81 c7 50 03          	add    di,0x350
    3549:	06                   	push   es
    354a:	57                   	push   di
    354b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    354e:	06                   	push   es
    354f:	57                   	push   di
    3550:	9a d6 21 80 35       	call   0x3580:0x21d6
    3555:	cb                   	retf
    3556:	c9                   	leave
    3557:	ca 04 00             	retf   0x4
    355a:	01 09                	add    WORD PTR [bx+di],cx
    355c:	01 0d                	add    WORD PTR [di],cx
    355e:	01 0a                	add    WORD PTR [bp+si],cx
    3560:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    3564:	ff                   	(bad)
    3565:	7f 00                	jg     0x3567
    3567:	00 02                	add    BYTE PTR [bp+si],al
    3569:	23 56 02             	and    dx,WORD PTR [bp+0x2]
    356c:	23 43 02             	and    ax,WORD PTR [bp+di+0x2]
    356f:	23 41 00             	and    ax,WORD PTR [bx+di+0x0]
    3572:	00 00                	add    BYTE PTR [bx+si],al
    3574:	00 ff                	add    bh,bh
    3576:	00 00                	add    BYTE PTR [bx+si],al
    3578:	00 02                	add    BYTE PTR [bp+si],al
    357a:	0d 0a 00             	or     ax,0xa
    357d:	00 55 39             	add    BYTE PTR [di+0x39],dl
    3580:	d6                   	(bad)
    3581:	35 55 89             	xor    ax,0x8955
    3584:	e5 b8                	in     ax,0xb8
    3586:	14 03                	adc    al,0x3
    3588:	9a 44 04 94 35       	call   0x3594:0x444
    358d:	81 ec 14 03          	sub    sp,0x314
    3591:	9a ea 01 de 35       	call   0x35de:0x1ea
    3596:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    359a:	89 96 f0 fe          	mov    WORD PTR [bp-0x110],dx
    359e:	83 be f0 fe 00       	cmp    WORD PTR [bp-0x110],0x0
    35a3:	7f 10                	jg     0x35b5
    35a5:	7d 03                	jge    0x35aa
    35a7:	e9 e7 03             	jmp    0x3991
    35aa:	81 be ee fe 30 75    	cmp    WORD PTR [bp-0x112],0x7530
    35b0:	77 03                	ja     0x35b5
    35b2:	e9 dc 03             	jmp    0x3991
    35b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35b8:	26 8b 85 cb 03       	mov    ax,WORD PTR es:[di+0x3cb]
    35bd:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    35c1:	26 c7 85 cb 03 14 00 	mov    WORD PTR es:[di+0x3cb],0x14
    35c8:	81 c7 50 03          	add    di,0x350
    35cc:	06                   	push   es
    35cd:	57                   	push   di
    35ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35d1:	06                   	push   es
    35d2:	57                   	push   di
    35d3:	9a d6 21 8e 39       	call   0x398e:0x21d6
    35d8:	68 30 75             	push   0x7530
    35db:	9a 82 01 ed 35       	call   0x35ed:0x182
    35e0:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    35e4:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    35e8:	6a 64                	push   0x64
    35ea:	9a 82 01 23 36       	call   0x3623:0x182
    35ef:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    35f3:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    35f7:	b8 7c 35             	mov    ax,0x357c
    35fa:	0e                   	push   cs
    35fb:	50                   	push   ax
    35fc:	55                   	push   bp
    35fd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3601:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3605:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    3609:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    360d:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    3611:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3615:	8d be ec fd          	lea    di,[bp-0x214]
    3619:	16                   	push   ss
    361a:	57                   	push   di
    361b:	bf fa 1d             	mov    di,0x1dfa
    361e:	1e                   	push   ds
    361f:	57                   	push   di
    3620:	9a cd 17 2d 36       	call   0x362d:0x17cd
    3625:	bf 5a 35             	mov    di,0x355a
    3628:	0e                   	push   cs
    3629:	57                   	push   di
    362a:	9a 4c 18 47 36       	call   0x3647:0x184c
    362f:	8d be ec fc          	lea    di,[bp-0x314]
    3633:	16                   	push   ss
    3634:	57                   	push   di
    3635:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3638:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    363d:	06                   	push   es
    363e:	57                   	push   di
    363f:	9a 53 1d 55 3a       	call   0x3a55:0x1d53
    3644:	9a 4c 18 51 36       	call   0x3651:0x184c
    3649:	bf 5c 35             	mov    di,0x355c
    364c:	0e                   	push   cs
    364d:	57                   	push   di
    364e:	9a 4c 18 5b 36       	call   0x365b:0x184c
    3653:	bf 5e 35             	mov    di,0x355e
    3656:	0e                   	push   cs
    3657:	57                   	push   di
    3658:	9a 4c 18 69 36       	call   0x3669:0x184c
    365d:	8d be 00 ff          	lea    di,[bp-0x100]
    3661:	16                   	push   ss
    3662:	57                   	push   di
    3663:	68 ff 00             	push   0xff
    3666:	9a e7 17 b8 36       	call   0x36b8:0x17e7
    366b:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    366f:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    3673:	8d be 00 ff          	lea    di,[bp-0x100]
    3677:	16                   	push   ss
    3678:	57                   	push   di
    3679:	9a 4c 0d 91 36       	call   0x3691:0xd4c
    367e:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    3682:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    3686:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    368a:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    368e:	9a 8f 0d b8 38       	call   0x38b8:0xd8f
    3693:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3696:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    369b:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    369f:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    36a3:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    36a8:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    36ad:	2d 01 00             	sub    ax,0x1
    36b0:	83 da 00             	sbb    dx,0x0
    36b3:	71 05                	jno    0x36ba
    36b5:	9a 3e 04 c0 36       	call   0x36c0:0x43e
    36ba:	bf 60 35             	mov    di,0x3560
    36bd:	9a 16 04 f4 36       	call   0x36f4:0x416
    36c2:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    36c6:	31 c0                	xor    ax,ax
    36c8:	3b 86 e6 fe          	cmp    ax,WORD PTR [bp-0x11a]
    36cc:	7e 03                	jle    0x36d1
    36ce:	e9 53 02             	jmp    0x3924
    36d1:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    36d5:	eb 04                	jmp    0x36db
    36d7:	ff 86 fc fe          	inc    WORD PTR [bp-0x104]
    36db:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    36df:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    36e4:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    36e9:	2d 01 00             	sub    ax,0x1
    36ec:	83 da 00             	sbb    dx,0x0
    36ef:	71 05                	jno    0x36f6
    36f1:	9a 3e 04 fc 36       	call   0x36fc:0x43e
    36f6:	bf 60 35             	mov    di,0x3560
    36f9:	9a 16 04 3c 37       	call   0x373c:0x416
    36fe:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    3702:	31 c0                	xor    ax,ax
    3704:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    3708:	7e 03                	jle    0x370d
    370a:	e9 cf 01             	jmp    0x38dc
    370d:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    3711:	eb 04                	jmp    0x3717
    3713:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    3717:	8d be e4 fd          	lea    di,[bp-0x21c]
    371b:	16                   	push   ss
    371c:	57                   	push   di
    371d:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    3721:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    3725:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    3729:	06                   	push   es
    372a:	57                   	push   di
    372b:	9a 68 9a 73 3b       	call   0x3b73:0x9a68
    3730:	8d be 00 ff          	lea    di,[bp-0x100]
    3734:	16                   	push   ss
    3735:	57                   	push   di
    3736:	68 ff 00             	push   0xff
    3739:	9a e7 17 4c 37       	call   0x374c:0x17e7
    373e:	bf 68 35             	mov    di,0x3568
    3741:	0e                   	push   cs
    3742:	57                   	push   di
    3743:	8d be 00 ff          	lea    di,[bp-0x100]
    3747:	16                   	push   ss
    3748:	57                   	push   di
    3749:	9a 78 18 68 37       	call   0x3768:0x1878
    374e:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    3752:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    3757:	7e 11                	jle    0x376a
    3759:	8d be 00 ff          	lea    di,[bp-0x100]
    375d:	16                   	push   ss
    375e:	57                   	push   di
    375f:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    3763:	6a 02                	push   0x2
    3765:	9a 75 19 7f 37       	call   0x377f:0x1975
    376a:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    376f:	75 cd                	jne    0x373e
    3771:	bf 6b 35             	mov    di,0x356b
    3774:	0e                   	push   cs
    3775:	57                   	push   di
    3776:	8d be 00 ff          	lea    di,[bp-0x100]
    377a:	16                   	push   ss
    377b:	57                   	push   di
    377c:	9a 78 18 9b 37       	call   0x379b:0x1878
    3781:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    3785:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    378a:	7e 11                	jle    0x379d
    378c:	8d be 00 ff          	lea    di,[bp-0x100]
    3790:	16                   	push   ss
    3791:	57                   	push   di
    3792:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    3796:	6a 03                	push   0x3
    3798:	9a 75 19 b2 37       	call   0x37b2:0x1975
    379d:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    37a2:	75 cd                	jne    0x3771
    37a4:	bf 6e 35             	mov    di,0x356e
    37a7:	0e                   	push   cs
    37a8:	57                   	push   di
    37a9:	8d be 00 ff          	lea    di,[bp-0x100]
    37ad:	16                   	push   ss
    37ae:	57                   	push   di
    37af:	9a 78 18 ce 37       	call   0x37ce:0x1878
    37b4:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    37b8:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    37bd:	7e 11                	jle    0x37d0
    37bf:	8d be 00 ff          	lea    di,[bp-0x100]
    37c3:	16                   	push   ss
    37c4:	57                   	push   di
    37c5:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    37c9:	6a 03                	push   0x3
    37cb:	9a 75 19 00 38       	call   0x3800:0x1975
    37d0:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    37d5:	75 cd                	jne    0x37a4
    37d7:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    37dc:	b0 00                	mov    al,0x0
    37de:	76 01                	jbe    0x37e1
    37e0:	40                   	inc    ax
    37e1:	8a d0                	mov    dl,al
    37e3:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    37e8:	b0 00                	mov    al,0x0
    37ea:	75 01                	jne    0x37ed
    37ec:	40                   	inc    ax
    37ed:	22 c2                	and    al,dl
    37ef:	08 c0                	or     al,al
    37f1:	74 11                	je     0x3804
    37f3:	8d be 00 ff          	lea    di,[bp-0x100]
    37f7:	16                   	push   ss
    37f8:	57                   	push   di
    37f9:	6a 01                	push   0x1
    37fb:	6a 01                	push   0x1
    37fd:	9a 75 19 19 38       	call   0x3819:0x1975
    3802:	eb d3                	jmp    0x37d7
    3804:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    3808:	30 e4                	xor    ah,ah
    380a:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    380e:	8b 86 fa fe          	mov    ax,WORD PTR [bp-0x106]
    3812:	99                   	cwd
    3813:	bf 71 35             	mov    di,0x3571
    3816:	9a 16 04 48 38       	call   0x3848:0x416
    381b:	8b f8                	mov    di,ax
    381d:	80 bb 00 ff 20       	cmp    BYTE PTR [bp+di-0x100],0x20
    3822:	b0 00                	mov    al,0x0
    3824:	75 01                	jne    0x3827
    3826:	40                   	inc    ax
    3827:	8a d0                	mov    dl,al
    3829:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    382e:	b0 00                	mov    al,0x0
    3830:	7e 01                	jle    0x3833
    3832:	40                   	inc    ax
    3833:	22 c2                	and    al,dl
    3835:	08 c0                	or     al,al
    3837:	74 17                	je     0x3850
    3839:	8d be 00 ff          	lea    di,[bp-0x100]
    383d:	16                   	push   ss
    383e:	57                   	push   di
    383f:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    3843:	6a 01                	push   0x1
    3845:	9a 75 19 69 38       	call   0x3869:0x1975
    384a:	ff 8e fa fe          	dec    WORD PTR [bp-0x106]
    384e:	eb be                	jmp    0x380e
    3850:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    3854:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    3859:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    385e:	2d 01 00             	sub    ax,0x1
    3861:	83 da 00             	sbb    dx,0x0
    3864:	71 05                	jno    0x386b
    3866:	9a 3e 04 8d 38       	call   0x388d:0x43e
    386b:	8b c8                	mov    cx,ax
    386d:	8b da                	mov    bx,dx
    386f:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    3873:	99                   	cwd
    3874:	3b d3                	cmp    dx,bx
    3876:	7c 06                	jl     0x387e
    3878:	7f 2d                	jg     0x38a7
    387a:	3b c1                	cmp    ax,cx
    387c:	73 29                	jae    0x38a7
    387e:	8d be e4 fd          	lea    di,[bp-0x21c]
    3882:	16                   	push   ss
    3883:	57                   	push   di
    3884:	8d be 00 ff          	lea    di,[bp-0x100]
    3888:	16                   	push   ss
    3889:	57                   	push   di
    388a:	9a cd 17 97 38       	call   0x3897:0x17cd
    388f:	bf 5a 35             	mov    di,0x355a
    3892:	0e                   	push   cs
    3893:	57                   	push   di
    3894:	9a 4c 18 a5 38       	call   0x38a5:0x184c
    3899:	8d be 00 ff          	lea    di,[bp-0x100]
    389d:	16                   	push   ss
    389e:	57                   	push   di
    389f:	68 ff 00             	push   0xff
    38a2:	9a e7 17 ed 38       	call   0x38ed:0x17e7
    38a7:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    38ab:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    38af:	8d be 00 ff          	lea    di,[bp-0x100]
    38b3:	16                   	push   ss
    38b4:	57                   	push   di
    38b5:	9a 4c 0d cd 38       	call   0x38cd:0xd4c
    38ba:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    38be:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    38c2:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    38c6:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    38ca:	9a 8f 0d 00 39       	call   0x3900:0xd8f
    38cf:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    38d3:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    38d7:	74 03                	je     0x38dc
    38d9:	e9 37 fe             	jmp    0x3713
    38dc:	bf 79 35             	mov    di,0x3579
    38df:	0e                   	push   cs
    38e0:	57                   	push   di
    38e1:	8d be 00 ff          	lea    di,[bp-0x100]
    38e5:	16                   	push   ss
    38e6:	57                   	push   di
    38e7:	68 ff 00             	push   0xff
    38ea:	9a e7 17 62 39       	call   0x3962:0x17e7
    38ef:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    38f3:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    38f7:	8d be 00 ff          	lea    di,[bp-0x100]
    38fb:	16                   	push   ss
    38fc:	57                   	push   di
    38fd:	9a 4c 0d 15 39       	call   0x3915:0xd4c
    3902:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    3906:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    390a:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    390e:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    3912:	9a 8f 0d 3a 39       	call   0x393a:0xd8f
    3917:	8b 86 fc fe          	mov    ax,WORD PTR [bp-0x104]
    391b:	3b 86 e6 fe          	cmp    ax,WORD PTR [bp-0x11a]
    391f:	74 03                	je     0x3924
    3921:	e9 b3 fd             	jmp    0x36d7
    3924:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    3928:	06                   	push   es
    3929:	57                   	push   di
    392a:	9a a1 36 47 39       	call   0x3947:0x36a1
    392f:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    3933:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    3937:	9a d6 0e ff ff       	call   0xffff:0xed6
    393c:	52                   	push   dx
    393d:	50                   	push   ax
    393e:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    3942:	06                   	push   es
    3943:	57                   	push   di
    3944:	9a 99 39 ff ff       	call   0xffff:0x3999
    3949:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    394d:	83 c4 06             	add    sp,0x6
    3950:	b8 91 39             	mov    ax,0x3991
    3953:	0e                   	push   cs
    3954:	50                   	push   ax
    3955:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    3959:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    395d:	6a 64                	push   0x64
    395f:	9a 9c 01 72 39       	call   0x3972:0x19c
    3964:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    3968:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    396c:	68 30 75             	push   0x7530
    396f:	9a 9c 01 bb 39       	call   0x39bb:0x19c
    3974:	8b 86 ec fe          	mov    ax,WORD PTR [bp-0x114]
    3978:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    397b:	26 89 85 cb 03       	mov    WORD PTR es:[di+0x3cb],ax
    3980:	81 c7 50 03          	add    di,0x350
    3984:	06                   	push   es
    3985:	57                   	push   di
    3986:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3989:	06                   	push   es
    398a:	57                   	push   di
    398b:	9a d6 21 f7 4d       	call   0x4df7:0x21d6
    3990:	cb                   	retf
    3991:	c9                   	leave
    3992:	ca 08 00             	retf   0x8
    3995:	01 09                	add    WORD PTR [bx+di],cx
    3997:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    399b:	ff                   	(bad)
    399c:	7f 00                	jg     0x399e
    399e:	00 02                	add    BYTE PTR [bp+si],al
    39a0:	23 56 02             	and    dx,WORD PTR [bp+0x2]
    39a3:	23 43 02             	and    ax,WORD PTR [bp+di+0x2]
    39a6:	23 41 00             	and    ax,WORD PTR [bx+di+0x0]
    39a9:	00 00                	add    BYTE PTR [bx+si],al
    39ab:	00 ff                	add    bh,bh
    39ad:	00 00                	add    BYTE PTR [bx+si],al
    39af:	00 01                	add    BYTE PTR [bx+di],al
    39b1:	20 55 89             	and    BYTE PTR [di-0x77],dl
    39b4:	e5 b8                	in     ax,0xb8
    39b6:	0e                   	push   cs
    39b7:	04 9a                	add    al,0x9a
    39b9:	44                   	inc    sp
    39ba:	04 36                	add    al,0x36
    39bc:	3a 81 ec 0e          	cmp    al,BYTE PTR [bx+di+0xeec]
    39c0:	04 8b                	add    al,0x8b
    39c2:	46                   	inc    si
    39c3:	0a 3d                	or     bh,BYTE PTR [di]
    39c5:	00 00                	add    BYTE PTR [bx+si],al
    39c7:	75 0e                	jne    0x39d7
    39c9:	c7 86 f8 fd 01 00    	mov    WORD PTR [bp-0x208],0x1
    39cf:	c7 86 f6 fd 08 00    	mov    WORD PTR [bp-0x20a],0x8
    39d5:	eb 29                	jmp    0x3a00
    39d7:	3d 01 00             	cmp    ax,0x1
    39da:	75 0e                	jne    0x39ea
    39dc:	c7 86 f8 fd 01 00    	mov    WORD PTR [bp-0x208],0x1
    39e2:	c7 86 f6 fd 04 00    	mov    WORD PTR [bp-0x20a],0x4
    39e8:	eb 16                	jmp    0x3a00
    39ea:	3d 02 00             	cmp    ax,0x2
    39ed:	75 0e                	jne    0x39fd
    39ef:	c7 86 f8 fd 05 00    	mov    WORD PTR [bp-0x208],0x5
    39f5:	c7 86 f6 fd 08 00    	mov    WORD PTR [bp-0x20a],0x8
    39fb:	eb 03                	jmp    0x3a00
    39fd:	e9 ee 03             	jmp    0x3dee
    3a00:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    3a04:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    3a08:	7e 07                	jle    0x3a11
    3a0a:	a1 4e 01             	mov    ax,ds:0x14e
    3a0d:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    3a11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a14:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    3a19:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    3a1d:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    3a21:	06                   	push   es
    3a22:	57                   	push   di
    3a23:	9a e3 49 ff ff       	call   0xffff:0x49e3
    3a28:	8d be f2 fc          	lea    di,[bp-0x30e]
    3a2c:	16                   	push   ss
    3a2d:	57                   	push   di
    3a2e:	bf fa 1d             	mov    di,0x1dfa
    3a31:	1e                   	push   ds
    3a32:	57                   	push   di
    3a33:	9a cd 17 40 3a       	call   0x3a40:0x17cd
    3a38:	bf 95 39             	mov    di,0x3995
    3a3b:	0e                   	push   cs
    3a3c:	57                   	push   di
    3a3d:	9a 4c 18 5a 3a       	call   0x3a5a:0x184c
    3a42:	8d be f2 fb          	lea    di,[bp-0x40e]
    3a46:	16                   	push   ss
    3a47:	57                   	push   di
    3a48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a4b:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    3a50:	06                   	push   es
    3a51:	57                   	push   di
    3a52:	9a 53 1d ff ff       	call   0xffff:0x1d53
    3a57:	9a 4c 18 68 3a       	call   0x3a68:0x184c
    3a5c:	8d be 00 ff          	lea    di,[bp-0x100]
    3a60:	16                   	push   ss
    3a61:	57                   	push   di
    3a62:	68 ff 00             	push   0xff
    3a65:	9a e7 17 a7 3a       	call   0x3aa7:0x17e7
    3a6a:	8d be 00 ff          	lea    di,[bp-0x100]
    3a6e:	16                   	push   ss
    3a6f:	57                   	push   di
    3a70:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3a74:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3a79:	06                   	push   es
    3a7a:	57                   	push   di
    3a7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a7e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a85:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    3a8a:	89 be ee fd          	mov    WORD PTR [bp-0x212],di
    3a8e:	8c 86 f0 fd          	mov    WORD PTR [bp-0x210],es
    3a92:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3a97:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    3a9c:	2d 01 00             	sub    ax,0x1
    3a9f:	83 da 00             	sbb    dx,0x0
    3aa2:	71 05                	jno    0x3aa9
    3aa4:	9a 3e 04 af 3a       	call   0x3aaf:0x43e
    3aa9:	bf 97 39             	mov    di,0x3997
    3aac:	9a 16 04 e8 3a       	call   0x3ae8:0x416
    3ab1:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    3ab5:	31 c0                	xor    ax,ax
    3ab7:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    3abb:	7e 03                	jle    0x3ac0
    3abd:	e9 2e 03             	jmp    0x3dee
    3ac0:	89 86 fc fd          	mov    WORD PTR [bp-0x204],ax
    3ac4:	eb 04                	jmp    0x3aca
    3ac6:	ff 86 fc fd          	inc    WORD PTR [bp-0x204]
    3aca:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3acf:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    3ad3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    3ad8:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    3add:	2d 01 00             	sub    ax,0x1
    3ae0:	83 da 00             	sbb    dx,0x0
    3ae3:	71 05                	jno    0x3aea
    3ae5:	9a 3e 04 f0 3a       	call   0x3af0:0x43e
    3aea:	bf 97 39             	mov    di,0x3997
    3aed:	9a 16 04 17 3b       	call   0x3b17:0x416
    3af2:	89 86 ea fd          	mov    WORD PTR [bp-0x216],ax
    3af6:	31 c0                	xor    ax,ax
    3af8:	3b 86 ea fd          	cmp    ax,WORD PTR [bp-0x216]
    3afc:	7e 03                	jle    0x3b01
    3afe:	e9 c8 02             	jmp    0x3dc9
    3b01:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    3b05:	eb 04                	jmp    0x3b0b
    3b07:	ff 86 fe fd          	inc    WORD PTR [bp-0x202]
    3b0b:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    3b0f:	05 01 00             	add    ax,0x1
    3b12:	71 05                	jno    0x3b19
    3b14:	9a 3e 04 30 3b       	call   0x3b30:0x43e
    3b19:	3b 86 fe fd          	cmp    ax,WORD PTR [bp-0x202]
    3b1d:	b0 00                	mov    al,0x0
    3b1f:	7e 01                	jle    0x3b22
    3b21:	40                   	inc    ax
    3b22:	8a d0                	mov    dl,al
    3b24:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    3b28:	2d 01 00             	sub    ax,0x1
    3b2b:	71 05                	jno    0x3b32
    3b2d:	9a 3e 04 3a 3b       	call   0x3b3a:0x43e
    3b32:	05 01 00             	add    ax,0x1
    3b35:	71 05                	jno    0x3b3c
    3b37:	9a 3e 04 81 3b       	call   0x3b81:0x43e
    3b3c:	3b 86 fe fd          	cmp    ax,WORD PTR [bp-0x202]
    3b40:	b0 00                	mov    al,0x0
    3b42:	7f 01                	jg     0x3b45
    3b44:	40                   	inc    ax
    3b45:	22 c2                	and    al,dl
    3b47:	8a d0                	mov    dl,al
    3b49:	83 be fe fd 01       	cmp    WORD PTR [bp-0x202],0x1
    3b4e:	b0 00                	mov    al,0x0
    3b50:	7d 01                	jge    0x3b53
    3b52:	40                   	inc    ax
    3b53:	0a c2                	or     al,dl
    3b55:	08 c0                	or     al,al
    3b57:	75 03                	jne    0x3b5c
    3b59:	e9 60 02             	jmp    0x3dbc
    3b5c:	8d be ea fc          	lea    di,[bp-0x316]
    3b60:	16                   	push   ss
    3b61:	57                   	push   di
    3b62:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    3b66:	ff b6 fc fd          	push   WORD PTR [bp-0x204]
    3b6a:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    3b6e:	06                   	push   es
    3b6f:	57                   	push   di
    3b70:	9a 68 9a 87 4f       	call   0x4f87:0x9a68
    3b75:	8d be 00 fe          	lea    di,[bp-0x200]
    3b79:	16                   	push   ss
    3b7a:	57                   	push   di
    3b7b:	68 ff 00             	push   0xff
    3b7e:	9a e7 17 91 3b       	call   0x3b91:0x17e7
    3b83:	bf 9f 39             	mov    di,0x399f
    3b86:	0e                   	push   cs
    3b87:	57                   	push   di
    3b88:	8d be 00 fe          	lea    di,[bp-0x200]
    3b8c:	16                   	push   ss
    3b8d:	57                   	push   di
    3b8e:	9a 78 18 ad 3b       	call   0x3bad:0x1878
    3b93:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3b97:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3b9c:	7e 11                	jle    0x3baf
    3b9e:	8d be 00 fe          	lea    di,[bp-0x200]
    3ba2:	16                   	push   ss
    3ba3:	57                   	push   di
    3ba4:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    3ba8:	6a 02                	push   0x2
    3baa:	9a 75 19 c4 3b       	call   0x3bc4:0x1975
    3baf:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3bb4:	75 cd                	jne    0x3b83
    3bb6:	bf a2 39             	mov    di,0x39a2
    3bb9:	0e                   	push   cs
    3bba:	57                   	push   di
    3bbb:	8d be 00 fe          	lea    di,[bp-0x200]
    3bbf:	16                   	push   ss
    3bc0:	57                   	push   di
    3bc1:	9a 78 18 e0 3b       	call   0x3be0:0x1878
    3bc6:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3bca:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3bcf:	7e 11                	jle    0x3be2
    3bd1:	8d be 00 fe          	lea    di,[bp-0x200]
    3bd5:	16                   	push   ss
    3bd6:	57                   	push   di
    3bd7:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    3bdb:	6a 03                	push   0x3
    3bdd:	9a 75 19 f7 3b       	call   0x3bf7:0x1975
    3be2:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3be7:	75 cd                	jne    0x3bb6
    3be9:	bf a5 39             	mov    di,0x39a5
    3bec:	0e                   	push   cs
    3bed:	57                   	push   di
    3bee:	8d be 00 fe          	lea    di,[bp-0x200]
    3bf2:	16                   	push   ss
    3bf3:	57                   	push   di
    3bf4:	9a 78 18 13 3c       	call   0x3c13:0x1878
    3bf9:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3bfd:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3c02:	7e 11                	jle    0x3c15
    3c04:	8d be 00 fe          	lea    di,[bp-0x200]
    3c08:	16                   	push   ss
    3c09:	57                   	push   di
    3c0a:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    3c0e:	6a 03                	push   0x3
    3c10:	9a 75 19 4b 3c       	call   0x3c4b:0x1975
    3c15:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3c1a:	75 cd                	jne    0x3be9
    3c1c:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    3c20:	75 79                	jne    0x3c9b
    3c22:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3c27:	b0 00                	mov    al,0x0
    3c29:	76 01                	jbe    0x3c2c
    3c2b:	40                   	inc    ax
    3c2c:	8a d0                	mov    dl,al
    3c2e:	80 be 01 fe 20       	cmp    BYTE PTR [bp-0x1ff],0x20
    3c33:	b0 00                	mov    al,0x0
    3c35:	75 01                	jne    0x3c38
    3c37:	40                   	inc    ax
    3c38:	22 c2                	and    al,dl
    3c3a:	08 c0                	or     al,al
    3c3c:	74 11                	je     0x3c4f
    3c3e:	8d be 00 fe          	lea    di,[bp-0x200]
    3c42:	16                   	push   ss
    3c43:	57                   	push   di
    3c44:	6a 01                	push   0x1
    3c46:	6a 01                	push   0x1
    3c48:	9a 75 19 64 3c       	call   0x3c64:0x1975
    3c4d:	eb d3                	jmp    0x3c22
    3c4f:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    3c53:	30 e4                	xor    ah,ah
    3c55:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3c59:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3c5d:	99                   	cwd
    3c5e:	bf a8 39             	mov    di,0x39a8
    3c61:	9a 16 04 93 3c       	call   0x3c93:0x416
    3c66:	8b f8                	mov    di,ax
    3c68:	80 bb 00 fe 20       	cmp    BYTE PTR [bp+di-0x200],0x20
    3c6d:	b0 00                	mov    al,0x0
    3c6f:	75 01                	jne    0x3c72
    3c71:	40                   	inc    ax
    3c72:	8a d0                	mov    dl,al
    3c74:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    3c79:	b0 00                	mov    al,0x0
    3c7b:	7e 01                	jle    0x3c7e
    3c7d:	40                   	inc    ax
    3c7e:	22 c2                	and    al,dl
    3c80:	08 c0                	or     al,al
    3c82:	74 17                	je     0x3c9b
    3c84:	8d be 00 fe          	lea    di,[bp-0x200]
    3c88:	16                   	push   ss
    3c89:	57                   	push   di
    3c8a:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    3c8e:	6a 01                	push   0x1
    3c90:	9a 75 19 cb 3c       	call   0x3ccb:0x1975
    3c95:	ff 8e fa fd          	dec    WORD PTR [bp-0x206]
    3c99:	eb be                	jmp    0x3c59
    3c9b:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    3c9f:	74 03                	je     0x3ca4
    3ca1:	e9 b1 00             	jmp    0x3d55
    3ca4:	83 be fe fd 00       	cmp    WORD PTR [bp-0x202],0x0
    3ca9:	75 6a                	jne    0x3d15
    3cab:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    3caf:	30 e4                	xor    ah,ah
    3cb1:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3cb5:	83 be fa fd 1c       	cmp    WORD PTR [bp-0x206],0x1c
    3cba:	7e 17                	jle    0x3cd3
    3cbc:	8d be 00 fe          	lea    di,[bp-0x200]
    3cc0:	16                   	push   ss
    3cc1:	57                   	push   di
    3cc2:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    3cc6:	6a 01                	push   0x1
    3cc8:	9a 75 19 f7 3c       	call   0x3cf7:0x1975
    3ccd:	ff 8e fa fd          	dec    WORD PTR [bp-0x206]
    3cd1:	eb e2                	jmp    0x3cb5
    3cd3:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    3cd7:	30 e4                	xor    ah,ah
    3cd9:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3cdd:	83 be fa fd 1c       	cmp    WORD PTR [bp-0x206],0x1c
    3ce2:	7d 2f                	jge    0x3d13
    3ce4:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    3ce8:	8d be ea fc          	lea    di,[bp-0x316]
    3cec:	16                   	push   ss
    3ced:	57                   	push   di
    3cee:	8d be 00 fe          	lea    di,[bp-0x200]
    3cf2:	16                   	push   ss
    3cf3:	57                   	push   di
    3cf4:	9a cd 17 01 3d       	call   0x3d01:0x17cd
    3cf9:	bf b0 39             	mov    di,0x39b0
    3cfc:	0e                   	push   cs
    3cfd:	57                   	push   di
    3cfe:	9a 4c 18 0f 3d       	call   0x3d0f:0x184c
    3d03:	8d be 00 fe          	lea    di,[bp-0x200]
    3d07:	16                   	push   ss
    3d08:	57                   	push   di
    3d09:	68 ff 00             	push   0xff
    3d0c:	9a e7 17 38 3d       	call   0x3d38:0x17e7
    3d11:	eb ca                	jmp    0x3cdd
    3d13:	eb 40                	jmp    0x3d55
    3d15:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    3d19:	30 e4                	xor    ah,ah
    3d1b:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3d1f:	83 be fa fd 14       	cmp    WORD PTR [bp-0x206],0x14
    3d24:	7d 2f                	jge    0x3d55
    3d26:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    3d2a:	8d be ea fc          	lea    di,[bp-0x316]
    3d2e:	16                   	push   ss
    3d2f:	57                   	push   di
    3d30:	bf b0 39             	mov    di,0x39b0
    3d33:	0e                   	push   cs
    3d34:	57                   	push   di
    3d35:	9a cd 17 43 3d       	call   0x3d43:0x17cd
    3d3a:	8d be 00 fe          	lea    di,[bp-0x200]
    3d3e:	16                   	push   ss
    3d3f:	57                   	push   di
    3d40:	9a 4c 18 51 3d       	call   0x3d51:0x184c
    3d45:	8d be 00 fe          	lea    di,[bp-0x200]
    3d49:	16                   	push   ss
    3d4a:	57                   	push   di
    3d4b:	68 ff 00             	push   0xff
    3d4e:	9a e7 17 61 3d       	call   0x3d61:0x17e7
    3d53:	eb ca                	jmp    0x3d1f
    3d55:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    3d59:	2d 01 00             	sub    ax,0x1
    3d5c:	71 05                	jno    0x3d63
    3d5e:	9a 3e 04 78 3d       	call   0x3d78:0x43e
    3d63:	3b 86 fe fd          	cmp    ax,WORD PTR [bp-0x202]
    3d67:	7e 29                	jle    0x3d92
    3d69:	8d be ea fc          	lea    di,[bp-0x316]
    3d6d:	16                   	push   ss
    3d6e:	57                   	push   di
    3d6f:	8d be 00 fe          	lea    di,[bp-0x200]
    3d73:	16                   	push   ss
    3d74:	57                   	push   di
    3d75:	9a cd 17 82 3d       	call   0x3d82:0x17cd
    3d7a:	bf 95 39             	mov    di,0x3995
    3d7d:	0e                   	push   cs
    3d7e:	57                   	push   di
    3d7f:	9a 4c 18 90 3d       	call   0x3d90:0x184c
    3d84:	8d be 00 fe          	lea    di,[bp-0x200]
    3d88:	16                   	push   ss
    3d89:	57                   	push   di
    3d8a:	68 ff 00             	push   0xff
    3d8d:	9a e7 17 a1 3d       	call   0x3da1:0x17e7
    3d92:	8d be ea fc          	lea    di,[bp-0x316]
    3d96:	16                   	push   ss
    3d97:	57                   	push   di
    3d98:	8d be 00 ff          	lea    di,[bp-0x100]
    3d9c:	16                   	push   ss
    3d9d:	57                   	push   di
    3d9e:	9a cd 17 ac 3d       	call   0x3dac:0x17cd
    3da3:	8d be 00 fe          	lea    di,[bp-0x200]
    3da7:	16                   	push   ss
    3da8:	57                   	push   di
    3da9:	9a 4c 18 ba 3d       	call   0x3dba:0x184c
    3dae:	8d be 00 ff          	lea    di,[bp-0x100]
    3db2:	16                   	push   ss
    3db3:	57                   	push   di
    3db4:	68 ff 00             	push   0xff
    3db7:	9a e7 17 2b 40       	call   0x402b:0x17e7
    3dbc:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    3dc0:	3b 86 ea fd          	cmp    ax,WORD PTR [bp-0x216]
    3dc4:	74 03                	je     0x3dc9
    3dc6:	e9 3e fd             	jmp    0x3b07
    3dc9:	8d be 00 ff          	lea    di,[bp-0x100]
    3dcd:	16                   	push   ss
    3dce:	57                   	push   di
    3dcf:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3dd3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3dd8:	06                   	push   es
    3dd9:	57                   	push   di
    3dda:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ddd:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3de1:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    3de5:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    3de9:	74 03                	je     0x3dee
    3deb:	e9 d8 fc             	jmp    0x3ac6
    3dee:	c9                   	leave
    3def:	ca 08 00             	retf   0x8
    3df2:	13 54 72             	adc    dx,WORD PTR [si+0x72]
    3df5:	65 73 6f             	gs jae 0x3e67
    3df8:	72 65                	jb     0x3e5f
    3dfa:	72 69                	jb     0x3e65
    3dfc:	65 50                	gs push ax
    3dfe:	6c                   	ins    BYTE PTR es:[di],dx
    3dff:	75 73                	jne    0x3e74
    3e01:	4d                   	dec    bp
    3e02:	6f                   	outs   dx,WORD PTR ds:[si]
    3e03:	69 6e 73 0a 54       	imul   bp,WORD PTR [bp+0x73],0x540a
    3e08:	72 65                	jb     0x3e6f
    3e0a:	73 6f                	jae    0x3e7b
    3e0c:	72 65                	jb     0x3e73
    3e0e:	72 69                	jb     0x3e79
    3e10:	65 0d 44 65          	gs or  ax,0x6544
    3e14:	63 6f 75             	arpl   WORD PTR [bx+0x75],bp
    3e17:	76 65                	jbe    0x3e7e
    3e19:	72 74                	jb     0x3e8f
    3e1b:	41                   	inc    cx
    3e1c:	75 74                	jne    0x3e92
    3e1e:	6f                   	outs   dx,WORD PTR ds:[si]
    3e1f:	0e                   	push   cs
    3e20:	44                   	inc    sp
    3e21:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3e25:	76 65                	jbe    0x3e8c
    3e27:	72 74                	jb     0x3e9d
    3e29:	4e                   	dec    si
    3e2a:	41                   	inc    cx
    3e2b:	75 74                	jne    0x3ea1
    3e2d:	6f                   	outs   dx,WORD PTR ds:[si]
    3e2e:	05 49 6d             	add    ax,0x6d49
    3e31:	70 6f                	jo     0x3ea2
    3e33:	74 0c                	je     0x3e41
    3e35:	46                   	inc    si
    3e36:	6f                   	outs   dx,WORD PTR ds:[si]
    3e37:	75 72                	jne    0x3eab
    3e39:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e3a:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    3e3f:	72 73                	jb     0x3eb4
    3e41:	07                   	pop    es
    3e42:	45                   	inc    bp
    3e43:	6d                   	ins    WORD PTR es:[di],dx
    3e44:	70 72                	jo     0x3eb8
    3e46:	75 6e                	jne    0x3eb6
    3e48:	74 0e                	je     0x3e58
    3e4a:	53                   	push   bx
    3e4b:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
    3e50:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
    3e55:	74 74                	je     0x3ecb
    3e57:	65 0d 45 6e          	gs or  ax,0x6e45
    3e5b:	64 65 74 74          	fs gs je 0x3ed3
    3e5f:	65 6d                	gs ins WORD PTR es:[di],dx
    3e61:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e63:	74 50                	je     0x3eb5
    3e65:	43                   	inc    bx
    3e66:	00 00                	add    BYTE PTR [bx+si],al
    3e68:	c8 42 06 56          	enter  0x642,0x56
    3e6c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e6e:	74 65                	je     0x3ed5
    3e70:	73 04                	jae    0x3e76
    3e72:	50                   	push   ax
    3e73:	72 69                	jb     0x3ede
    3e75:	78 10                	js     0x3e87
    3e77:	56                   	push   si
    3e78:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e7a:	74 65                	je     0x3ee1
    3e7c:	73 53                	jae    0x3ed1
    3e7e:	6f                   	outs   dx,WORD PTR ds:[si]
    3e7f:	6c                   	ins    BYTE PTR es:[di],dx
    3e80:	64 65 65 73 51       	fs gs gs jae 0x3ed6
    3e85:	74 65                	je     0x3eec
    3e87:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    3e8a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e8b:	74 65                	je     0x3ef2
    3e8d:	73 53                	jae    0x3ee2
    3e8f:	6f                   	outs   dx,WORD PTR ds:[si]
    3e90:	6c                   	ins    BYTE PTR es:[di],dx
    3e91:	64 65 65 73 50       	fs gs gs jae 0x3ee6
    3e96:	72 69                	jb     0x3f01
    3e98:	78 0c                	js     0x3ea6
    3e9a:	56                   	push   si
    3e9b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e9d:	74 65                	je     0x3f04
    3e9f:	73 53                	jae    0x3ef4
    3ea1:	70 65                	jo     0x3f08
    3ea3:	51                   	push   cx
    3ea4:	74 65                	je     0x3f0b
    3ea6:	0d 56 65             	or     ax,0x6556
    3ea9:	6e                   	outs   dx,BYTE PTR ds:[si]
    3eaa:	74 65                	je     0x3f11
    3eac:	73 53                	jae    0x3f01
    3eae:	70 65                	jo     0x3f15
    3eb0:	50                   	push   ax
    3eb1:	72 69                	jb     0x3f1c
    3eb3:	78 0b                	js     0x3ec0
    3eb5:	56                   	push   si
    3eb6:	61                   	popa
    3eb7:	6c                   	ins    BYTE PTR es:[di],dx
    3eb8:	65 75 72             	gs jne 0x3f2d
    3ebb:	53                   	push   bx
    3ebc:	74 6f                	je     0x3f2d
    3ebe:	63 6b 13             	arpl   WORD PTR [bp+di+0x13],bp
    3ec1:	43                   	inc    bx
    3ec2:	6f                   	outs   dx,WORD PTR ds:[si]
    3ec3:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ec4:	73 6f                	jae    0x3f35
    3ec6:	6d                   	ins    WORD PTR es:[di],dx
    3ec7:	6d                   	ins    WORD PTR es:[di],dx
    3ec8:	61                   	popa
    3ec9:	74 69                	je     0x3f34
    3ecb:	6f                   	outs   dx,WORD PTR ds:[si]
    3ecc:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ecd:	4d                   	dec    bp
    3ece:	61                   	popa
    3ecf:	74 69                	je     0x3f3a
    3ed1:	65 72 65             	gs jb  0x3f39
    3ed4:	0f 44 65 70          	cmove  sp,WORD PTR [di+0x70]
    3ed8:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3eda:	73 65                	jae    0x3f41
    3edc:	73 51                	jae    0x3f2f
    3ede:	75 61                	jne    0x3f41
    3ee0:	6c                   	ins    BYTE PTR es:[di],dx
    3ee1:	69 74 65 09 50       	imul   si,WORD PTR [si+0x65],0x5009
    3ee6:	75 62                	jne    0x3f4a
    3ee8:	6c                   	ins    BYTE PTR es:[di],dx
    3ee9:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    3eee:	11 41 63             	adc    WORD PTR [bx+di+0x63],ax
    3ef1:	74 69                	je     0x3f5c
    3ef3:	6f                   	outs   dx,WORD PTR ds:[si]
    3ef4:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ef5:	43                   	inc    bx
    3ef6:	6f                   	outs   dx,WORD PTR ds:[si]
    3ef7:	6d                   	ins    WORD PTR es:[di],dx
    3ef8:	6d                   	ins    WORD PTR es:[di],dx
    3ef9:	65 72 63             	gs jb  0x3f5f
    3efc:	69 61 6c 65 08       	imul   sp,WORD PTR [bx+di+0x6c],0x865
    3f01:	51                   	push   cx
    3f02:	74 65                	je     0x3f69
    3f04:	53                   	push   bx
    3f05:	74 6f                	je     0x3f76
    3f07:	63 6b 0e             	arpl   WORD PTR [bp+di+0xe],bp
    3f0a:	43                   	inc    bx
    3f0b:	6f                   	outs   dx,WORD PTR ds:[si]
    3f0c:	75 74                	jne    0x3f82
    3f0e:	55                   	push   bp
    3f0f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f10:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    3f15:	6f                   	outs   dx,WORD PTR ds:[si]
    3f16:	63 6b 14             	arpl   WORD PTR [bp+di+0x14],bp
    3f19:	43                   	inc    bx
    3f1a:	6f                   	outs   dx,WORD PTR ds:[si]
    3f1b:	75 74                	jne    0x3f91
    3f1d:	73 46                	jae    0x3f65
    3f1f:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
    3f24:	72 6f                	jb     0x3f95
    3f26:	64 75 63             	fs jne 0x3f8c
    3f29:	74 69                	je     0x3f94
    3f2b:	6f                   	outs   dx,WORD PTR ds:[si]
    3f2c:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f2d:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    3f30:	70 61                	jo     0x3f93
    3f32:	72 61                	jb     0x3f95
    3f34:	74 69                	je     0x3f9f
    3f36:	6f                   	outs   dx,WORD PTR ds:[si]
    3f37:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f38:	73 11                	jae    0x3f4b
    3f3a:	45                   	inc    bp
    3f3b:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f3c:	74 72                	je     0x3fb0
    3f3e:	65 74 69             	gs je  0x3faa
    3f41:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3f43:	4d                   	dec    bp
    3f44:	61                   	popa
    3f45:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3f48:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f49:	65 73 0f             	gs jae 0x3f5b
    3f4c:	50                   	push   ax
    3f4d:	72 69                	jb     0x3fb8
    3f4f:	6d                   	ins    WORD PTR es:[di],dx
    3f50:	65 73 41             	gs jae 0x3f94
    3f53:	73 73                	jae    0x3fc8
    3f55:	75 72                	jne    0x3fc9
    3f57:	61                   	popa
    3f58:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f59:	63 65 06             	arpl   WORD PTR [di+0x6],sp
    3f5c:	45                   	inc    bp
    3f5d:	74 75                	je     0x3fd4
    3f5f:	64 65 73 0d          	fs gs jae 0x3f70
    3f63:	56                   	push   si
    3f64:	61                   	popa
    3f65:	6c                   	ins    BYTE PTR es:[di],dx
    3f66:	65 75 72             	gs jne 0x3fdb
    3f69:	41                   	inc    cx
    3f6a:	6a 6f                	push   0x6f
    3f6c:	75 74                	jne    0x3fe2
    3f6e:	65 65 0b 53 75       	gs or  dx,WORD PTR gs:[bp+di+0x75]
    3f73:	62 76 65             	bound  si,DWORD PTR [bp+0x65]
    3f76:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f77:	74 69                	je     0x3fe2
    3f79:	6f                   	outs   dx,WORD PTR ds:[si]
    3f7a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f7b:	73 11                	jae    0x3f8e
    3f7d:	4d                   	dec    bp
    3f7e:	61                   	popa
    3f7f:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    3f84:	76 72                	jbe    0x3ff8
    3f86:	65 44                	gs inc sp
    3f88:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    3f8d:	65 0e                	gs push cs
    3f8f:	52                   	push   dx
    3f90:	65 6d                	gs ins WORD PTR es:[di],dx
    3f92:	75 6e                	jne    0x4002
    3f94:	65 72 61             	gs jb  0x3ff8
    3f97:	74 69                	je     0x4002
    3f99:	6f                   	outs   dx,WORD PTR ds:[si]
    3f9a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f9b:	46                   	inc    si
    3f9c:	56                   	push   si
    3f9d:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
    3fa0:	6d                   	ins    WORD PTR es:[di],dx
    3fa1:	75 6e                	jne    0x4011
    3fa3:	65 72 61             	gs jb  0x4007
    3fa6:	74 69                	je     0x4011
    3fa8:	6f                   	outs   dx,WORD PTR ds:[si]
    3fa9:	6e                   	outs   dx,BYTE PTR ds:[si]
    3faa:	43                   	inc    bx
    3fab:	61                   	popa
    3fac:	64 72 65             	fs jb  0x4014
    3faf:	73 0c                	jae    0x3fbd
    3fb1:	43                   	inc    bx
    3fb2:	6f                   	outs   dx,WORD PTR ds:[si]
    3fb3:	75 74                	jne    0x4029
    3fb5:	45                   	inc    bp
    3fb6:	6d                   	ins    WORD PTR es:[di],dx
    3fb7:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    3fba:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    3fbd:	0c 43                	or     al,0x43
    3fbf:	6f                   	outs   dx,WORD PTR ds:[si]
    3fc0:	75 74                	jne    0x4036
    3fc2:	4c                   	dec    sp
    3fc3:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    3fc8:	69 65 0d 43 6f       	imul   sp,WORD PTR [di+0xd],0x6f43
    3fcd:	75 74                	jne    0x4043
    3fcf:	46                   	inc    si
    3fd0:	6f                   	outs   dx,WORD PTR ds:[si]
    3fd1:	72 6d                	jb     0x4040
    3fd3:	61                   	popa
    3fd4:	74 69                	je     0x403f
    3fd6:	6f                   	outs   dx,WORD PTR ds:[si]
    3fd7:	6e                   	outs   dx,BYTE PTR ds:[si]
    3fd8:	03 45 42             	add    ax,WORD PTR [di+0x42]
    3fdb:	45                   	inc    bp
    3fdc:	11 52 65             	adc    WORD PTR [bp+si+0x65],dx
    3fdf:	73 75                	jae    0x4056
    3fe1:	6c                   	ins    BYTE PTR es:[di],dx
    3fe2:	74 61                	je     0x4045
    3fe4:	74 43                	je     0x4029
    3fe6:	6f                   	outs   dx,WORD PTR ds:[si]
    3fe7:	6d                   	ins    WORD PTR es:[di],dx
    3fe8:	70 74                	jo     0x405e
    3fea:	61                   	popa
    3feb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    3fee:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    3ff1:	73 75                	jae    0x4068
    3ff3:	6c                   	ins    BYTE PTR es:[di],dx
    3ff4:	74 61                	je     0x4057
    3ff6:	74 4e                	je     0x4046
    3ff8:	65 74 0d             	gs je  0x4008
    3ffb:	52                   	push   dx
    3ffc:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3ffe:	74 61                	je     0x4061
    4000:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    4003:	69 74 65 43 70       	imul   si,WORD PTR [si+0x65],0x7043
    4008:	0d 52 6f             	or     ax,0x6f52
    400b:	74 61                	je     0x406e
    400d:	74 69                	je     0x4078
    400f:	6f                   	outs   dx,WORD PTR ds:[si]
    4010:	6e                   	outs   dx,BYTE PTR ds:[si]
    4011:	41                   	inc    cx
    4012:	63 74 69             	arpl   WORD PTR [si+0x69],si
    4015:	66 0b 45 66          	or     eax,DWORD PTR [di+0x66]
    4019:	66 65 74 4c          	data32 gs je 0x4069
    401d:	65 76 69             	gs jbe 0x4089
    4020:	65 72 55             	gs jb  0x4078
    4023:	89 e5                	mov    bp,sp
    4025:	b8 0c 01             	mov    ax,0x10c
    4028:	9a 44 04 42 40       	call   0x4042:0x444
    402d:	81 ec 0c 01          	sub    sp,0x10c
    4031:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4034:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4037:	bf 38 01             	mov    di,0x138
    403a:	b8 ff ff             	mov    ax,0xffff
    403d:	50                   	push   ax
    403e:	57                   	push   di
    403f:	9a 73 22 8e 4d       	call   0x4d8e:0x2273
    4044:	89 c7                	mov    di,ax
    4046:	8e c2                	mov    es,dx
    4048:	89 be 1c ff          	mov    WORD PTR [bp-0xe4],di
    404c:	8c 86 1e ff          	mov    WORD PTR [bp-0xe2],es
    4050:	bf 06 3e             	mov    di,0x3e06
    4053:	0e                   	push   cs
    4054:	57                   	push   di
    4055:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4059:	06                   	push   es
    405a:	57                   	push   di
    405b:	9a 9b 3b 80 40       	call   0x4080:0x3b9b
    4060:	89 c7                	mov    di,ax
    4062:	8e c2                	mov    es,dx
    4064:	06                   	push   es
    4065:	57                   	push   di
    4066:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4069:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    406d:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    4072:	bf 11 3e             	mov    di,0x3e11
    4075:	0e                   	push   cs
    4076:	57                   	push   di
    4077:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    407b:	06                   	push   es
    407c:	57                   	push   di
    407d:	9a 9b 3b aa 40       	call   0x40aa:0x3b9b
    4082:	89 c7                	mov    di,ax
    4084:	8e c2                	mov    es,dx
    4086:	06                   	push   es
    4087:	57                   	push   di
    4088:	26 c4 3d             	les    di,DWORD PTR es:[di]
    408b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    408f:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    4094:	9b de e1             	fsubrp st(1),st
    4097:	9b db be 08 ff       	fstp   TBYTE PTR [bp-0xf8]
    409c:	bf 1f 3e             	mov    di,0x3e1f
    409f:	0e                   	push   cs
    40a0:	57                   	push   di
    40a1:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    40a5:	06                   	push   es
    40a6:	57                   	push   di
    40a7:	9a 9b 3b da 40       	call   0x40da:0x3b9b
    40ac:	89 c7                	mov    di,ax
    40ae:	8e c2                	mov    es,dx
    40b0:	06                   	push   es
    40b1:	57                   	push   di
    40b2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40b5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40b9:	9b db ae 08 ff       	fld    TBYTE PTR [bp-0xf8]
    40be:	9b de e1             	fsubrp st(1),st
    40c1:	83 ec 08             	sub    sp,0x8
    40c4:	89 e3                	mov    bx,sp
    40c6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    40ca:	90                   	nop
    40cb:	9b                   	fwait
    40cc:	bf f2 3d             	mov    di,0x3df2
    40cf:	0e                   	push   cs
    40d0:	57                   	push   di
    40d1:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    40d5:	06                   	push   es
    40d6:	57                   	push   di
    40d7:	9a 9b 3b f7 40       	call   0x40f7:0x3b9b
    40dc:	89 c7                	mov    di,ax
    40de:	8e c2                	mov    es,dx
    40e0:	06                   	push   es
    40e1:	57                   	push   di
    40e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40e5:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    40e9:	bf 2e 3e             	mov    di,0x3e2e
    40ec:	0e                   	push   cs
    40ed:	57                   	push   di
    40ee:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    40f2:	06                   	push   es
    40f3:	57                   	push   di
    40f4:	9a 9b 3b 19 41       	call   0x4119:0x3b9b
    40f9:	89 c7                	mov    di,ax
    40fb:	8e c2                	mov    es,dx
    40fd:	06                   	push   es
    40fe:	57                   	push   di
    40ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4102:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4106:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    410b:	bf 34 3e             	mov    di,0x3e34
    410e:	0e                   	push   cs
    410f:	57                   	push   di
    4110:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4114:	06                   	push   es
    4115:	57                   	push   di
    4116:	9a 9b 3b 43 41       	call   0x4143:0x3b9b
    411b:	89 c7                	mov    di,ax
    411d:	8e c2                	mov    es,dx
    411f:	06                   	push   es
    4120:	57                   	push   di
    4121:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4124:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4128:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    412d:	9b de c1             	faddp  st(1),st
    4130:	9b db be 08 ff       	fstp   TBYTE PTR [bp-0xf8]
    4135:	bf 41 3e             	mov    di,0x3e41
    4138:	0e                   	push   cs
    4139:	57                   	push   di
    413a:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    413e:	06                   	push   es
    413f:	57                   	push   di
    4140:	9a 9b 3b 6d 41       	call   0x416d:0x3b9b
    4145:	89 c7                	mov    di,ax
    4147:	8e c2                	mov    es,dx
    4149:	06                   	push   es
    414a:	57                   	push   di
    414b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    414e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4152:	9b db ae 08 ff       	fld    TBYTE PTR [bp-0xf8]
    4157:	9b de c1             	faddp  st(1),st
    415a:	9b db be fe fe       	fstp   TBYTE PTR [bp-0x102]
    415f:	bf 11 3e             	mov    di,0x3e11
    4162:	0e                   	push   cs
    4163:	57                   	push   di
    4164:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4168:	06                   	push   es
    4169:	57                   	push   di
    416a:	9a 9b 3b 97 41       	call   0x4197:0x3b9b
    416f:	89 c7                	mov    di,ax
    4171:	8e c2                	mov    es,dx
    4173:	06                   	push   es
    4174:	57                   	push   di
    4175:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4178:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    417c:	9b db ae fe fe       	fld    TBYTE PTR [bp-0x102]
    4181:	9b de c1             	faddp  st(1),st
    4184:	9b db be f4 fe       	fstp   TBYTE PTR [bp-0x10c]
    4189:	bf 1f 3e             	mov    di,0x3e1f
    418c:	0e                   	push   cs
    418d:	57                   	push   di
    418e:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4192:	06                   	push   es
    4193:	57                   	push   di
    4194:	9a 9b 3b c3 41       	call   0x41c3:0x3b9b
    4199:	89 c7                	mov    di,ax
    419b:	8e c2                	mov    es,dx
    419d:	06                   	push   es
    419e:	57                   	push   di
    419f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41a2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41a6:	9b db ae f4 fe       	fld    TBYTE PTR [bp-0x10c]
    41ab:	9b de c1             	faddp  st(1),st
    41ae:	9b dd 9e 28 ff       	fstp   QWORD PTR [bp-0xd8]
    41b3:	90                   	nop
    41b4:	9b                   	fwait
    41b5:	bf 49 3e             	mov    di,0x3e49
    41b8:	0e                   	push   cs
    41b9:	57                   	push   di
    41ba:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    41be:	06                   	push   es
    41bf:	57                   	push   di
    41c0:	9a 9b 3b 22 42       	call   0x4222:0x3b9b
    41c5:	89 c7                	mov    di,ax
    41c7:	8e c2                	mov    es,dx
    41c9:	06                   	push   es
    41ca:	57                   	push   di
    41cb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41ce:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41d2:	9b dd 9e 20 ff       	fstp   QWORD PTR [bp-0xe0]
    41d7:	90                   	nop
    41d8:	9b                   	fwait
    41d9:	ff b6 2e ff          	push   WORD PTR [bp-0xd2]
    41dd:	ff b6 2c ff          	push   WORD PTR [bp-0xd4]
    41e1:	ff b6 2a ff          	push   WORD PTR [bp-0xd6]
    41e5:	ff b6 28 ff          	push   WORD PTR [bp-0xd8]
    41e9:	9b dd 86 28 ff       	fld    QWORD PTR [bp-0xd8]
    41ee:	9b dc 86 20 ff       	fadd   QWORD PTR [bp-0xe0]
    41f3:	83 ec 08             	sub    sp,0x8
    41f6:	89 e3                	mov    bx,sp
    41f8:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    41fc:	90                   	nop
    41fd:	9b                   	fwait
    41fe:	9a a7 2e 9b 42       	call   0x429b:0x2ea7
    4203:	9b 2e d8 0e 66 3e    	fmul   DWORD PTR cs:0x3e66
    4209:	83 ec 08             	sub    sp,0x8
    420c:	89 e3                	mov    bx,sp
    420e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4212:	90                   	nop
    4213:	9b                   	fwait
    4214:	bf 58 3e             	mov    di,0x3e58
    4217:	0e                   	push   cs
    4218:	57                   	push   di
    4219:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    421d:	06                   	push   es
    421e:	57                   	push   di
    421f:	9a 9b 3b 43 42       	call   0x4243:0x3b9b
    4224:	89 c7                	mov    di,ax
    4226:	8e c2                	mov    es,dx
    4228:	06                   	push   es
    4229:	57                   	push   di
    422a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    422d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4231:	bf 6a 3e             	mov    di,0x3e6a
    4234:	0e                   	push   cs
    4235:	57                   	push   di
    4236:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4239:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    423e:	06                   	push   es
    423f:	57                   	push   di
    4240:	9a 9b 3b 76 42       	call   0x4276:0x3b9b
    4245:	89 c7                	mov    di,ax
    4247:	8e c2                	mov    es,dx
    4249:	06                   	push   es
    424a:	57                   	push   di
    424b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    424e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4252:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    4256:	89 96 1a ff          	mov    WORD PTR [bp-0xe6],dx
    425a:	9b db 86 18 ff       	fild   DWORD PTR [bp-0xe8]
    425f:	9b db be 0e ff       	fstp   TBYTE PTR [bp-0xf2]
    4264:	bf 71 3e             	mov    di,0x3e71
    4267:	0e                   	push   cs
    4268:	57                   	push   di
    4269:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    426c:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    4271:	06                   	push   es
    4272:	57                   	push   di
    4273:	9a 9b 3b b4 42       	call   0x42b4:0x3b9b
    4278:	89 c7                	mov    di,ax
    427a:	8e c2                	mov    es,dx
    427c:	06                   	push   es
    427d:	57                   	push   di
    427e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4281:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4285:	9b db ae 0e ff       	fld    TBYTE PTR [bp-0xf2]
    428a:	9b de c9             	fmulp  st(1),st
    428d:	83 ec 08             	sub    sp,0x8
    4290:	89 e3                	mov    bx,sp
    4292:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4296:	90                   	nop
    4297:	9b                   	fwait
    4298:	9a a6 2f 0c 43       	call   0x430c:0x2fa6
    429d:	9b db be f6 fe       	fstp   TBYTE PTR [bp-0x10a]
    42a2:	bf 6a 3e             	mov    di,0x3e6a
    42a5:	0e                   	push   cs
    42a6:	57                   	push   di
    42a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42aa:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    42af:	06                   	push   es
    42b0:	57                   	push   di
    42b1:	9a 9b 3b e7 42       	call   0x42e7:0x3b9b
    42b6:	89 c7                	mov    di,ax
    42b8:	8e c2                	mov    es,dx
    42ba:	06                   	push   es
    42bb:	57                   	push   di
    42bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42bf:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    42c3:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    42c7:	89 96 0c ff          	mov    WORD PTR [bp-0xf4],dx
    42cb:	9b db 86 0a ff       	fild   DWORD PTR [bp-0xf6]
    42d0:	9b db be 00 ff       	fstp   TBYTE PTR [bp-0x100]
    42d5:	bf 71 3e             	mov    di,0x3e71
    42d8:	0e                   	push   cs
    42d9:	57                   	push   di
    42da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42dd:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    42e2:	06                   	push   es
    42e3:	57                   	push   di
    42e4:	9a 9b 3b 45 43       	call   0x4345:0x3b9b
    42e9:	89 c7                	mov    di,ax
    42eb:	8e c2                	mov    es,dx
    42ed:	06                   	push   es
    42ee:	57                   	push   di
    42ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42f2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42f6:	9b db ae 00 ff       	fld    TBYTE PTR [bp-0x100]
    42fb:	9b de c9             	fmulp  st(1),st
    42fe:	83 ec 08             	sub    sp,0x8
    4301:	89 e3                	mov    bx,sp
    4303:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4307:	90                   	nop
    4308:	9b                   	fwait
    4309:	9a a6 2f 2b 43       	call   0x432b:0x2fa6
    430e:	9b db ae f6 fe       	fld    TBYTE PTR [bp-0x10a]
    4313:	9b de c1             	faddp  st(1),st
    4316:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    431a:	90                   	nop
    431b:	9b                   	fwait
    431c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    431f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4322:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4325:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4328:	9a a6 2f 9d 43       	call   0x439d:0x2fa6
    432d:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    4331:	90                   	nop
    4332:	9b                   	fwait
    4333:	bf 76 3e             	mov    di,0x3e76
    4336:	0e                   	push   cs
    4337:	57                   	push   di
    4338:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    433b:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4340:	06                   	push   es
    4341:	57                   	push   di
    4342:	9a 9b 3b 78 43       	call   0x4378:0x3b9b
    4347:	89 c7                	mov    di,ax
    4349:	8e c2                	mov    es,dx
    434b:	06                   	push   es
    434c:	57                   	push   di
    434d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4350:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4354:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    4358:	89 96 1a ff          	mov    WORD PTR [bp-0xe6],dx
    435c:	9b db 86 18 ff       	fild   DWORD PTR [bp-0xe8]
    4361:	9b db be 0e ff       	fstp   TBYTE PTR [bp-0xf2]
    4366:	bf 87 3e             	mov    di,0x3e87
    4369:	0e                   	push   cs
    436a:	57                   	push   di
    436b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    436e:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4373:	06                   	push   es
    4374:	57                   	push   di
    4375:	9a 9b 3b b6 43       	call   0x43b6:0x3b9b
    437a:	89 c7                	mov    di,ax
    437c:	8e c2                	mov    es,dx
    437e:	06                   	push   es
    437f:	57                   	push   di
    4380:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4383:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4387:	9b db ae 0e ff       	fld    TBYTE PTR [bp-0xf2]
    438c:	9b de c9             	fmulp  st(1),st
    438f:	83 ec 08             	sub    sp,0x8
    4392:	89 e3                	mov    bx,sp
    4394:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4398:	90                   	nop
    4399:	9b                   	fwait
    439a:	9a a6 2f 0e 44       	call   0x440e:0x2fa6
    439f:	9b db be f6 fe       	fstp   TBYTE PTR [bp-0x10a]
    43a4:	bf 76 3e             	mov    di,0x3e76
    43a7:	0e                   	push   cs
    43a8:	57                   	push   di
    43a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43ac:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    43b1:	06                   	push   es
    43b2:	57                   	push   di
    43b3:	9a 9b 3b e9 43       	call   0x43e9:0x3b9b
    43b8:	89 c7                	mov    di,ax
    43ba:	8e c2                	mov    es,dx
    43bc:	06                   	push   es
    43bd:	57                   	push   di
    43be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43c1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    43c5:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    43c9:	89 96 0c ff          	mov    WORD PTR [bp-0xf4],dx
    43cd:	9b db 86 0a ff       	fild   DWORD PTR [bp-0xf6]
    43d2:	9b db be 00 ff       	fstp   TBYTE PTR [bp-0x100]
    43d7:	bf 87 3e             	mov    di,0x3e87
    43da:	0e                   	push   cs
    43db:	57                   	push   di
    43dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43df:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    43e4:	06                   	push   es
    43e5:	57                   	push   di
    43e6:	9a 9b 3b 47 44       	call   0x4447:0x3b9b
    43eb:	89 c7                	mov    di,ax
    43ed:	8e c2                	mov    es,dx
    43ef:	06                   	push   es
    43f0:	57                   	push   di
    43f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43f4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    43f8:	9b db ae 00 ff       	fld    TBYTE PTR [bp-0x100]
    43fd:	9b de c9             	fmulp  st(1),st
    4400:	83 ec 08             	sub    sp,0x8
    4403:	89 e3                	mov    bx,sp
    4405:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4409:	90                   	nop
    440a:	9b                   	fwait
    440b:	9a a6 2f 2d 44       	call   0x442d:0x2fa6
    4410:	9b db ae f6 fe       	fld    TBYTE PTR [bp-0x10a]
    4415:	9b de c1             	faddp  st(1),st
    4418:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    441c:	90                   	nop
    441d:	9b                   	fwait
    441e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4421:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4424:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4427:	ff 76 f8             	push   WORD PTR [bp-0x8]
    442a:	9a a6 2f 9f 44       	call   0x449f:0x2fa6
    442f:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    4433:	90                   	nop
    4434:	9b                   	fwait
    4435:	bf 99 3e             	mov    di,0x3e99
    4438:	0e                   	push   cs
    4439:	57                   	push   di
    443a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    443d:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4442:	06                   	push   es
    4443:	57                   	push   di
    4444:	9a 9b 3b 7a 44       	call   0x447a:0x3b9b
    4449:	89 c7                	mov    di,ax
    444b:	8e c2                	mov    es,dx
    444d:	06                   	push   es
    444e:	57                   	push   di
    444f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4452:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4456:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    445a:	89 96 1a ff          	mov    WORD PTR [bp-0xe6],dx
    445e:	9b db 86 18 ff       	fild   DWORD PTR [bp-0xe8]
    4463:	9b db be 0e ff       	fstp   TBYTE PTR [bp-0xf2]
    4468:	bf a6 3e             	mov    di,0x3ea6
    446b:	0e                   	push   cs
    446c:	57                   	push   di
    446d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4470:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4475:	06                   	push   es
    4476:	57                   	push   di
    4477:	9a 9b 3b b8 44       	call   0x44b8:0x3b9b
    447c:	89 c7                	mov    di,ax
    447e:	8e c2                	mov    es,dx
    4480:	06                   	push   es
    4481:	57                   	push   di
    4482:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4485:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4489:	9b db ae 0e ff       	fld    TBYTE PTR [bp-0xf2]
    448e:	9b de c9             	fmulp  st(1),st
    4491:	83 ec 08             	sub    sp,0x8
    4494:	89 e3                	mov    bx,sp
    4496:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    449a:	90                   	nop
    449b:	9b                   	fwait
    449c:	9a a6 2f 10 45       	call   0x4510:0x2fa6
    44a1:	9b db be f6 fe       	fstp   TBYTE PTR [bp-0x10a]
    44a6:	bf 99 3e             	mov    di,0x3e99
    44a9:	0e                   	push   cs
    44aa:	57                   	push   di
    44ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ae:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    44b3:	06                   	push   es
    44b4:	57                   	push   di
    44b5:	9a 9b 3b eb 44       	call   0x44eb:0x3b9b
    44ba:	89 c7                	mov    di,ax
    44bc:	8e c2                	mov    es,dx
    44be:	06                   	push   es
    44bf:	57                   	push   di
    44c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44c3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    44c7:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    44cb:	89 96 0c ff          	mov    WORD PTR [bp-0xf4],dx
    44cf:	9b db 86 0a ff       	fild   DWORD PTR [bp-0xf6]
    44d4:	9b db be 00 ff       	fstp   TBYTE PTR [bp-0x100]
    44d9:	bf a6 3e             	mov    di,0x3ea6
    44dc:	0e                   	push   cs
    44dd:	57                   	push   di
    44de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44e1:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    44e6:	06                   	push   es
    44e7:	57                   	push   di
    44e8:	9a 9b 3b 49 45       	call   0x4549:0x3b9b
    44ed:	89 c7                	mov    di,ax
    44ef:	8e c2                	mov    es,dx
    44f1:	06                   	push   es
    44f2:	57                   	push   di
    44f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44f6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    44fa:	9b db ae 00 ff       	fld    TBYTE PTR [bp-0x100]
    44ff:	9b de c9             	fmulp  st(1),st
    4502:	83 ec 08             	sub    sp,0x8
    4505:	89 e3                	mov    bx,sp
    4507:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    450b:	90                   	nop
    450c:	9b                   	fwait
    450d:	9a a6 2f 2f 45       	call   0x452f:0x2fa6
    4512:	9b db ae f6 fe       	fld    TBYTE PTR [bp-0x10a]
    4517:	9b de c1             	faddp  st(1),st
    451a:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    451e:	90                   	nop
    451f:	9b                   	fwait
    4520:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4523:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4526:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4529:	ff 76 f8             	push   WORD PTR [bp-0x8]
    452c:	9a a6 2f c2 45       	call   0x45c2:0x2fa6
    4531:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    4535:	90                   	nop
    4536:	9b                   	fwait
    4537:	bf b4 3e             	mov    di,0x3eb4
    453a:	0e                   	push   cs
    453b:	57                   	push   di
    453c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    453f:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4544:	06                   	push   es
    4545:	57                   	push   di
    4546:	9a 9b 3b 6f 45       	call   0x456f:0x3b9b
    454b:	89 c7                	mov    di,ax
    454d:	8e c2                	mov    es,dx
    454f:	06                   	push   es
    4550:	57                   	push   di
    4551:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4554:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4558:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    455d:	bf b4 3e             	mov    di,0x3eb4
    4560:	0e                   	push   cs
    4561:	57                   	push   di
    4562:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4565:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    456a:	06                   	push   es
    456b:	57                   	push   di
    456c:	9a 9b 3b 9d 45       	call   0x459d:0x3b9b
    4571:	89 c7                	mov    di,ax
    4573:	8e c2                	mov    es,dx
    4575:	06                   	push   es
    4576:	57                   	push   di
    4577:	26 c4 3d             	les    di,DWORD PTR es:[di]
    457a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    457e:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    4583:	9b de e1             	fsubrp st(1),st
    4586:	9b db be 08 ff       	fstp   TBYTE PTR [bp-0xf8]
    458b:	bf b4 3e             	mov    di,0x3eb4
    458e:	0e                   	push   cs
    458f:	57                   	push   di
    4590:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4593:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    4598:	06                   	push   es
    4599:	57                   	push   di
    459a:	9a 9b 3b db 45       	call   0x45db:0x3b9b
    459f:	89 c7                	mov    di,ax
    45a1:	8e c2                	mov    es,dx
    45a3:	06                   	push   es
    45a4:	57                   	push   di
    45a5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45a8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45ac:	9b db ae 08 ff       	fld    TBYTE PTR [bp-0xf8]
    45b1:	9b de c1             	faddp  st(1),st
    45b4:	83 ec 08             	sub    sp,0x8
    45b7:	89 e3                	mov    bx,sp
    45b9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    45bd:	90                   	nop
    45be:	9b                   	fwait
    45bf:	9a a6 2f 07 46       	call   0x4607:0x2fa6
    45c4:	9b db be fe fe       	fstp   TBYTE PTR [bp-0x102]
    45c9:	bf b4 3e             	mov    di,0x3eb4
    45cc:	0e                   	push   cs
    45cd:	57                   	push   di
    45ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45d1:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    45d6:	06                   	push   es
    45d7:	57                   	push   di
    45d8:	9a 9b 3b 4a 46       	call   0x464a:0x3b9b
    45dd:	89 c7                	mov    di,ax
    45df:	8e c2                	mov    es,dx
    45e1:	06                   	push   es
    45e2:	57                   	push   di
    45e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45e6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45ea:	9b db ae fe fe       	fld    TBYTE PTR [bp-0x102]
    45ef:	9b de e1             	fsubrp st(1),st
    45f2:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    45f6:	90                   	nop
    45f7:	9b                   	fwait
    45f8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    45fb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    45fe:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4601:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4604:	9a a6 2f 67 46       	call   0x4667:0x2fa6
    4609:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    460d:	90                   	nop
    460e:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
    4613:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    4617:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    461b:	9b dc 46 d8          	fadd   QWORD PTR [bp-0x28]
    461f:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    4623:	90                   	nop
    4624:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
    4629:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    462d:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    4631:	9b dd 9e 30 ff       	fstp   QWORD PTR [bp-0xd0]
    4636:	90                   	nop
    4637:	9b                   	fwait
    4638:	bf c0 3e             	mov    di,0x3ec0
    463b:	0e                   	push   cs
    463c:	57                   	push   di
    463d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4640:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4645:	06                   	push   es
    4646:	57                   	push   di
    4647:	9a 9b 3b 80 46       	call   0x4680:0x3b9b
    464c:	89 c7                	mov    di,ax
    464e:	8e c2                	mov    es,dx
    4650:	06                   	push   es
    4651:	57                   	push   di
    4652:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4655:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4659:	83 ec 08             	sub    sp,0x8
    465c:	89 e3                	mov    bx,sp
    465e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4662:	90                   	nop
    4663:	9b                   	fwait
    4664:	9a a6 2f 9d 46       	call   0x469d:0x2fa6
    4669:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    466e:	bf c0 3e             	mov    di,0x3ec0
    4671:	0e                   	push   cs
    4672:	57                   	push   di
    4673:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4676:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    467b:	06                   	push   es
    467c:	57                   	push   di
    467d:	9a 9b 3b bf 46       	call   0x46bf:0x3b9b
    4682:	89 c7                	mov    di,ax
    4684:	8e c2                	mov    es,dx
    4686:	06                   	push   es
    4687:	57                   	push   di
    4688:	26 c4 3d             	les    di,DWORD PTR es:[di]
    468b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    468f:	83 ec 08             	sub    sp,0x8
    4692:	89 e3                	mov    bx,sp
    4694:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4698:	90                   	nop
    4699:	9b                   	fwait
    469a:	9a a6 2f 31 47       	call   0x4731:0x2fa6
    469f:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    46a4:	9b de c1             	faddp  st(1),st
    46a7:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    46ab:	90                   	nop
    46ac:	9b                   	fwait
    46ad:	bf d4 3e             	mov    di,0x3ed4
    46b0:	0e                   	push   cs
    46b1:	57                   	push   di
    46b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46b5:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    46ba:	06                   	push   es
    46bb:	57                   	push   di
    46bc:	9a 9b 3b e5 46       	call   0x46e5:0x3b9b
    46c1:	89 c7                	mov    di,ax
    46c3:	8e c2                	mov    es,dx
    46c5:	06                   	push   es
    46c6:	57                   	push   di
    46c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46ca:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46ce:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    46d3:	bf d4 3e             	mov    di,0x3ed4
    46d6:	0e                   	push   cs
    46d7:	57                   	push   di
    46d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46db:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    46e0:	06                   	push   es
    46e1:	57                   	push   di
    46e2:	9a 9b 3b 14 47       	call   0x4714:0x3b9b
    46e7:	89 c7                	mov    di,ax
    46e9:	8e c2                	mov    es,dx
    46eb:	06                   	push   es
    46ec:	57                   	push   di
    46ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46f0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46f4:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    46f9:	9b de c1             	faddp  st(1),st
    46fc:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    4700:	90                   	nop
    4701:	9b                   	fwait
    4702:	bf e4 3e             	mov    di,0x3ee4
    4705:	0e                   	push   cs
    4706:	57                   	push   di
    4707:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    470a:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    470f:	06                   	push   es
    4710:	57                   	push   di
    4711:	9a 9b 3b 4a 47       	call   0x474a:0x3b9b
    4716:	89 c7                	mov    di,ax
    4718:	8e c2                	mov    es,dx
    471a:	06                   	push   es
    471b:	57                   	push   di
    471c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    471f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4723:	83 ec 08             	sub    sp,0x8
    4726:	89 e3                	mov    bx,sp
    4728:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    472c:	90                   	nop
    472d:	9b                   	fwait
    472e:	9a a6 2f 67 47       	call   0x4767:0x2fa6
    4733:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    4738:	bf ee 3e             	mov    di,0x3eee
    473b:	0e                   	push   cs
    473c:	57                   	push   di
    473d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4740:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    4745:	06                   	push   es
    4746:	57                   	push   di
    4747:	9a 9b 3b 88 47       	call   0x4788:0x3b9b
    474c:	89 c7                	mov    di,ax
    474e:	8e c2                	mov    es,dx
    4750:	06                   	push   es
    4751:	57                   	push   di
    4752:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4755:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4759:	83 ec 08             	sub    sp,0x8
    475c:	89 e3                	mov    bx,sp
    475e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4762:	90                   	nop
    4763:	9b                   	fwait
    4764:	9a a6 2f a5 47       	call   0x47a5:0x2fa6
    4769:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    476e:	9b de c1             	faddp  st(1),st
    4771:	9b db be 08 ff       	fstp   TBYTE PTR [bp-0xf8]
    4776:	bf e4 3e             	mov    di,0x3ee4
    4779:	0e                   	push   cs
    477a:	57                   	push   di
    477b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    477e:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    4783:	06                   	push   es
    4784:	57                   	push   di
    4785:	9a 9b 3b c6 47       	call   0x47c6:0x3b9b
    478a:	89 c7                	mov    di,ax
    478c:	8e c2                	mov    es,dx
    478e:	06                   	push   es
    478f:	57                   	push   di
    4790:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4793:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4797:	83 ec 08             	sub    sp,0x8
    479a:	89 e3                	mov    bx,sp
    479c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    47a0:	90                   	nop
    47a1:	9b                   	fwait
    47a2:	9a a6 2f e3 47       	call   0x47e3:0x2fa6
    47a7:	9b db ae 08 ff       	fld    TBYTE PTR [bp-0xf8]
    47ac:	9b de c1             	faddp  st(1),st
    47af:	9b db be fe fe       	fstp   TBYTE PTR [bp-0x102]
    47b4:	bf ee 3e             	mov    di,0x3eee
    47b7:	0e                   	push   cs
    47b8:	57                   	push   di
    47b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47bc:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    47c1:	06                   	push   es
    47c2:	57                   	push   di
    47c3:	9a 9b 3b 05 48       	call   0x4805:0x3b9b
    47c8:	89 c7                	mov    di,ax
    47ca:	8e c2                	mov    es,dx
    47cc:	06                   	push   es
    47cd:	57                   	push   di
    47ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47d1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    47d5:	83 ec 08             	sub    sp,0x8
    47d8:	89 e3                	mov    bx,sp
    47da:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    47de:	90                   	nop
    47df:	9b                   	fwait
    47e0:	9a a6 2f 5d 48       	call   0x485d:0x2fa6
    47e5:	9b db ae fe fe       	fld    TBYTE PTR [bp-0x102]
    47ea:	9b de c1             	faddp  st(1),st
    47ed:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    47f1:	90                   	nop
    47f2:	9b                   	fwait
    47f3:	bf 00 3f             	mov    di,0x3f00
    47f6:	0e                   	push   cs
    47f7:	57                   	push   di
    47f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47fb:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    4800:	06                   	push   es
    4801:	57                   	push   di
    4802:	9a 9b 3b 38 48       	call   0x4838:0x3b9b
    4807:	89 c7                	mov    di,ax
    4809:	8e c2                	mov    es,dx
    480b:	06                   	push   es
    480c:	57                   	push   di
    480d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4810:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4814:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    4818:	89 96 1a ff          	mov    WORD PTR [bp-0xe6],dx
    481c:	9b db 86 18 ff       	fild   DWORD PTR [bp-0xe8]
    4821:	9b db be 0e ff       	fstp   TBYTE PTR [bp-0xf2]
    4826:	bf 09 3f             	mov    di,0x3f09
    4829:	0e                   	push   cs
    482a:	57                   	push   di
    482b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    482e:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    4833:	06                   	push   es
    4834:	57                   	push   di
    4835:	9a 9b 3b 76 48       	call   0x4876:0x3b9b
    483a:	89 c7                	mov    di,ax
    483c:	8e c2                	mov    es,dx
    483e:	06                   	push   es
    483f:	57                   	push   di
    4840:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4843:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4847:	9b db ae 0e ff       	fld    TBYTE PTR [bp-0xf2]
    484c:	9b de c9             	fmulp  st(1),st
    484f:	83 ec 08             	sub    sp,0x8
    4852:	89 e3                	mov    bx,sp
    4854:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4858:	90                   	nop
    4859:	9b                   	fwait
    485a:	9a a6 2f ce 48       	call   0x48ce:0x2fa6
    485f:	9b db be f6 fe       	fstp   TBYTE PTR [bp-0x10a]
    4864:	bf 00 3f             	mov    di,0x3f00
    4867:	0e                   	push   cs
    4868:	57                   	push   di
    4869:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    486c:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    4871:	06                   	push   es
    4872:	57                   	push   di
    4873:	9a 9b 3b a9 48       	call   0x48a9:0x3b9b
    4878:	89 c7                	mov    di,ax
    487a:	8e c2                	mov    es,dx
    487c:	06                   	push   es
    487d:	57                   	push   di
    487e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4881:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4885:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    4889:	89 96 0c ff          	mov    WORD PTR [bp-0xf4],dx
    488d:	9b db 86 0a ff       	fild   DWORD PTR [bp-0xf6]
    4892:	9b db be 00 ff       	fstp   TBYTE PTR [bp-0x100]
    4897:	bf 09 3f             	mov    di,0x3f09
    489a:	0e                   	push   cs
    489b:	57                   	push   di
    489c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    489f:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    48a4:	06                   	push   es
    48a5:	57                   	push   di
    48a6:	9a 9b 3b ec 48       	call   0x48ec:0x3b9b
    48ab:	89 c7                	mov    di,ax
    48ad:	8e c2                	mov    es,dx
    48af:	06                   	push   es
    48b0:	57                   	push   di
    48b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48b4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48b8:	9b db ae 00 ff       	fld    TBYTE PTR [bp-0x100]
    48bd:	9b de c9             	fmulp  st(1),st
    48c0:	83 ec 08             	sub    sp,0x8
    48c3:	89 e3                	mov    bx,sp
    48c5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    48c9:	90                   	nop
    48ca:	9b                   	fwait
    48cb:	9a a6 2f 09 49       	call   0x4909:0x2fa6
    48d0:	9b db ae f6 fe       	fld    TBYTE PTR [bp-0x10a]
    48d5:	9b de c1             	faddp  st(1),st
    48d8:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    48dc:	90                   	nop
    48dd:	9b                   	fwait
    48de:	bf 18 3f             	mov    di,0x3f18
    48e1:	0e                   	push   cs
    48e2:	57                   	push   di
    48e3:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    48e7:	06                   	push   es
    48e8:	57                   	push   di
    48e9:	9a 9b 3b 1f 49       	call   0x491f:0x3b9b
    48ee:	89 c7                	mov    di,ax
    48f0:	8e c2                	mov    es,dx
    48f2:	06                   	push   es
    48f3:	57                   	push   di
    48f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48f7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48fb:	83 ec 08             	sub    sp,0x8
    48fe:	89 e3                	mov    bx,sp
    4900:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4904:	90                   	nop
    4905:	9b                   	fwait
    4906:	9a a6 2f 3c 49       	call   0x493c:0x2fa6
    490b:	9b dd 5e a8          	fstp   QWORD PTR [bp-0x58]
    490f:	90                   	nop
    4910:	9b                   	fwait
    4911:	bf 2d 3f             	mov    di,0x3f2d
    4914:	0e                   	push   cs
    4915:	57                   	push   di
    4916:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    491a:	06                   	push   es
    491b:	57                   	push   di
    491c:	9a 9b 3b 52 49       	call   0x4952:0x3b9b
    4921:	89 c7                	mov    di,ax
    4923:	8e c2                	mov    es,dx
    4925:	06                   	push   es
    4926:	57                   	push   di
    4927:	26 c4 3d             	les    di,DWORD PTR es:[di]
    492a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    492e:	83 ec 08             	sub    sp,0x8
    4931:	89 e3                	mov    bx,sp
    4933:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4937:	90                   	nop
    4938:	9b                   	fwait
    4939:	9a a6 2f 6f 49       	call   0x496f:0x2fa6
    493e:	9b dd 5e a0          	fstp   QWORD PTR [bp-0x60]
    4942:	90                   	nop
    4943:	9b                   	fwait
    4944:	bf 39 3f             	mov    di,0x3f39
    4947:	0e                   	push   cs
    4948:	57                   	push   di
    4949:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    494d:	06                   	push   es
    494e:	57                   	push   di
    494f:	9a 9b 3b 85 49       	call   0x4985:0x3b9b
    4954:	89 c7                	mov    di,ax
    4956:	8e c2                	mov    es,dx
    4958:	06                   	push   es
    4959:	57                   	push   di
    495a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    495d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4961:	83 ec 08             	sub    sp,0x8
    4964:	89 e3                	mov    bx,sp
    4966:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    496a:	90                   	nop
    496b:	9b                   	fwait
    496c:	9a a6 2f c9 49       	call   0x49c9:0x2fa6
    4971:	9b dd 5e 98          	fstp   QWORD PTR [bp-0x68]
    4975:	90                   	nop
    4976:	9b                   	fwait
    4977:	bf 4b 3f             	mov    di,0x3f4b
    497a:	0e                   	push   cs
    497b:	57                   	push   di
    497c:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4980:	06                   	push   es
    4981:	57                   	push   di
    4982:	9a 9b 3b ac 49       	call   0x49ac:0x3b9b
    4987:	89 c7                	mov    di,ax
    4989:	8e c2                	mov    es,dx
    498b:	06                   	push   es
    498c:	57                   	push   di
    498d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4990:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4994:	9b dd 5e 90          	fstp   QWORD PTR [bp-0x70]
    4998:	90                   	nop
    4999:	9b                   	fwait
    499a:	bf 5b 3f             	mov    di,0x3f5b
    499d:	0e                   	push   cs
    499e:	57                   	push   di
    499f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49a2:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    49a7:	06                   	push   es
    49a8:	57                   	push   di
    49a9:	9a 9b 3b 28 4a       	call   0x4a28:0x3b9b
    49ae:	89 c7                	mov    di,ax
    49b0:	8e c2                	mov    es,dx
    49b2:	06                   	push   es
    49b3:	57                   	push   di
    49b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49b7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49bb:	83 ec 08             	sub    sp,0x8
    49be:	89 e3                	mov    bx,sp
    49c0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    49c4:	90                   	nop
    49c5:	9b                   	fwait
    49c6:	9a a6 2f ad 4c       	call   0x4cad:0x2fa6
    49cb:	9b dd 5e 88          	fstp   QWORD PTR [bp-0x78]
    49cf:	90                   	nop
    49d0:	9b 9b dd 46 c8       	fld    QWORD PTR [bp-0x38]
    49d5:	9b dc 46 c0          	fadd   QWORD PTR [bp-0x40]
    49d9:	9b dc 46 b8          	fadd   QWORD PTR [bp-0x48]
    49dd:	9b dc 46 b0          	fadd   QWORD PTR [bp-0x50]
    49e1:	9b dc 46 a8          	fadd   QWORD PTR [bp-0x58]
    49e5:	9b dc 46 a0          	fadd   QWORD PTR [bp-0x60]
    49e9:	9b dc 46 98          	fadd   QWORD PTR [bp-0x68]
    49ed:	9b dc 46 90          	fadd   QWORD PTR [bp-0x70]
    49f1:	9b dc 46 88          	fadd   QWORD PTR [bp-0x78]
    49f5:	9b dd 5e 80          	fstp   QWORD PTR [bp-0x80]
    49f9:	90                   	nop
    49fa:	9b 9b dd 46 d0       	fld    QWORD PTR [bp-0x30]
    49ff:	9b dc 66 80          	fsub   QWORD PTR [bp-0x80]
    4a03:	9b dd 9e 78 ff       	fstp   QWORD PTR [bp-0x88]
    4a08:	90                   	nop
    4a09:	9b                   	fwait
    4a0a:	ff b6 7e ff          	push   WORD PTR [bp-0x82]
    4a0e:	ff b6 7c ff          	push   WORD PTR [bp-0x84]
    4a12:	ff b6 7a ff          	push   WORD PTR [bp-0x86]
    4a16:	ff b6 78 ff          	push   WORD PTR [bp-0x88]
    4a1a:	bf 62 3f             	mov    di,0x3f62
    4a1d:	0e                   	push   cs
    4a1e:	57                   	push   di
    4a1f:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4a23:	06                   	push   es
    4a24:	57                   	push   di
    4a25:	9a 9b 3b 49 4a       	call   0x4a49:0x3b9b
    4a2a:	89 c7                	mov    di,ax
    4a2c:	8e c2                	mov    es,dx
    4a2e:	06                   	push   es
    4a2f:	57                   	push   di
    4a30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a33:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4a37:	bf 70 3f             	mov    di,0x3f70
    4a3a:	0e                   	push   cs
    4a3b:	57                   	push   di
    4a3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a3f:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    4a44:	06                   	push   es
    4a45:	57                   	push   di
    4a46:	9a 9b 3b 71 4a       	call   0x4a71:0x3b9b
    4a4b:	89 c7                	mov    di,ax
    4a4d:	8e c2                	mov    es,dx
    4a4f:	06                   	push   es
    4a50:	57                   	push   di
    4a51:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a54:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a58:	9b dd 9e 70 ff       	fstp   QWORD PTR [bp-0x90]
    4a5d:	90                   	nop
    4a5e:	9b                   	fwait
    4a5f:	bf 7c 3f             	mov    di,0x3f7c
    4a62:	0e                   	push   cs
    4a63:	57                   	push   di
    4a64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a67:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4a6c:	06                   	push   es
    4a6d:	57                   	push   di
    4a6e:	9a 9b 3b 97 4a       	call   0x4a97:0x3b9b
    4a73:	89 c7                	mov    di,ax
    4a75:	8e c2                	mov    es,dx
    4a77:	06                   	push   es
    4a78:	57                   	push   di
    4a79:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a7c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a80:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    4a85:	bf 7c 3f             	mov    di,0x3f7c
    4a88:	0e                   	push   cs
    4a89:	57                   	push   di
    4a8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a8d:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    4a92:	06                   	push   es
    4a93:	57                   	push   di
    4a94:	9a 9b 3b c7 4a       	call   0x4ac7:0x3b9b
    4a99:	89 c7                	mov    di,ax
    4a9b:	8e c2                	mov    es,dx
    4a9d:	06                   	push   es
    4a9e:	57                   	push   di
    4a9f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4aa2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4aa6:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    4aab:	9b de c1             	faddp  st(1),st
    4aae:	9b dd 9e 68 ff       	fstp   QWORD PTR [bp-0x98]
    4ab3:	90                   	nop
    4ab4:	9b                   	fwait
    4ab5:	bf 8e 3f             	mov    di,0x3f8e
    4ab8:	0e                   	push   cs
    4ab9:	57                   	push   di
    4aba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4abd:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4ac2:	06                   	push   es
    4ac3:	57                   	push   di
    4ac4:	9a 9b 3b ed 4a       	call   0x4aed:0x3b9b
    4ac9:	89 c7                	mov    di,ax
    4acb:	8e c2                	mov    es,dx
    4acd:	06                   	push   es
    4ace:	57                   	push   di
    4acf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ad2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ad6:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    4adb:	bf 8e 3f             	mov    di,0x3f8e
    4ade:	0e                   	push   cs
    4adf:	57                   	push   di
    4ae0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ae3:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    4ae8:	06                   	push   es
    4ae9:	57                   	push   di
    4aea:	9a 9b 3b 19 4b       	call   0x4b19:0x3b9b
    4aef:	89 c7                	mov    di,ax
    4af1:	8e c2                	mov    es,dx
    4af3:	06                   	push   es
    4af4:	57                   	push   di
    4af5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4af8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4afc:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    4b01:	9b de c1             	faddp  st(1),st
    4b04:	9b dd 9e 60 ff       	fstp   QWORD PTR [bp-0xa0]
    4b09:	90                   	nop
    4b0a:	9b                   	fwait
    4b0b:	bf 9d 3f             	mov    di,0x3f9d
    4b0e:	0e                   	push   cs
    4b0f:	57                   	push   di
    4b10:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4b14:	06                   	push   es
    4b15:	57                   	push   di
    4b16:	9a 9b 3b 41 4b       	call   0x4b41:0x3b9b
    4b1b:	89 c7                	mov    di,ax
    4b1d:	8e c2                	mov    es,dx
    4b1f:	06                   	push   es
    4b20:	57                   	push   di
    4b21:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b24:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b28:	9b dd 9e 58 ff       	fstp   QWORD PTR [bp-0xa8]
    4b2d:	90                   	nop
    4b2e:	9b                   	fwait
    4b2f:	bf b0 3f             	mov    di,0x3fb0
    4b32:	0e                   	push   cs
    4b33:	57                   	push   di
    4b34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b37:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4b3c:	06                   	push   es
    4b3d:	57                   	push   di
    4b3e:	9a 9b 3b 69 4b       	call   0x4b69:0x3b9b
    4b43:	89 c7                	mov    di,ax
    4b45:	8e c2                	mov    es,dx
    4b47:	06                   	push   es
    4b48:	57                   	push   di
    4b49:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b4c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b50:	9b dd 9e 50 ff       	fstp   QWORD PTR [bp-0xb0]
    4b55:	90                   	nop
    4b56:	9b                   	fwait
    4b57:	bf bd 3f             	mov    di,0x3fbd
    4b5a:	0e                   	push   cs
    4b5b:	57                   	push   di
    4b5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b5f:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4b64:	06                   	push   es
    4b65:	57                   	push   di
    4b66:	9a 9b 3b 91 4b       	call   0x4b91:0x3b9b
    4b6b:	89 c7                	mov    di,ax
    4b6d:	8e c2                	mov    es,dx
    4b6f:	06                   	push   es
    4b70:	57                   	push   di
    4b71:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b74:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b78:	9b dd 9e 48 ff       	fstp   QWORD PTR [bp-0xb8]
    4b7d:	90                   	nop
    4b7e:	9b                   	fwait
    4b7f:	bf ca 3f             	mov    di,0x3fca
    4b82:	0e                   	push   cs
    4b83:	57                   	push   di
    4b84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b87:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4b8c:	06                   	push   es
    4b8d:	57                   	push   di
    4b8e:	9a 9b 3b f4 4b       	call   0x4bf4:0x3b9b
    4b93:	89 c7                	mov    di,ax
    4b95:	8e c2                	mov    es,dx
    4b97:	06                   	push   es
    4b98:	57                   	push   di
    4b99:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b9c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ba0:	9b dd 9e 40 ff       	fstp   QWORD PTR [bp-0xc0]
    4ba5:	90                   	nop
    4ba6:	9b 9b dd 86 78 ff    	fld    QWORD PTR [bp-0x88]
    4bac:	9b dc 86 70 ff       	fadd   QWORD PTR [bp-0x90]
    4bb1:	9b dc a6 68 ff       	fsub   QWORD PTR [bp-0x98]
    4bb6:	9b dc a6 60 ff       	fsub   QWORD PTR [bp-0xa0]
    4bbb:	9b dc a6 58 ff       	fsub   QWORD PTR [bp-0xa8]
    4bc0:	9b dc a6 50 ff       	fsub   QWORD PTR [bp-0xb0]
    4bc5:	9b dc a6 48 ff       	fsub   QWORD PTR [bp-0xb8]
    4bca:	9b dc a6 40 ff       	fsub   QWORD PTR [bp-0xc0]
    4bcf:	9b dd 9e 38 ff       	fstp   QWORD PTR [bp-0xc8]
    4bd4:	90                   	nop
    4bd5:	9b                   	fwait
    4bd6:	ff b6 3e ff          	push   WORD PTR [bp-0xc2]
    4bda:	ff b6 3c ff          	push   WORD PTR [bp-0xc4]
    4bde:	ff b6 3a ff          	push   WORD PTR [bp-0xc6]
    4be2:	ff b6 38 ff          	push   WORD PTR [bp-0xc8]
    4be6:	bf d8 3f             	mov    di,0x3fd8
    4be9:	0e                   	push   cs
    4bea:	57                   	push   di
    4beb:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4bef:	06                   	push   es
    4bf0:	57                   	push   di
    4bf1:	9a 9b 3b 11 4c       	call   0x4c11:0x3b9b
    4bf6:	89 c7                	mov    di,ax
    4bf8:	8e c2                	mov    es,dx
    4bfa:	06                   	push   es
    4bfb:	57                   	push   di
    4bfc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bff:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4c03:	bf ee 3f             	mov    di,0x3fee
    4c06:	0e                   	push   cs
    4c07:	57                   	push   di
    4c08:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4c0c:	06                   	push   es
    4c0d:	57                   	push   di
    4c0e:	9a 9b 3b 33 4c       	call   0x4c33:0x3b9b
    4c13:	89 c7                	mov    di,ax
    4c15:	8e c2                	mov    es,dx
    4c17:	06                   	push   es
    4c18:	57                   	push   di
    4c19:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c1c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c20:	9b db be 12 ff       	fstp   TBYTE PTR [bp-0xee]
    4c25:	bf 2e 3e             	mov    di,0x3e2e
    4c28:	0e                   	push   cs
    4c29:	57                   	push   di
    4c2a:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4c2e:	06                   	push   es
    4c2f:	57                   	push   di
    4c30:	9a 9b 3b 63 4c       	call   0x4c63:0x3b9b
    4c35:	89 c7                	mov    di,ax
    4c37:	8e c2                	mov    es,dx
    4c39:	06                   	push   es
    4c3a:	57                   	push   di
    4c3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c3e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c42:	9b db ae 12 ff       	fld    TBYTE PTR [bp-0xee]
    4c47:	9b de c1             	faddp  st(1),st
    4c4a:	83 ec 08             	sub    sp,0x8
    4c4d:	89 e3                	mov    bx,sp
    4c4f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c53:	90                   	nop
    4c54:	9b                   	fwait
    4c55:	bf dc 3f             	mov    di,0x3fdc
    4c58:	0e                   	push   cs
    4c59:	57                   	push   di
    4c5a:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4c5e:	06                   	push   es
    4c5f:	57                   	push   di
    4c60:	9a 9b 3b 80 4c       	call   0x4c80:0x3b9b
    4c65:	89 c7                	mov    di,ax
    4c67:	8e c2                	mov    es,dx
    4c69:	06                   	push   es
    4c6a:	57                   	push   di
    4c6b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c6e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4c72:	bf ee 3f             	mov    di,0x3fee
    4c75:	0e                   	push   cs
    4c76:	57                   	push   di
    4c77:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4c7b:	06                   	push   es
    4c7c:	57                   	push   di
    4c7d:	9a 9b 3b ce 4c       	call   0x4cce:0x3b9b
    4c82:	89 c7                	mov    di,ax
    4c84:	8e c2                	mov    es,dx
    4c86:	06                   	push   es
    4c87:	57                   	push   di
    4c88:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c8b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c8f:	83 ec 08             	sub    sp,0x8
    4c92:	89 e3                	mov    bx,sp
    4c94:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c98:	90                   	nop
    4c99:	9b                   	fwait
    4c9a:	ff b6 26 ff          	push   WORD PTR [bp-0xda]
    4c9e:	ff b6 24 ff          	push   WORD PTR [bp-0xdc]
    4ca2:	ff b6 22 ff          	push   WORD PTR [bp-0xde]
    4ca6:	ff b6 20 ff          	push   WORD PTR [bp-0xe0]
    4caa:	9a a7 2e 05 4d       	call   0x4d05:0x2ea7
    4caf:	9b 2e d8 0e 66 3e    	fmul   DWORD PTR cs:0x3e66
    4cb5:	83 ec 08             	sub    sp,0x8
    4cb8:	89 e3                	mov    bx,sp
    4cba:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4cbe:	90                   	nop
    4cbf:	9b                   	fwait
    4cc0:	bf fa 3f             	mov    di,0x3ffa
    4cc3:	0e                   	push   cs
    4cc4:	57                   	push   di
    4cc5:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4cc9:	06                   	push   es
    4cca:	57                   	push   di
    4ccb:	9a 9b 3b 20 4d       	call   0x4d20:0x3b9b
    4cd0:	89 c7                	mov    di,ax
    4cd2:	8e c2                	mov    es,dx
    4cd4:	06                   	push   es
    4cd5:	57                   	push   di
    4cd6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cd9:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4cdd:	ff b6 36 ff          	push   WORD PTR [bp-0xca]
    4ce1:	ff b6 34 ff          	push   WORD PTR [bp-0xcc]
    4ce5:	ff b6 32 ff          	push   WORD PTR [bp-0xce]
    4ce9:	ff b6 30 ff          	push   WORD PTR [bp-0xd0]
    4ced:	9b dd 86 20 ff       	fld    QWORD PTR [bp-0xe0]
    4cf2:	9b dc 86 28 ff       	fadd   QWORD PTR [bp-0xd8]
    4cf7:	83 ec 08             	sub    sp,0x8
    4cfa:	89 e3                	mov    bx,sp
    4cfc:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d00:	90                   	nop
    4d01:	9b                   	fwait
    4d02:	9a a7 2e 57 4d       	call   0x4d57:0x2ea7
    4d07:	83 ec 08             	sub    sp,0x8
    4d0a:	89 e3                	mov    bx,sp
    4d0c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d10:	90                   	nop
    4d11:	9b                   	fwait
    4d12:	bf 08 40             	mov    di,0x4008
    4d15:	0e                   	push   cs
    4d16:	57                   	push   di
    4d17:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4d1b:	06                   	push   es
    4d1c:	57                   	push   di
    4d1d:	9a 9b 3b 72 4d       	call   0x4d72:0x3b9b
    4d22:	89 c7                	mov    di,ax
    4d24:	8e c2                	mov    es,dx
    4d26:	06                   	push   es
    4d27:	57                   	push   di
    4d28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d2b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4d2f:	9b dd 86 20 ff       	fld    QWORD PTR [bp-0xe0]
    4d34:	9b dc 86 28 ff       	fadd   QWORD PTR [bp-0xd8]
    4d39:	83 ec 08             	sub    sp,0x8
    4d3c:	89 e3                	mov    bx,sp
    4d3e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d42:	90                   	nop
    4d43:	9b                   	fwait
    4d44:	ff b6 26 ff          	push   WORD PTR [bp-0xda]
    4d48:	ff b6 24 ff          	push   WORD PTR [bp-0xdc]
    4d4c:	ff b6 22 ff          	push   WORD PTR [bp-0xde]
    4d50:	ff b6 20 ff          	push   WORD PTR [bp-0xe0]
    4d54:	9a a7 2e ff ff       	call   0xffff:0x2ea7
    4d59:	83 ec 08             	sub    sp,0x8
    4d5c:	89 e3                	mov    bx,sp
    4d5e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d62:	90                   	nop
    4d63:	9b                   	fwait
    4d64:	bf 16 40             	mov    di,0x4016
    4d67:	0e                   	push   cs
    4d68:	57                   	push   di
    4d69:	c4 be 1c ff          	les    di,DWORD PTR [bp-0xe4]
    4d6d:	06                   	push   es
    4d6e:	57                   	push   di
    4d6f:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    4d74:	89 c7                	mov    di,ax
    4d76:	8e c2                	mov    es,dx
    4d78:	06                   	push   es
    4d79:	57                   	push   di
    4d7a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d7d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4d81:	c9                   	leave
    4d82:	ca 08 00             	retf   0x8
    4d85:	55                   	push   bp
    4d86:	89 e5                	mov    bp,sp
    4d88:	b8 04 00             	mov    ax,0x4
    4d8b:	9a 44 04 22 4e       	call   0x4e22:0x444
    4d90:	83 ec 04             	sub    sp,0x4
    4d93:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4d97:	b0 00                	mov    al,0x0
    4d99:	75 01                	jne    0x4d9c
    4d9b:	40                   	inc    ax
    4d9c:	8a d0                	mov    dl,al
    4d9e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4da1:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    4da5:	b0 00                	mov    al,0x0
    4da7:	75 01                	jne    0x4daa
    4da9:	40                   	inc    ax
    4daa:	22 c2                	and    al,dl
    4dac:	08 c0                	or     al,al
    4dae:	74 49                	je     0x4df9
    4db0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4db3:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    4db8:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    4dbd:	26 3b 95 52 03       	cmp    dx,WORD PTR es:[di+0x352]
    4dc2:	75 35                	jne    0x4df9
    4dc4:	26 3b 85 50 03       	cmp    ax,WORD PTR es:[di+0x350]
    4dc9:	75 2e                	jne    0x4df9
    4dcb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4dce:	31 c0                	xor    ax,ax
    4dd0:	26 89 05             	mov    WORD PTR es:[di],ax
    4dd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dd6:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    4ddb:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    4de0:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    4de5:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    4dea:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    4def:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4df2:	06                   	push   es
    4df3:	57                   	push   di
    4df4:	9a c1 4e e7 4f       	call   0x4fe7:0x4ec1
    4df9:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4dfc:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    4e00:	74 14                	je     0x4e16
    4e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e05:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    4e0a:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    4e0f:	06                   	push   es
    4e10:	57                   	push   di
    4e11:	9a 30 22 3f 4e       	call   0x4e3f:0x2230
    4e16:	c9                   	leave
    4e17:	ca 0e 00             	retf   0xe
    4e1a:	55                   	push   bp
    4e1b:	89 e5                	mov    bp,sp
    4e1d:	31 c0                	xor    ax,ax
    4e1f:	9a 44 04 4d 4e       	call   0x4e4d:0x444
    4e24:	6a 01                	push   0x1
    4e26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e29:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    4e2e:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    4e32:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    4e36:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4e3a:	06                   	push   es
    4e3b:	57                   	push   di
    4e3c:	9a b2 77 5e 4e       	call   0x4e5e:0x77b2
    4e41:	c9                   	leave
    4e42:	ca 08 00             	retf   0x8
    4e45:	55                   	push   bp
    4e46:	89 e5                	mov    bp,sp
    4e48:	31 c0                	xor    ax,ax
    4e4a:	9a 44 04 6c 4e       	call   0x4e6c:0x444
    4e4f:	6a 03                	push   0x3
    4e51:	6a 00                	push   0x0
    4e53:	6a 00                	push   0x0
    4e55:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4e59:	06                   	push   es
    4e5a:	57                   	push   di
    4e5b:	9a b2 77 7f 4e       	call   0x4e7f:0x77b2
    4e60:	c9                   	leave
    4e61:	ca 08 00             	retf   0x8
    4e64:	55                   	push   bp
    4e65:	89 e5                	mov    bp,sp
    4e67:	31 c0                	xor    ax,ax
    4e69:	9a 44 04 8d 4e       	call   0x4e8d:0x444
    4e6e:	68 05 01             	push   0x105
    4e71:	bf 64 02             	mov    di,0x264
    4e74:	1e                   	push   ds
    4e75:	57                   	push   di
    4e76:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4e7a:	06                   	push   es
    4e7b:	57                   	push   di
    4e7c:	9a b2 77 9e 4e       	call   0x4e9e:0x77b2
    4e81:	c9                   	leave
    4e82:	ca 08 00             	retf   0x8
    4e85:	55                   	push   bp
    4e86:	89 e5                	mov    bp,sp
    4e88:	31 c0                	xor    ax,ax
    4e8a:	9a 44 04 ad 4e       	call   0x4ead:0x444
    4e8f:	6a 04                	push   0x4
    4e91:	6a 00                	push   0x0
    4e93:	6a 00                	push   0x0
    4e95:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4e99:	06                   	push   es
    4e9a:	57                   	push   di
    4e9b:	9a b2 77 bb 4e       	call   0x4ebb:0x77b2
    4ea0:	c9                   	leave
    4ea1:	ca 08 00             	retf   0x8
    4ea4:	55                   	push   bp
    4ea5:	89 e5                	mov    bp,sp
    4ea7:	b8 04 00             	mov    ax,0x4
    4eaa:	9a 44 04 ca 4e       	call   0x4eca:0x444
    4eaf:	83 ec 04             	sub    sp,0x4
    4eb2:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    4eb6:	06                   	push   es
    4eb7:	57                   	push   di
    4eb8:	9a 45 5d 1b 4f       	call   0x4f1b:0x5d45
    4ebd:	c9                   	leave
    4ebe:	ca 08 00             	retf   0x8
    4ec1:	55                   	push   bp
    4ec2:	89 e5                	mov    bp,sp
    4ec4:	b8 08 00             	mov    ax,0x8
    4ec7:	9a 44 04 f6 4e       	call   0x4ef6:0x444
    4ecc:	83 ec 08             	sub    sp,0x8
    4ecf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ed2:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    4ed7:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    4edb:	7f 08                	jg     0x4ee5
    4edd:	7c 21                	jl     0x4f00
    4edf:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    4ee3:	76 1b                	jbe    0x4f00
    4ee5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4ee8:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4eeb:	05 b8 bc             	add    ax,0xbcb8
    4eee:	83 d2 21             	adc    dx,0x21
    4ef1:	71 05                	jno    0x4ef8
    4ef3:	9a 3e 04 2a 4f       	call   0x4f2a:0x43e
    4ef8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4efb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4efe:	eb 0a                	jmp    0x4f0a
    4f00:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4f05:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    4f0a:	6a 08                	push   0x8
    4f0c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4f0f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4f12:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4f16:	06                   	push   es
    4f17:	57                   	push   di
    4f18:	9a b2 77 12 50       	call   0x5012:0x77b2
    4f1d:	c9                   	leave
    4f1e:	ca 0c 00             	retf   0xc
    4f21:	55                   	push   bp
    4f22:	89 e5                	mov    bp,sp
    4f24:	b8 0c 00             	mov    ax,0xc
    4f27:	9a 44 04 49 4f       	call   0x4f49:0x444
    4f2c:	83 ec 0c             	sub    sp,0xc
    4f2f:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    4f33:	74 03                	je     0x4f38
    4f35:	e9 b1 00             	jmp    0x4fe9
    4f38:	ff 76 14             	push   WORD PTR [bp+0x14]
    4f3b:	ff 76 12             	push   WORD PTR [bp+0x12]
    4f3e:	bf e7 18             	mov    di,0x18e7
    4f41:	b8 5c 4f             	mov    ax,0x4f5c
    4f44:	50                   	push   ax
    4f45:	57                   	push   di
    4f46:	9a 55 22 63 4f       	call   0x4f63:0x2255
    4f4b:	08 c0                	or     al,al
    4f4d:	75 03                	jne    0x4f52
    4f4f:	e9 97 00             	jmp    0x4fe9
    4f52:	ff 76 14             	push   WORD PTR [bp+0x14]
    4f55:	ff 76 12             	push   WORD PTR [bp+0x12]
    4f58:	bf e7 18             	mov    di,0x18e7
    4f5b:	b8 ff ff             	mov    ax,0xffff
    4f5e:	50                   	push   ax
    4f5f:	57                   	push   di
    4f60:	9a 73 22 f5 4f       	call   0x4ff5:0x2273
    4f65:	89 c7                	mov    di,ax
    4f67:	8e c2                	mov    es,dx
    4f69:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    4f6c:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    4f6f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f72:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f75:	8d 7e fc             	lea    di,[bp-0x4]
    4f78:	16                   	push   ss
    4f79:	57                   	push   di
    4f7a:	8d 7e f8             	lea    di,[bp-0x8]
    4f7d:	16                   	push   ss
    4f7e:	57                   	push   di
    4f7f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4f82:	06                   	push   es
    4f83:	57                   	push   di
    4f84:	9a 64 7f ac 4f       	call   0x4fac:0x7f64
    4f89:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4f8c:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    4f91:	99                   	cwd
    4f92:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    4f95:	7c 07                	jl     0x4f9e
    4f97:	7f 15                	jg     0x4fae
    4f99:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4f9c:	77 10                	ja     0x4fae
    4f9e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4fa1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4fa4:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4fa7:	06                   	push   es
    4fa8:	57                   	push   di
    4fa9:	9a e1 6f d1 4f       	call   0x4fd1:0x6fe1
    4fae:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4fb1:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4fb6:	99                   	cwd
    4fb7:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    4fba:	7c 07                	jl     0x4fc3
    4fbc:	7f 15                	jg     0x4fd3
    4fbe:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4fc1:	77 10                	ja     0x4fd3
    4fc3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4fc6:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4fc9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4fcc:	06                   	push   es
    4fcd:	57                   	push   di
    4fce:	9a ec 73 53 52       	call   0x5253:0x73ec
    4fd3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4fd6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4fd9:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4fdc:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4fdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fe2:	06                   	push   es
    4fe3:	57                   	push   di
    4fe4:	9a c1 4e 20 53       	call   0x5320:0x4ec1
    4fe9:	c9                   	leave
    4fea:	ca 10 00             	retf   0x10
    4fed:	55                   	push   bp
    4fee:	89 e5                	mov    bp,sp
    4ff0:	31 c0                	xor    ax,ax
    4ff2:	9a 44 04 20 50       	call   0x5020:0x444
    4ff7:	c7 06 44 01 0b 00    	mov    WORD PTR ds:0x144,0xb
    4ffd:	31 c0                	xor    ax,ax
    4fff:	a3 46 01             	mov    ds:0x146,ax
    5002:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5005:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    500a:	a3 48 01             	mov    ds:0x148,ax
    500d:	06                   	push   es
    500e:	57                   	push   di
    500f:	9a 56 55 3d 50       	call   0x503d:0x5556
    5014:	c9                   	leave
    5015:	ca 08 00             	retf   0x8
    5018:	55                   	push   bp
    5019:	89 e5                	mov    bp,sp
    501b:	31 c0                	xor    ax,ax
    501d:	9a 44 04 4b 50       	call   0x504b:0x444
    5022:	c7 06 44 01 0c 00    	mov    WORD PTR ds:0x144,0xc
    5028:	31 c0                	xor    ax,ax
    502a:	a3 46 01             	mov    ds:0x146,ax
    502d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5030:	26 8b 85 c7 03       	mov    ax,WORD PTR es:[di+0x3c7]
    5035:	a3 48 01             	mov    ds:0x148,ax
    5038:	06                   	push   es
    5039:	57                   	push   di
    503a:	9a 56 55 ff ff       	call   0xffff:0x5556
    503f:	c9                   	leave
    5040:	ca 08 00             	retf   0x8
    5043:	55                   	push   bp
    5044:	89 e5                	mov    bp,sp
    5046:	31 c0                	xor    ax,ax
    5048:	9a 44 04 66 50       	call   0x5066:0x444
    504d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5050:	26 ff b5 c7 03       	push   WORD PTR es:[di+0x3c7]
    5055:	9a 44 0e ff ff       	call   0xffff:0xe44
    505a:	c9                   	leave
    505b:	ca 08 00             	retf   0x8
    505e:	55                   	push   bp
    505f:	89 e5                	mov    bp,sp
    5061:	31 c0                	xor    ax,ax
    5063:	9a 44 04 85 50       	call   0x5085:0x444
    5068:	6a 00                	push   0x0
    506a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    506d:	26 ff b5 c7 03       	push   WORD PTR es:[di+0x3c7]
    5072:	6a 01                	push   0x1
    5074:	9a a1 0c ff ff       	call   0xffff:0xca1
    5079:	c9                   	leave
    507a:	ca 08 00             	retf   0x8
    507d:	55                   	push   bp
    507e:	89 e5                	mov    bp,sp
    5080:	31 c0                	xor    ax,ax
    5082:	9a 44 04 b9 50       	call   0x50b9:0x444
    5087:	9a 42 09 ff ff       	call   0xffff:0x942
    508c:	c9                   	leave
    508d:	ca 08 00             	retf   0x8
    5090:	cd cc                	int    0xcc
    5092:	cc                   	int3
    5093:	cc                   	int3
    5094:	cc                   	int3
    5095:	cc                   	int3
    5096:	cc                   	int3
    5097:	cc                   	int3
    5098:	fe                   	(bad)
    5099:	3f                   	aas
    509a:	00 00                	add    BYTE PTR [bx+si],al
    509c:	c8 42 66 66          	enter  0x6642,0x66
    50a0:	66 66 66 66 66 a6    	data32 data32 data32 data32 data32 cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    50a6:	ff                   	(bad)
    50a7:	3f                   	aas
    50a8:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    50ac:	ff                   	(bad)
    50ad:	7f 00                	jg     0x50af
    50af:	00 55 89             	add    BYTE PTR [di-0x77],dl
    50b2:	e5 b8                	in     ax,0xb8
    50b4:	1c 00                	sbb    al,0x0
    50b6:	9a 44 04 cf 50       	call   0x50cf:0x444
    50bb:	83 ec 1c             	sub    sp,0x1c
    50be:	ff 76 0c             	push   WORD PTR [bp+0xc]
    50c1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    50c4:	bf 94 00             	mov    di,0x94
    50c7:	b8 e2 50             	mov    ax,0x50e2
    50ca:	50                   	push   ax
    50cb:	57                   	push   di
    50cc:	9a 55 22 e9 50       	call   0x50e9:0x2255
    50d1:	08 c0                	or     al,al
    50d3:	75 03                	jne    0x50d8
    50d5:	e9 6d 02             	jmp    0x5345
    50d8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    50db:	ff 76 0a             	push   WORD PTR [bp+0xa]
    50de:	bf 94 00             	mov    di,0x94
    50e1:	b8 fa 50             	mov    ax,0x50fa
    50e4:	50                   	push   ax
    50e5:	57                   	push   di
    50e6:	9a 73 22 31 51       	call   0x5131:0x2273
    50eb:	52                   	push   dx
    50ec:	50                   	push   ax
    50ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50f0:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    50f5:	06                   	push   es
    50f6:	57                   	push   di
    50f7:	9a 2b 16 ee 51       	call   0x51ee:0x162b
    50fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    50ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5102:	26 8b 85 cb 03       	mov    ax,WORD PTR es:[di+0x3cb]
    5107:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    510a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    510d:	3d 00 00             	cmp    ax,0x0
    5110:	75 2a                	jne    0x513c
    5112:	26 c7 85 cb 03 0a 00 	mov    WORD PTR es:[di+0x3cb],0xa
    5119:	9b 26 df 85 c4 03    	fild   WORD PTR es:[di+0x3c4]
    511f:	9b 2e db 2e 90 50    	fld    TBYTE PTR cs:0x5090
    5125:	9b de c9             	fmulp  st(1),st
    5128:	9b 2e d9 06 9a 50    	fld    DWORD PTR cs:0x509a
    512e:	9a b2 04 5a 51       	call   0x515a:0x4b2
    5133:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    5137:	90                   	nop
    5138:	9b                   	fwait
    5139:	e9 9f 00             	jmp    0x51db
    513c:	3d 01 00             	cmp    ax,0x1
    513f:	75 39                	jne    0x517a
    5141:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5144:	26 c7 85 cb 03 0f 00 	mov    WORD PTR es:[di+0x3cb],0xf
    514b:	26 8b 85 c4 03       	mov    ax,WORD PTR es:[di+0x3c4]
    5150:	b9 01 00             	mov    cx,0x1
    5153:	f7 e9                	imul   cx
    5155:	71 05                	jno    0x515c
    5157:	9a 3e 04 70 51       	call   0x5170:0x43e
    515c:	99                   	cwd
    515d:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5160:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5163:	9b db 46 e8          	fild   DWORD PTR [bp-0x18]
    5167:	9b 2e d9 06 9a 50    	fld    DWORD PTR cs:0x509a
    516d:	9a b2 04 a1 51       	call   0x51a1:0x4b2
    5172:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    5176:	90                   	nop
    5177:	9b                   	fwait
    5178:	eb 61                	jmp    0x51db
    517a:	3d 02 00             	cmp    ax,0x2
    517d:	75 2c                	jne    0x51ab
    517f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5182:	26 c7 85 cb 03 14 00 	mov    WORD PTR es:[di+0x3cb],0x14
    5189:	9b 26 df 85 c4 03    	fild   WORD PTR es:[di+0x3c4]
    518f:	9b 2e db 2e 9e 50    	fld    TBYTE PTR cs:0x509e
    5195:	9b de c9             	fmulp  st(1),st
    5198:	9b 2e d9 06 9a 50    	fld    DWORD PTR cs:0x509a
    519e:	9a b2 04 bd 51       	call   0x51bd:0x4b2
    51a3:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    51a7:	90                   	nop
    51a8:	9b                   	fwait
    51a9:	eb 30                	jmp    0x51db
    51ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ae:	26 8b 85 c4 03       	mov    ax,WORD PTR es:[di+0x3c4]
    51b3:	b9 01 00             	mov    cx,0x1
    51b6:	f7 e9                	imul   cx
    51b8:	71 05                	jno    0x51bf
    51ba:	9a 3e 04 d3 51       	call   0x51d3:0x43e
    51bf:	99                   	cwd
    51c0:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    51c3:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    51c6:	9b db 46 e8          	fild   DWORD PTR [bp-0x18]
    51ca:	9b 2e d9 06 9a 50    	fld    DWORD PTR cs:0x509a
    51d0:	9a b2 04 f8 51       	call   0x51f8:0x4b2
    51d5:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    51d9:	90                   	nop
    51da:	9b                   	fwait
    51db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51de:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    51e3:	89 7e e8             	mov    WORD PTR [bp-0x18],di
    51e6:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
    51e9:	06                   	push   es
    51ea:	57                   	push   di
    51eb:	9a 26 13 23 52       	call   0x5223:0x1326
    51f0:	2d 01 00             	sub    ax,0x1
    51f3:	71 05                	jno    0x51fa
    51f5:	9a 3e 04 67 52       	call   0x5267:0x43e
    51fa:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    51fd:	31 c0                	xor    ax,ax
    51ff:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    5202:	7f 34                	jg     0x5238
    5204:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5207:	eb 03                	jmp    0x520c
    5209:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    520c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    520f:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    5212:	b0 00                	mov    al,0x0
    5214:	75 01                	jne    0x5217
    5216:	40                   	inc    ax
    5217:	50                   	push   ax
    5218:	ff 76 fa             	push   WORD PTR [bp-0x6]
    521b:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    521e:	06                   	push   es
    521f:	57                   	push   di
    5220:	9a 53 13 2e 52       	call   0x522e:0x1353
    5225:	89 c7                	mov    di,ax
    5227:	8e c2                	mov    es,dx
    5229:	06                   	push   es
    522a:	57                   	push   di
    522b:	9a 75 12 10 54       	call   0x5410:0x1275
    5230:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5233:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    5236:	75 d1                	jne    0x5209
    5238:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    523b:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    5240:	89 7e e8             	mov    WORD PTR [bp-0x18],di
    5243:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
    5246:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    524b:	99                   	cwd
    524c:	52                   	push   dx
    524d:	50                   	push   ax
    524e:	06                   	push   es
    524f:	57                   	push   di
    5250:	9a 45 73 82 52       	call   0x5282:0x7345
    5255:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5258:	26 8b 85 c9 03       	mov    ax,WORD PTR es:[di+0x3c9]
    525d:	b9 01 00             	mov    cx,0x1
    5260:	f7 e9                	imul   cx
    5262:	71 05                	jno    0x5269
    5264:	9a 3e 04 71 52       	call   0x5271:0x43e
    5269:	05 01 00             	add    ax,0x1
    526c:	71 05                	jno    0x5273
    526e:	9a 3e 04 94 52       	call   0x5294:0x43e
    5273:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5276:	6a 00                	push   0x0
    5278:	6a 00                	push   0x0
    527a:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    527d:	06                   	push   es
    527e:	57                   	push   di
    527f:	9a 30 6e 04 53       	call   0x5304:0x6e30
    5284:	8b d0                	mov    dx,ax
    5286:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5289:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    528d:	2b c2                	sub    ax,dx
    528f:	71 05                	jno    0x5296
    5291:	9a 3e 04 ac 52       	call   0x52ac:0x43e
    5296:	99                   	cwd
    5297:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    529a:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    529d:	9b db 46 e4          	fild   DWORD PTR [bp-0x1c]
    52a1:	9b dc 4e ec          	fmul   QWORD PTR [bp-0x14]
    52a5:	9b df 46 f8          	fild   WORD PTR [bp-0x8]
    52a9:	9a b2 04 b1 52       	call   0x52b1:0x4b2
    52ae:	9a 2f 10 b9 52       	call   0x52b9:0x102f
    52b3:	bf a8 50             	mov    di,0x50a8
    52b6:	9a 16 04 d6 52       	call   0x52d6:0x416
    52bb:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    52be:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    52c1:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    52c6:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    52cb:	2d 01 00             	sub    ax,0x1
    52ce:	83 da 00             	sbb    dx,0x0
    52d1:	71 05                	jno    0x52d8
    52d3:	9a 3e 04 de 52       	call   0x52de:0x43e
    52d8:	bf a8 50             	mov    di,0x50a8
    52db:	9a 16 04 5a 53       	call   0x535a:0x416
    52e0:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    52e3:	b8 01 00             	mov    ax,0x1
    52e6:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    52e9:	7f 23                	jg     0x530e
    52eb:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    52ee:	eb 03                	jmp    0x52f3
    52f0:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    52f3:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    52f6:	99                   	cwd
    52f7:	52                   	push   dx
    52f8:	50                   	push   ax
    52f9:	ff 76 f6             	push   WORD PTR [bp-0xa]
    52fc:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    52ff:	06                   	push   es
    5300:	57                   	push   di
    5301:	9a c9 70 84 53       	call   0x5384:0x70c9
    5306:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    5309:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    530c:	75 e2                	jne    0x52f0
    530e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5311:	26 8b 85 cb 03       	mov    ax,WORD PTR es:[di+0x3cb]
    5316:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5319:	74 1a                	je     0x5335
    531b:	06                   	push   es
    531c:	57                   	push   di
    531d:	9a 37 1e 33 53       	call   0x5333:0x1e37
    5322:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5325:	81 c7 50 03          	add    di,0x350
    5329:	06                   	push   es
    532a:	57                   	push   di
    532b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    532e:	06                   	push   es
    532f:	57                   	push   di
    5330:	9a d6 21 43 53       	call   0x5343:0x21d6
    5335:	ff 76 08             	push   WORD PTR [bp+0x8]
    5338:	ff 76 06             	push   WORD PTR [bp+0x6]
    533b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    533e:	06                   	push   es
    533f:	57                   	push   di
    5340:	9a 20 16 fb 53       	call   0x53fb:0x1620
    5345:	c9                   	leave
    5346:	ca 08 00             	retf   0x8
    5349:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    534d:	ff                   	(bad)
    534e:	7f 00                	jg     0x5350
    5350:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5353:	e5 b8                	in     ax,0xb8
    5355:	10 00                	adc    BYTE PTR [bx+si],al
    5357:	9a 44 04 bb 53       	call   0x53bb:0x444
    535c:	83 ec 10             	sub    sp,0x10
    535f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5362:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    5367:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    536a:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    536d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5372:	75 03                	jne    0x5377
    5374:	e9 e9 00             	jmp    0x5460
    5377:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    537c:	99                   	cwd
    537d:	52                   	push   dx
    537e:	50                   	push   ax
    537f:	06                   	push   es
    5380:	57                   	push   di
    5381:	9a 45 73 98 53       	call   0x5398:0x7345
    5386:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5389:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    538e:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    5393:	06                   	push   es
    5394:	57                   	push   di
    5395:	9a 30 6e e9 53       	call   0x53e9:0x6e30
    539a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    539d:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    53a1:	7e 50                	jle    0x53f3
    53a3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    53a6:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    53ab:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    53b0:	2d 01 00             	sub    ax,0x1
    53b3:	83 da 00             	sbb    dx,0x0
    53b6:	71 05                	jno    0x53bd
    53b8:	9a 3e 04 c3 53       	call   0x53c3:0x43e
    53bd:	bf 49 53             	mov    di,0x5349
    53c0:	9a 16 04 1a 54       	call   0x541a:0x416
    53c5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    53c8:	b8 01 00             	mov    ax,0x1
    53cb:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    53ce:	7f 23                	jg     0x53f3
    53d0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    53d3:	eb 03                	jmp    0x53d8
    53d5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    53d8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    53db:	99                   	cwd
    53dc:	52                   	push   dx
    53dd:	50                   	push   ax
    53de:	ff 76 fa             	push   WORD PTR [bp-0x6]
    53e1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    53e4:	06                   	push   es
    53e5:	57                   	push   di
    53e6:	9a c9 70 ff ff       	call   0xffff:0x70c9
    53eb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    53ee:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    53f1:	75 e2                	jne    0x53d5
    53f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53f6:	06                   	push   es
    53f7:	57                   	push   di
    53f8:	9a 37 1e 5e 54       	call   0x545e:0x1e37
    53fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5400:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    5405:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    5408:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    540b:	06                   	push   es
    540c:	57                   	push   di
    540d:	9a 26 13 3b 54       	call   0x543b:0x1326
    5412:	2d 01 00             	sub    ax,0x1
    5415:	71 05                	jno    0x541c
    5417:	9a 3e 04 ff ff       	call   0xffff:0x43e
    541c:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    541f:	31 c0                	xor    ax,ax
    5421:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    5424:	7f 2a                	jg     0x5450
    5426:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5429:	eb 03                	jmp    0x542e
    542b:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    542e:	6a 00                	push   0x0
    5430:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5433:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5436:	06                   	push   es
    5437:	57                   	push   di
    5438:	9a 53 13 46 54       	call   0x5446:0x1353
    543d:	89 c7                	mov    di,ax
    543f:	8e c2                	mov    es,dx
    5441:	06                   	push   es
    5442:	57                   	push   di
    5443:	9a 75 12 ff ff       	call   0xffff:0x1275
    5448:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    544b:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    544e:	75 db                	jne    0x542b
    5450:	ff 76 08             	push   WORD PTR [bp+0x8]
    5453:	ff 76 06             	push   WORD PTR [bp+0x6]
    5456:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5459:	06                   	push   es
    545a:	57                   	push   di
    545b:	9a 20 16 ff ff       	call   0xffff:0x1620
    5460:	c9                   	leave
    5461:	ca                   	.byte 0xca
    5462:	08                   	.byte 0x8
