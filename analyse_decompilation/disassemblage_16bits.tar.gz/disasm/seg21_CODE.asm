; ================================================================
; seg21_CODE  (12769 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	15 00 2d             	adc    ax,0x2d00
       3:	06                   	push   es
       4:	cd 00                	int    0x0
       6:	ae                   	scas   al,BYTE PTR es:[di]
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 2c          	add    BYTE PTR [bp+0x2c00],bl
       d:	06                   	push   es
       e:	fb                   	sti
       f:	04 44                	add    al,0x44
      11:	06                   	push   es
      12:	39 3f                	cmp    WORD PTR [bx],di
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 57 06 cb       	call   0xcb06:0x571f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 2e 08 d6          	adc    BYTE PTR ds:0xd608,ch
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c dd                	sbb    al,0xdd
      61:	06                   	push   es
      62:	e2 2f                	loop   0x93
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	43                   	inc    bx
      a6:	44                   	inc    sp
      a7:	49                   	dec    cx
      a8:	5f                   	pop    di
      a9:	50                   	push   ax
      aa:	72 69                	jb     0x115
      ac:	6e                   	outs   dx,BYTE PTR ds:[si]
      ad:	74 02                	je     0xb1
      af:	00 9c 06 c1          	add    BYTE PTR [si-0x3efa],bl
      b3:	00 0a                	add    BYTE PTR [bp+si],cl
      b5:	46                   	inc    si
      b6:	6f                   	outs   dx,WORD PTR ds:[si]
      b7:	72 6d                	jb     0x126
      b9:	43                   	inc    bx
      ba:	72 65                	jb     0x121
      bc:	61                   	popa
      bd:	74 65                	je     0x124
      bf:	84 0a                	test   BYTE PTR [bp+si],cl
      c1:	40                   	inc    ax
      c2:	06                   	push   es
      c3:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
      c6:	72 6d                	jb     0x135
      c8:	43                   	inc    bx
      c9:	6c                   	ins    BYTE PTR es:[di],dx
      ca:	6f                   	outs   dx,WORD PTR ds:[si]
      cb:	73 65                	jae    0x132
      cd:	6c                   	ins    BYTE PTR es:[di],dx
      ce:	00 07                	add    BYTE PTR [bx],al
      d0:	06                   	push   es
      d1:	7c 01                	jl     0xd4
      d3:	00 00                	add    BYTE PTR [bx+si],al
      d5:	06                   	push   es
      d6:	50                   	push   ax
      d7:	61                   	popa
      d8:	6e                   	outs   dx,BYTE PTR ds:[si]
      d9:	65 6c                	gs ins BYTE PTR es:[di],dx
      db:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
      df:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
      e3:	6e                   	outs   dx,BYTE PTR ds:[si]
      e4:	65 6c                	gs ins BYTE PTR es:[di],dx
      e6:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
      ea:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
      ee:	6e                   	outs   dx,BYTE PTR ds:[si]
      ef:	65 6c                	gs ins BYTE PTR es:[di],dx
      f1:	35 88 01             	xor    ax,0x188
      f4:	00 00                	add    BYTE PTR [bx+si],al
      f6:	06                   	push   es
      f7:	50                   	push   ax
      f8:	61                   	popa
      f9:	6e                   	outs   dx,BYTE PTR ds:[si]
      fa:	65 6c                	gs ins BYTE PTR es:[di],dx
      fc:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     100:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     104:	6e                   	outs   dx,BYTE PTR ds:[si]
     105:	65 6c                	gs ins BYTE PTR es:[di],dx
     107:	36 90                	ss nop
     109:	01 00                	add    WORD PTR [bx+si],ax
     10b:	00 07                	add    BYTE PTR [bx],al
     10d:	50                   	push   ax
     10e:	61                   	popa
     10f:	6e                   	outs   dx,BYTE PTR ds:[si]
     110:	65 6c                	gs ins BYTE PTR es:[di],dx
     112:	33 38                	xor    di,WORD PTR [bx+si]
     114:	94                   	xchg   sp,ax
     115:	01 04                	add    WORD PTR [si],ax
     117:	00 07                	add    BYTE PTR [bx],al
     119:	54                   	push   sp
     11a:	61                   	popa
     11b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     11e:	43                   	inc    bx
     11f:	47                   	inc    di
     120:	98                   	cbw
     121:	01 08                	add    WORD PTR [bx+si],cx
     123:	00 0c                	add    BYTE PTR [si],cl
     125:	44                   	inc    sp
     126:	61                   	popa
     127:	74 61                	je     0x18a
     129:	53                   	push   bx
     12a:	6f                   	outs   dx,WORD PTR ds:[si]
     12b:	75 72                	jne    0x19f
     12d:	63 65 43             	arpl   WORD PTR [di+0x43],sp
     130:	47                   	inc    di
     131:	9c                   	pushf
     132:	01 04                	add    WORD PTR [si],ax
     134:	00 08                	add    BYTE PTR [bx+si],cl
     136:	54                   	push   sp
     137:	61                   	popa
     138:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     13b:	43                   	inc    bx
     13c:	50                   	push   ax
     13d:	31 a0 01 08          	xor    WORD PTR [bx+si+0x801],sp
     141:	00 0d                	add    BYTE PTR [di],cl
     143:	44                   	inc    sp
     144:	61                   	popa
     145:	74 61                	je     0x1a8
     147:	53                   	push   bx
     148:	6f                   	outs   dx,WORD PTR ds:[si]
     149:	75 72                	jne    0x1bd
     14b:	63 65 43             	arpl   WORD PTR [di+0x43],sp
     14e:	50                   	push   ax
     14f:	31 a4 01 04          	xor    WORD PTR [si+0x401],sp
     153:	00 08                	add    BYTE PTR [bx+si],cl
     155:	54                   	push   sp
     156:	61                   	popa
     157:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     15a:	43                   	inc    bx
     15b:	50                   	push   ax
     15c:	32 a8 01 08          	xor    ch,BYTE PTR [bx+si+0x801]
     160:	00 0d                	add    BYTE PTR [di],cl
     162:	44                   	inc    sp
     163:	61                   	popa
     164:	74 61                	je     0x1c7
     166:	53                   	push   bx
     167:	6f                   	outs   dx,WORD PTR ds:[si]
     168:	75 72                	jne    0x1dc
     16a:	63 65 43             	arpl   WORD PTR [di+0x43],sp
     16d:	50                   	push   ax
     16e:	32 ac 01 00          	xor    ch,BYTE PTR [si+0x1]
     172:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     176:	6e                   	outs   dx,BYTE PTR ds:[si]
     177:	65 6c                	gs ins BYTE PTR es:[di],dx
     179:	34 b0                	xor    al,0xb0
     17b:	01 0c                	add    WORD PTR [si],cx
     17d:	00 09                	add    BYTE PTR [bx+di],cl
     17f:	47                   	inc    di
     180:	72 6f                	jb     0x1f1
     182:	75 70                	jne    0x1f4
     184:	42                   	inc    dx
     185:	6f                   	outs   dx,WORD PTR ds:[si]
     186:	78 31                	js     0x1b9
     188:	b4 01                	mov    ah,0x1
     18a:	0c 00                	or     al,0x0
     18c:	09 47 72             	or     WORD PTR [bx+0x72],ax
     18f:	6f                   	outs   dx,WORD PTR ds:[si]
     190:	75 70                	jne    0x202
     192:	42                   	inc    dx
     193:	6f                   	outs   dx,WORD PTR ds:[si]
     194:	78 36                	js     0x1cc
     196:	b8 01 00             	mov    ax,0x1
     199:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     19d:	6e                   	outs   dx,BYTE PTR ds:[si]
     19e:	65 6c                	gs ins BYTE PTR es:[di],dx
     1a0:	39 bc 01 10          	cmp    WORD PTR [si+0x1001],di
     1a4:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     1a8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1ab:	35 c0 01             	xor    ax,0x1c0
     1ae:	10 00                	adc    BYTE PTR [bx+si],al
     1b0:	07                   	pop    es
     1b1:	4c                   	dec    sp
     1b2:	61                   	popa
     1b3:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1b6:	31 30                	xor    WORD PTR [bx+si],si
     1b8:	c4 01                	les    ax,DWORD PTR [bx+di]
     1ba:	10 00                	adc    BYTE PTR [bx+si],al
     1bc:	06                   	push   es
     1bd:	4c                   	dec    sp
     1be:	61                   	popa
     1bf:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1c2:	37                   	aaa
     1c3:	c8 01 10 00          	enter  0x1001,0x0
     1c7:	06                   	push   es
     1c8:	4c                   	dec    sp
     1c9:	61                   	popa
     1ca:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1cd:	38 cc                	cmp    ah,cl
     1cf:	01 10                	add    WORD PTR [bx+si],dx
     1d1:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     1d5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1d8:	39 d0                	cmp    ax,dx
     1da:	01 14                	add    WORD PTR [si],dx
     1dc:	00 07                	add    BYTE PTR [bx],al
     1de:	44                   	inc    sp
     1df:	42                   	inc    dx
     1e0:	45                   	inc    bp
     1e1:	64 69 74 34 d4 01    	imul   si,WORD PTR fs:[si+0x34],0x1d4
     1e7:	14 00                	adc    al,0x0
     1e9:	07                   	pop    es
     1ea:	44                   	inc    sp
     1eb:	42                   	inc    dx
     1ec:	45                   	inc    bp
     1ed:	64 69 74 36 d8 01    	imul   si,WORD PTR fs:[si+0x36],0x1d8
     1f3:	18 00                	sbb    BYTE PTR [bx+si],al
     1f5:	05 45 64             	add    ax,0x6445
     1f8:	69 74 31 dc 01       	imul   si,WORD PTR [si+0x31],0x1dc
     1fd:	14 00                	adc    al,0x0
     1ff:	07                   	pop    es
     200:	44                   	inc    sp
     201:	42                   	inc    dx
     202:	45                   	inc    bp
     203:	64 69 74 38 e0 01    	imul   si,WORD PTR fs:[si+0x38],0x1e0
     209:	1c 00                	sbb    al,0x0
     20b:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     20e:	6d                   	ins    WORD PTR es:[di],dx
     20f:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     212:	6f                   	outs   dx,WORD PTR ds:[si]
     213:	78 31                	js     0x246
     215:	e4 01                	in     al,0x1
     217:	1c 00                	sbb    al,0x0
     219:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     21c:	6d                   	ins    WORD PTR es:[di],dx
     21d:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     220:	6f                   	outs   dx,WORD PTR ds:[si]
     221:	78 32                	js     0x255
     223:	e8 01 00             	call   0x227
     226:	00 07                	add    BYTE PTR [bx],al
     228:	50                   	push   ax
     229:	61                   	popa
     22a:	6e                   	outs   dx,BYTE PTR ds:[si]
     22b:	65 6c                	gs ins BYTE PTR es:[di],dx
     22d:	31 38                	xor    WORD PTR [bx+si],di
     22f:	ec                   	in     al,dx
     230:	01 10                	add    WORD PTR [bx+si],dx
     232:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     236:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     239:	36 f0 01 10          	lock add WORD PTR ss:[bx+si],dx
     23d:	00 07                	add    BYTE PTR [bx],al
     23f:	4c                   	dec    sp
     240:	61                   	popa
     241:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     244:	31 31                	xor    WORD PTR [bx+di],si
     246:	f4                   	hlt
     247:	01 14                	add    WORD PTR [si],dx
     249:	00 07                	add    BYTE PTR [bx],al
     24b:	44                   	inc    sp
     24c:	42                   	inc    dx
     24d:	45                   	inc    bp
     24e:	64 69 74 35 f8 01    	imul   si,WORD PTR fs:[si+0x35],0x1f8
     254:	14 00                	adc    al,0x0
     256:	07                   	pop    es
     257:	44                   	inc    sp
     258:	42                   	inc    dx
     259:	45                   	inc    bp
     25a:	64 69 74 37 fc 01    	imul   si,WORD PTR fs:[si+0x37],0x1fc
     260:	18 00                	sbb    BYTE PTR [bx+si],al
     262:	05 45 64             	add    ax,0x6445
     265:	69 74 32 00 02       	imul   si,WORD PTR [si+0x32],0x200
     26a:	14 00                	adc    al,0x0
     26c:	07                   	pop    es
     26d:	44                   	inc    sp
     26e:	42                   	inc    dx
     26f:	45                   	inc    bp
     270:	64 69 74 39 04 02    	imul   si,WORD PTR fs:[si+0x39],0x204
     276:	0c 00                	or     al,0x0
     278:	09 47 72             	or     WORD PTR [bx+0x72],ax
     27b:	6f                   	outs   dx,WORD PTR ds:[si]
     27c:	75 70                	jne    0x2ee
     27e:	42                   	inc    dx
     27f:	6f                   	outs   dx,WORD PTR ds:[si]
     280:	78 33                	js     0x2b5
     282:	08 02                	or     BYTE PTR [bp+si],al
     284:	10 00                	adc    BYTE PTR [bx+si],al
     286:	06                   	push   es
     287:	4c                   	dec    sp
     288:	61                   	popa
     289:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     28c:	31 0c                	xor    WORD PTR [si],cx
     28e:	02 14                	add    dl,BYTE PTR [si]
     290:	00 07                	add    BYTE PTR [bx],al
     292:	44                   	inc    sp
     293:	42                   	inc    dx
     294:	45                   	inc    bp
     295:	64 69 74 31 10 02    	imul   si,WORD PTR fs:[si+0x31],0x210
     29b:	0c 00                	or     al,0x0
     29d:	09 47 72             	or     WORD PTR [bx+0x72],ax
     2a0:	6f                   	outs   dx,WORD PTR ds:[si]
     2a1:	75 70                	jne    0x313
     2a3:	42                   	inc    dx
     2a4:	6f                   	outs   dx,WORD PTR ds:[si]
     2a5:	78 34                	js     0x2db
     2a7:	14 02                	adc    al,0x2
     2a9:	10 00                	adc    BYTE PTR [bx+si],al
     2ab:	06                   	push   es
     2ac:	4c                   	dec    sp
     2ad:	61                   	popa
     2ae:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2b1:	32 18                	xor    bl,BYTE PTR [bx+si]
     2b3:	02 10                	add    dl,BYTE PTR [bx+si]
     2b5:	00 07                	add    BYTE PTR [bx],al
     2b7:	4c                   	dec    sp
     2b8:	61                   	popa
     2b9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2bc:	31 32                	xor    WORD PTR [bp+si],si
     2be:	1c 02                	sbb    al,0x2
     2c0:	14 00                	adc    al,0x0
     2c2:	07                   	pop    es
     2c3:	44                   	inc    sp
     2c4:	42                   	inc    dx
     2c5:	45                   	inc    bp
     2c6:	64 69 74 32 20 02    	imul   si,WORD PTR fs:[si+0x32],0x220
     2cc:	14 00                	adc    al,0x0
     2ce:	08 44 42             	or     BYTE PTR [si+0x42],al
     2d1:	45                   	inc    bp
     2d2:	64 69 74 31 30 24    	imul   si,WORD PTR fs:[si+0x31],0x2430
     2d8:	02 0c                	add    cl,BYTE PTR [si]
     2da:	00 09                	add    BYTE PTR [bx+di],cl
     2dc:	47                   	inc    di
     2dd:	72 6f                	jb     0x34e
     2df:	75 70                	jne    0x351
     2e1:	42                   	inc    dx
     2e2:	6f                   	outs   dx,WORD PTR ds:[si]
     2e3:	78 37                	js     0x31c
     2e5:	28 02                	sub    BYTE PTR [bp+si],al
     2e7:	10 00                	adc    BYTE PTR [bx+si],al
     2e9:	07                   	pop    es
     2ea:	4c                   	dec    sp
     2eb:	61                   	popa
     2ec:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2ef:	31 35                	xor    WORD PTR [di],si
     2f1:	2c 02                	sub    al,0x2
     2f3:	14 00                	adc    al,0x0
     2f5:	07                   	pop    es
     2f6:	44                   	inc    sp
     2f7:	42                   	inc    dx
     2f8:	45                   	inc    bp
     2f9:	64 69 74 33 30 02    	imul   si,WORD PTR fs:[si+0x33],0x230
     2ff:	0c 00                	or     al,0x0
     301:	09 47 72             	or     WORD PTR [bx+0x72],ax
     304:	6f                   	outs   dx,WORD PTR ds:[si]
     305:	75 70                	jne    0x377
     307:	42                   	inc    dx
     308:	6f                   	outs   dx,WORD PTR ds:[si]
     309:	78 39                	js     0x344
     30b:	34 02                	xor    al,0x2
     30d:	10 00                	adc    BYTE PTR [bx+si],al
     30f:	07                   	pop    es
     310:	4c                   	dec    sp
     311:	61                   	popa
     312:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     315:	31 33                	xor    WORD PTR [bp+di],si
     317:	38 02                	cmp    BYTE PTR [bp+si],al
     319:	10 00                	adc    BYTE PTR [bx+si],al
     31b:	07                   	pop    es
     31c:	4c                   	dec    sp
     31d:	61                   	popa
     31e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     321:	31 34                	xor    WORD PTR [si],si
     323:	3c 02                	cmp    al,0x2
     325:	14 00                	adc    al,0x0
     327:	08 44 42             	or     BYTE PTR [si+0x42],al
     32a:	45                   	inc    bp
     32b:	64 69 74 31 31 40    	imul   si,WORD PTR fs:[si+0x31],0x4031
     331:	02 14                	add    dl,BYTE PTR [si]
     333:	00 08                	add    BYTE PTR [bx+si],cl
     335:	44                   	inc    sp
     336:	42                   	inc    dx
     337:	45                   	inc    bp
     338:	64 69 74 31 32 44    	imul   si,WORD PTR fs:[si+0x31],0x4432
     33e:	02 0c                	add    cl,BYTE PTR [si]
     340:	00 09                	add    BYTE PTR [bx+di],cl
     342:	47                   	inc    di
     343:	72 6f                	jb     0x3b4
     345:	75 70                	jne    0x3b7
     347:	42                   	inc    dx
     348:	6f                   	outs   dx,WORD PTR ds:[si]
     349:	78 38                	js     0x383
     34b:	48                   	dec    ax
     34c:	02 18                	add    bl,BYTE PTR [bx+si]
     34e:	00 05                	add    BYTE PTR [di],al
     350:	45                   	inc    bp
     351:	64 69 74 33 4c 02    	imul   si,WORD PTR fs:[si+0x33],0x24c
     357:	00 00                	add    BYTE PTR [bx+si],al
     359:	06                   	push   es
     35a:	50                   	push   ax
     35b:	61                   	popa
     35c:	6e                   	outs   dx,BYTE PTR ds:[si]
     35d:	65 6c                	gs ins BYTE PTR es:[di],dx
     35f:	37                   	aaa
     360:	50                   	push   ax
     361:	02 0c                	add    cl,BYTE PTR [si]
     363:	00 09                	add    BYTE PTR [bx+di],cl
     365:	47                   	inc    di
     366:	72 6f                	jb     0x3d7
     368:	75 70                	jne    0x3da
     36a:	42                   	inc    dx
     36b:	6f                   	outs   dx,WORD PTR ds:[si]
     36c:	78 35                	js     0x3a3
     36e:	54                   	push   sp
     36f:	02 00                	add    al,BYTE PTR [bx+si]
     371:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     375:	6e                   	outs   dx,BYTE PTR ds:[si]
     376:	65 6c                	gs ins BYTE PTR es:[di],dx
     378:	38 58 02             	cmp    BYTE PTR [bx+si+0x2],bl
     37b:	00 00                	add    BYTE PTR [bx+si],al
     37d:	07                   	pop    es
     37e:	50                   	push   ax
     37f:	61                   	popa
     380:	6e                   	outs   dx,BYTE PTR ds:[si]
     381:	65 6c                	gs ins BYTE PTR es:[di],dx
     383:	31 30                	xor    WORD PTR [bx+si],si
     385:	5c                   	pop    sp
     386:	02 00                	add    al,BYTE PTR [bx+si]
     388:	00 07                	add    BYTE PTR [bx],al
     38a:	50                   	push   ax
     38b:	61                   	popa
     38c:	6e                   	outs   dx,BYTE PTR ds:[si]
     38d:	65 6c                	gs ins BYTE PTR es:[di],dx
     38f:	31 31                	xor    WORD PTR [bx+di],si
     391:	60                   	pusha
     392:	02 00                	add    al,BYTE PTR [bx+si]
     394:	00 07                	add    BYTE PTR [bx],al
     396:	50                   	push   ax
     397:	61                   	popa
     398:	6e                   	outs   dx,BYTE PTR ds:[si]
     399:	65 6c                	gs ins BYTE PTR es:[di],dx
     39b:	31 32                	xor    WORD PTR [bp+si],si
     39d:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     3a0:	00 07                	add    BYTE PTR [bx],al
     3a2:	50                   	push   ax
     3a3:	61                   	popa
     3a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     3a5:	65 6c                	gs ins BYTE PTR es:[di],dx
     3a7:	31 33                	xor    WORD PTR [bp+di],si
     3a9:	68 02 00             	push   0x2
     3ac:	00 07                	add    BYTE PTR [bx],al
     3ae:	50                   	push   ax
     3af:	61                   	popa
     3b0:	6e                   	outs   dx,BYTE PTR ds:[si]
     3b1:	65 6c                	gs ins BYTE PTR es:[di],dx
     3b3:	31 34                	xor    WORD PTR [si],si
     3b5:	6c                   	ins    BYTE PTR es:[di],dx
     3b6:	02 00                	add    al,BYTE PTR [bx+si]
     3b8:	00 07                	add    BYTE PTR [bx],al
     3ba:	50                   	push   ax
     3bb:	61                   	popa
     3bc:	6e                   	outs   dx,BYTE PTR ds:[si]
     3bd:	65 6c                	gs ins BYTE PTR es:[di],dx
     3bf:	31 35                	xor    WORD PTR [di],si
     3c1:	70 02                	jo     0x3c5
     3c3:	00 00                	add    BYTE PTR [bx+si],al
     3c5:	07                   	pop    es
     3c6:	50                   	push   ax
     3c7:	61                   	popa
     3c8:	6e                   	outs   dx,BYTE PTR ds:[si]
     3c9:	65 6c                	gs ins BYTE PTR es:[di],dx
     3cb:	31 36 74 02          	xor    WORD PTR ds:0x274,si
     3cf:	00 00                	add    BYTE PTR [bx+si],al
     3d1:	07                   	pop    es
     3d2:	50                   	push   ax
     3d3:	61                   	popa
     3d4:	6e                   	outs   dx,BYTE PTR ds:[si]
     3d5:	65 6c                	gs ins BYTE PTR es:[di],dx
     3d7:	31 37                	xor    WORD PTR [bx],si
     3d9:	78 02                	js     0x3dd
     3db:	14 00                	adc    al,0x0
     3dd:	08 44 42             	or     BYTE PTR [si+0x42],al
     3e0:	45                   	inc    bp
     3e1:	64 69 74 31 33 7c    	imul   si,WORD PTR fs:[si+0x31],0x7c33
     3e7:	02 14                	add    dl,BYTE PTR [si]
     3e9:	00 08                	add    BYTE PTR [bx+si],cl
     3eb:	44                   	inc    sp
     3ec:	42                   	inc    dx
     3ed:	45                   	inc    bp
     3ee:	64 69 74 31 35 80    	imul   si,WORD PTR fs:[si+0x31],0x8035
     3f4:	02 14                	add    dl,BYTE PTR [si]
     3f6:	00 08                	add    BYTE PTR [bx+si],cl
     3f8:	44                   	inc    sp
     3f9:	42                   	inc    dx
     3fa:	45                   	inc    bp
     3fb:	64 69 74 31 37 84    	imul   si,WORD PTR fs:[si+0x31],0x8437
     401:	02 14                	add    dl,BYTE PTR [si]
     403:	00 08                	add    BYTE PTR [bx+si],cl
     405:	44                   	inc    sp
     406:	42                   	inc    dx
     407:	45                   	inc    bp
     408:	64 69 74 31 39 88    	imul   si,WORD PTR fs:[si+0x31],0x8839
     40e:	02 14                	add    dl,BYTE PTR [si]
     410:	00 08                	add    BYTE PTR [bx+si],cl
     412:	44                   	inc    sp
     413:	42                   	inc    dx
     414:	45                   	inc    bp
     415:	64 69 74 32 31 8c    	imul   si,WORD PTR fs:[si+0x32],0x8c31
     41b:	02 14                	add    dl,BYTE PTR [si]
     41d:	00 08                	add    BYTE PTR [bx+si],cl
     41f:	44                   	inc    sp
     420:	42                   	inc    dx
     421:	45                   	inc    bp
     422:	64 69 74 32 33 90    	imul   si,WORD PTR fs:[si+0x32],0x9033
     428:	02 14                	add    dl,BYTE PTR [si]
     42a:	00 08                	add    BYTE PTR [bx+si],cl
     42c:	44                   	inc    sp
     42d:	42                   	inc    dx
     42e:	45                   	inc    bp
     42f:	64 69 74 32 35 94    	imul   si,WORD PTR fs:[si+0x32],0x9435
     435:	02 14                	add    dl,BYTE PTR [si]
     437:	00 08                	add    BYTE PTR [bx+si],cl
     439:	44                   	inc    sp
     43a:	42                   	inc    dx
     43b:	45                   	inc    bp
     43c:	64 69 74 32 38 98    	imul   si,WORD PTR fs:[si+0x32],0x9838
     442:	02 14                	add    dl,BYTE PTR [si]
     444:	00 08                	add    BYTE PTR [bx+si],cl
     446:	44                   	inc    sp
     447:	42                   	inc    dx
     448:	45                   	inc    bp
     449:	64 69 74 32 36 9c    	imul   si,WORD PTR fs:[si+0x32],0x9c36
     44f:	02 14                	add    dl,BYTE PTR [si]
     451:	00 08                	add    BYTE PTR [bx+si],cl
     453:	44                   	inc    sp
     454:	42                   	inc    dx
     455:	45                   	inc    bp
     456:	64 69 74 32 34 a0    	imul   si,WORD PTR fs:[si+0x32],0xa034
     45c:	02 14                	add    dl,BYTE PTR [si]
     45e:	00 08                	add    BYTE PTR [bx+si],cl
     460:	44                   	inc    sp
     461:	42                   	inc    dx
     462:	45                   	inc    bp
     463:	64 69 74 32 32 a4    	imul   si,WORD PTR fs:[si+0x32],0xa432
     469:	02 14                	add    dl,BYTE PTR [si]
     46b:	00 08                	add    BYTE PTR [bx+si],cl
     46d:	44                   	inc    sp
     46e:	42                   	inc    dx
     46f:	45                   	inc    bp
     470:	64 69 74 32 30 a8    	imul   si,WORD PTR fs:[si+0x32],0xa830
     476:	02 14                	add    dl,BYTE PTR [si]
     478:	00 08                	add    BYTE PTR [bx+si],cl
     47a:	44                   	inc    sp
     47b:	42                   	inc    dx
     47c:	45                   	inc    bp
     47d:	64 69 74 31 38 ac    	imul   si,WORD PTR fs:[si+0x31],0xac38
     483:	02 14                	add    dl,BYTE PTR [si]
     485:	00 08                	add    BYTE PTR [bx+si],cl
     487:	44                   	inc    sp
     488:	42                   	inc    dx
     489:	45                   	inc    bp
     48a:	64 69 74 31 36 b0    	imul   si,WORD PTR fs:[si+0x31],0xb036
     490:	02 14                	add    dl,BYTE PTR [si]
     492:	00 08                	add    BYTE PTR [bx+si],cl
     494:	44                   	inc    sp
     495:	42                   	inc    dx
     496:	45                   	inc    bp
     497:	64 69 74 31 34 b4    	imul   si,WORD PTR fs:[si+0x31],0xb434
     49d:	02 00                	add    al,BYTE PTR [bx+si]
     49f:	00 07                	add    BYTE PTR [bx],al
     4a1:	50                   	push   ax
     4a2:	61                   	popa
     4a3:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a4:	65 6c                	gs ins BYTE PTR es:[di],dx
     4a6:	31 39                	xor    WORD PTR [bx+di],di
     4a8:	b8 02 00             	mov    ax,0x2
     4ab:	00 07                	add    BYTE PTR [bx],al
     4ad:	50                   	push   ax
     4ae:	61                   	popa
     4af:	6e                   	outs   dx,BYTE PTR ds:[si]
     4b0:	65 6c                	gs ins BYTE PTR es:[di],dx
     4b2:	32 30                	xor    dh,BYTE PTR [bx+si]
     4b4:	bc 02 0c             	mov    sp,0xc02
     4b7:	00 09                	add    BYTE PTR [bx+di],cl
     4b9:	47                   	inc    di
     4ba:	72 6f                	jb     0x52b
     4bc:	75 70                	jne    0x52e
     4be:	42                   	inc    dx
     4bf:	6f                   	outs   dx,WORD PTR ds:[si]
     4c0:	78 32                	js     0x4f4
     4c2:	c0 02 00             	rol    BYTE PTR [bp+si],0x0
     4c5:	00 07                	add    BYTE PTR [bx],al
     4c7:	50                   	push   ax
     4c8:	61                   	popa
     4c9:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ca:	65 6c                	gs ins BYTE PTR es:[di],dx
     4cc:	34 34                	xor    al,0x34
     4ce:	c4 02                	les    ax,DWORD PTR [bp+si]
     4d0:	10 00                	adc    BYTE PTR [bx+si],al
     4d2:	07                   	pop    es
     4d3:	4c                   	dec    sp
     4d4:	61                   	popa
     4d5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4d8:	55                   	push   bp
     4d9:	30 c8                	xor    al,cl
     4db:	02 10                	add    dl,BYTE PTR [bx+si]
     4dd:	00 07                	add    BYTE PTR [bx],al
     4df:	4c                   	dec    sp
     4e0:	61                   	popa
     4e1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4e4:	55                   	push   bp
     4e5:	31 cc                	xor    sp,cx
     4e7:	02 10                	add    dl,BYTE PTR [bx+si]
     4e9:	00 07                	add    BYTE PTR [bx],al
     4eb:	4c                   	dec    sp
     4ec:	61                   	popa
     4ed:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4f0:	55                   	push   bp
     4f1:	32 d0                	xor    dl,al
     4f3:	02 10                	add    dl,BYTE PTR [bx+si]
     4f5:	00 07                	add    BYTE PTR [bx],al
     4f7:	4c                   	dec    sp
     4f8:	61                   	popa
     4f9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4fc:	55                   	push   bp
     4fd:	33 d4                	xor    dx,sp
     4ff:	02 0c                	add    cl,BYTE PTR [si]
     501:	00 0a                	add    BYTE PTR [bp+si],cl
     503:	47                   	inc    di
     504:	72 6f                	jb     0x575
     506:	75 70                	jne    0x578
     508:	42                   	inc    dx
     509:	6f                   	outs   dx,WORD PTR ds:[si]
     50a:	78 31                	js     0x53d
     50c:	30 d8                	xor    al,bl
     50e:	02 00                	add    al,BYTE PTR [bx+si]
     510:	00 07                	add    BYTE PTR [bx],al
     512:	50                   	push   ax
     513:	61                   	popa
     514:	6e                   	outs   dx,BYTE PTR ds:[si]
     515:	65 6c                	gs ins BYTE PTR es:[di],dx
     517:	32 37                	xor    dh,BYTE PTR [bx]
     519:	dc 02                	fadd   QWORD PTR [bp+si]
     51b:	10 00                	adc    BYTE PTR [bx+si],al
     51d:	06                   	push   es
     51e:	4c                   	dec    sp
     51f:	61                   	popa
     520:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     523:	33 e0                	xor    sp,ax
     525:	02 00                	add    al,BYTE PTR [bx+si]
     527:	00 07                	add    BYTE PTR [bx],al
     529:	50                   	push   ax
     52a:	61                   	popa
     52b:	6e                   	outs   dx,BYTE PTR ds:[si]
     52c:	65 6c                	gs ins BYTE PTR es:[di],dx
     52e:	32 39                	xor    bh,BYTE PTR [bx+di]
     530:	e4 02                	in     al,0x2
     532:	10 00                	adc    BYTE PTR [bx+si],al
     534:	06                   	push   es
     535:	4c                   	dec    sp
     536:	61                   	popa
     537:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     53a:	34 e8                	xor    al,0xe8
     53c:	02 00                	add    al,BYTE PTR [bx+si]
     53e:	00 07                	add    BYTE PTR [bx],al
     540:	50                   	push   ax
     541:	61                   	popa
     542:	6e                   	outs   dx,BYTE PTR ds:[si]
     543:	65 6c                	gs ins BYTE PTR es:[di],dx
     545:	33 30                	xor    si,WORD PTR [bx+si]
     547:	ec                   	in     al,dx
     548:	02 18                	add    bl,BYTE PTR [bx+si]
     54a:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
     54e:	69 74 50 31 f0       	imul   si,WORD PTR [si+0x50],0xf031
     553:	02 18                	add    bl,BYTE PTR [bx+si]
     555:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
     559:	69 74 50 32 f4       	imul   si,WORD PTR [si+0x50],0xf432
     55e:	02 20                	add    ah,BYTE PTR [bx+si]
     560:	00 05                	add    BYTE PTR [di],al
     562:	4d                   	dec    bp
     563:	65 6d                	gs ins WORD PTR es:[di],dx
     565:	6f                   	outs   dx,WORD PTR ds:[si]
     566:	31 f8                	xor    ax,di
     568:	02 00                	add    al,BYTE PTR [bx+si]
     56a:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     56e:	6e                   	outs   dx,BYTE PTR ds:[si]
     56f:	65 6c                	gs ins BYTE PTR es:[di],dx
     571:	31 fc                	xor    sp,di
     573:	02 00                	add    al,BYTE PTR [bx+si]
     575:	00 07                	add    BYTE PTR [bx],al
     577:	50                   	push   ax
     578:	61                   	popa
     579:	6e                   	outs   dx,BYTE PTR ds:[si]
     57a:	65 6c                	gs ins BYTE PTR es:[di],dx
     57c:	32 31                	xor    dh,BYTE PTR [bx+di]
     57e:	00 03                	add    BYTE PTR [bp+di],al
     580:	00 00                	add    BYTE PTR [bx+si],al
     582:	07                   	pop    es
     583:	50                   	push   ax
     584:	61                   	popa
     585:	6e                   	outs   dx,BYTE PTR ds:[si]
     586:	65 6c                	gs ins BYTE PTR es:[di],dx
     588:	32 32                	xor    dh,BYTE PTR [bp+si]
     58a:	04 03                	add    al,0x3
     58c:	14 00                	adc    al,0x0
     58e:	08 44 42             	or     BYTE PTR [si+0x42],al
     591:	45                   	inc    bp
     592:	64 69 74 32 37 08    	imul   si,WORD PTR fs:[si+0x32],0x837
     598:	03 14                	add    dx,WORD PTR [si]
     59a:	00 08                	add    BYTE PTR [bx+si],cl
     59c:	44                   	inc    sp
     59d:	42                   	inc    dx
     59e:	45                   	inc    bp
     59f:	64 69 74 32 39 0c    	imul   si,WORD PTR fs:[si+0x32],0xc39
     5a5:	03 14                	add    dx,WORD PTR [si]
     5a7:	00 08                	add    BYTE PTR [bx+si],cl
     5a9:	44                   	inc    sp
     5aa:	42                   	inc    dx
     5ab:	45                   	inc    bp
     5ac:	64 69 74 33 30 10    	imul   si,WORD PTR fs:[si+0x33],0x1030
     5b2:	03 14                	add    dx,WORD PTR [si]
     5b4:	00 08                	add    BYTE PTR [bx+si],cl
     5b6:	44                   	inc    sp
     5b7:	42                   	inc    dx
     5b8:	45                   	inc    bp
     5b9:	64 69 74 33 31 14    	imul   si,WORD PTR fs:[si+0x33],0x1431
     5bf:	03 14                	add    dx,WORD PTR [si]
     5c1:	00 08                	add    BYTE PTR [bx+si],cl
     5c3:	44                   	inc    sp
     5c4:	42                   	inc    dx
     5c5:	45                   	inc    bp
     5c6:	64 69 74 33 32 18    	imul   si,WORD PTR fs:[si+0x33],0x1832
     5cc:	03 14                	add    dx,WORD PTR [si]
     5ce:	00 08                	add    BYTE PTR [bx+si],cl
     5d0:	44                   	inc    sp
     5d1:	42                   	inc    dx
     5d2:	45                   	inc    bp
     5d3:	64 69 74 33 34 1c    	imul   si,WORD PTR fs:[si+0x33],0x1c34
     5d9:	03 18                	add    bx,WORD PTR [bx+si]
     5db:	00 05                	add    BYTE PTR [di],al
     5dd:	45                   	inc    bp
     5de:	64 69 74 34 20 03    	imul   si,WORD PTR fs:[si+0x34],0x320
     5e4:	00 00                	add    BYTE PTR [bx+si],al
     5e6:	07                   	pop    es
     5e7:	50                   	push   ax
     5e8:	61                   	popa
     5e9:	6e                   	outs   dx,BYTE PTR ds:[si]
     5ea:	65 6c                	gs ins BYTE PTR es:[di],dx
     5ec:	32 33                	xor    dh,BYTE PTR [bp+di]
     5ee:	24 03                	and    al,0x3
     5f0:	10 00                	adc    BYTE PTR [bx+si],al
     5f2:	07                   	pop    es
     5f3:	4c                   	dec    sp
     5f4:	61                   	popa
     5f5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5f8:	31 36 28 03          	xor    WORD PTR ds:0x328,si
     5fc:	14 00                	adc    al,0x0
     5fe:	08 44 42             	or     BYTE PTR [si+0x42],al
     601:	45                   	inc    bp
     602:	64 69 74 33 33 09    	imul   si,WORD PTR fs:[si+0x33],0x933
     608:	00 ad 0d 44          	add    BYTE PTR [di+0x440d],ch
     60c:	1b 38                	sbb    di,WORD PTR [bx+si]
     60e:	01 56 0a             	add    WORD PTR [bp+0xa],dx
     611:	c8 08 01 0b          	enter  0x108,0xb
     615:	0c 01                	or     al,0x1
     617:	1b 06 17 06          	sbb    ax,WORD PTR ds:0x617
     61b:	23 06 22 00          	and    ax,WORD PTR ds:0x22
     61f:	e7 0a                	out    0xa,ax
     621:	90                   	nop
     622:	0b 27                	or     sp,WORD PTR [bx]
     624:	06                   	push   es
     625:	14 1b                	adc    al,0x1b
     627:	2b 06 91 12          	sub    ax,WORD PTR ds:0x1291
     62b:	50                   	push   ax
     62c:	09 07                	or     WORD PTR [bx],ax
     62e:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
     632:	72 6d                	jb     0x6a1
     634:	53                   	push   bx
     635:	43                   	inc    bx
     636:	44                   	inc    sp
     637:	49                   	dec    cx
     638:	5f                   	pop    di
     639:	50                   	push   ax
     63a:	72 69                	jb     0x6a5
     63c:	6e                   	outs   dx,BYTE PTR ds:[si]
     63d:	74 22                	je     0x661
     63f:	00 96 0a 7b          	add    BYTE PTR [bp+0x7b0a],dl
     643:	06                   	push   es
     644:	6f                   	outs   dx,WORD PTR ds:[si]
     645:	06                   	push   es
     646:	38 00                	cmp    BYTE PTR [bx+si],al
     648:	04 53                	add    al,0x53
     64a:	63 64 69             	arpl   WORD PTR [si+0x69],sp
     64d:	00 00                	add    BYTE PTR [bx+si],al
     64f:	55                   	push   bp
     650:	89 e5                	mov    bp,sp
     652:	31 c0                	xor    ax,ax
     654:	9a 44 04 a5 06       	call   0x6a5:0x444
     659:	6a 00                	push   0x0
     65b:	9a c2 38 af 14       	call   0x14af:0x38c2
     660:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     663:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     66a:	06                   	push   es
     66b:	57                   	push   di
     66c:	9a 56 55 46 07       	call   0x746:0x5556
     671:	9a c3 28 21 07       	call   0x721:0x28c3
     676:	c9                   	leave
     677:	ca 04 00             	retf   0x4
     67a:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     67d:	6d                   	ins    WORD PTR es:[di],dx
     67e:	73 74                	jae    0x6f4
     680:	72 61                	jb     0x6e3
     682:	74 20                	je     0x6a4
     684:	2d 20 03             	sub    ax,0x320
     687:	20 2d                	and    BYTE PTR [di],ch
     689:	20 07                	and    BYTE PTR [bx],al
     68b:	4e                   	dec    si
     68c:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
     691:	20 01                	and    BYTE PTR [bx+di],al
     693:	2d 00 00             	sub    ax,0x0
     696:	00 00                	add    BYTE PTR [bx+si],al
     698:	02 00                	add    al,BYTE PTR [bx+si]
     69a:	00 00                	add    BYTE PTR [bx+si],al
     69c:	55                   	push   bp
     69d:	89 e5                	mov    bp,sp
     69f:	b8 04 04             	mov    ax,0x404
     6a2:	9a 44 04 b9 06       	call   0x6b9:0x444
     6a7:	81 ec 04 04          	sub    sp,0x404
     6ab:	8d be fc fd          	lea    di,[bp-0x204]
     6af:	16                   	push   ss
     6b0:	57                   	push   di
     6b1:	bf 7a 06             	mov    di,0x67a
     6b4:	0e                   	push   cs
     6b5:	57                   	push   di
     6b6:	9a cd 17 c3 06       	call   0x6c3:0x17cd
     6bb:	bf fa 1d             	mov    di,0x1dfa
     6be:	1e                   	push   ds
     6bf:	57                   	push   di
     6c0:	9a 4c 18 cd 06       	call   0x6cd:0x184c
     6c5:	bf 86 06             	mov    di,0x686
     6c8:	0e                   	push   cs
     6c9:	57                   	push   di
     6ca:	9a 4c 18 e2 06       	call   0x6e2:0x184c
     6cf:	8d be fc fc          	lea    di,[bp-0x304]
     6d3:	16                   	push   ss
     6d4:	57                   	push   di
     6d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6d8:	06                   	push   es
     6d9:	57                   	push   di
     6da:	9a 53 1d ec 06       	call   0x6ec:0x1d53
     6df:	9a 4c 18 10 07       	call   0x710:0x184c
     6e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6e7:	06                   	push   es
     6e8:	57                   	push   di
     6e9:	9a 8c 1d 00 07       	call   0x700:0x1d8c
     6ee:	bf fa 1d             	mov    di,0x1dfa
     6f1:	1e                   	push   ds
     6f2:	57                   	push   di
     6f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6f6:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     6fb:	06                   	push   es
     6fc:	57                   	push   di
     6fd:	9a 8c 1d 35 07       	call   0x735:0x1d8c
     702:	8d be fc fc          	lea    di,[bp-0x304]
     706:	16                   	push   ss
     707:	57                   	push   di
     708:	bf 8a 06             	mov    di,0x68a
     70b:	0e                   	push   cs
     70c:	57                   	push   di
     70d:	9a cd 17 26 07       	call   0x726:0x17cd
     712:	8d be fc fd          	lea    di,[bp-0x204]
     716:	16                   	push   ss
     717:	57                   	push   di
     718:	a1 06 1e             	mov    ax,ds:0x1e06
     71b:	99                   	cwd
     71c:	52                   	push   dx
     71d:	50                   	push   ax
     71e:	9a a9 08 ea 09       	call   0x9ea:0x8a9
     723:	9a 4c 18 9a 07       	call   0x79a:0x184c
     728:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     72b:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
     730:	06                   	push   es
     731:	57                   	push   di
     732:	9a 8c 1d 64 08       	call   0x864:0x1d8c
     737:	6a 00                	push   0x0
     739:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     73c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     741:	06                   	push   es
     742:	57                   	push   di
     743:	9a d0 1c 57 07       	call   0x757:0x1cd0
     748:	6a 00                	push   0x0
     74a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     74d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     752:	06                   	push   es
     753:	57                   	push   di
     754:	9a d0 1c 75 0b       	call   0xb75:0x1cd0
     759:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     75c:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     761:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     765:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     769:	31 c0                	xor    ax,ax
     76b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     76e:	eb 03                	jmp    0x773
     770:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     773:	8d be f8 fd          	lea    di,[bp-0x208]
     777:	16                   	push   ss
     778:	57                   	push   di
     779:	ff 76 fe             	push   WORD PTR [bp-0x2]
     77c:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     780:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     785:	06                   	push   es
     786:	57                   	push   di
     787:	26 c4 3d             	les    di,DWORD PTR es:[di]
     78a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
     78e:	8d be fc fe          	lea    di,[bp-0x104]
     792:	16                   	push   ss
     793:	57                   	push   di
     794:	68 ff 00             	push   0xff
     797:	9a e7 17 aa 07       	call   0x7aa:0x17e7
     79c:	bf 92 06             	mov    di,0x692
     79f:	0e                   	push   cs
     7a0:	57                   	push   di
     7a1:	8d be fc fe          	lea    di,[bp-0x104]
     7a5:	16                   	push   ss
     7a6:	57                   	push   di
     7a7:	9a 78 18 c6 07       	call   0x7c6:0x1878
     7ac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     7af:	8d be f8 fd          	lea    di,[bp-0x208]
     7b3:	16                   	push   ss
     7b4:	57                   	push   di
     7b5:	8d be fc fe          	lea    di,[bp-0x104]
     7b9:	16                   	push   ss
     7ba:	57                   	push   di
     7bb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     7be:	05 01 00             	add    ax,0x1
     7c1:	71 05                	jno    0x7c8
     7c3:	9a 3e 04 ce 07       	call   0x7ce:0x43e
     7c8:	50                   	push   ax
     7c9:	6a 64                	push   0x64
     7cb:	9a 0b 18 da 07       	call   0x7da:0x180b
     7d0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     7d3:	99                   	cwd
     7d4:	bf 94 06             	mov    di,0x694
     7d7:	9a 16 04 f0 07       	call   0x7f0:0x416
     7dc:	c1 e0 08             	shl    ax,0x8
     7df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7e2:	03 f8                	add    di,ax
     7e4:	81 c7 2c 03          	add    di,0x32c
     7e8:	06                   	push   es
     7e9:	57                   	push   di
     7ea:	68 ff 00             	push   0xff
     7ed:	9a e7 17 00 08       	call   0x800:0x17e7
     7f2:	8d be fc fe          	lea    di,[bp-0x104]
     7f6:	16                   	push   ss
     7f7:	57                   	push   di
     7f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
     7fb:	6a 64                	push   0x64
     7fd:	9a 75 19 38 08       	call   0x838:0x1975
     802:	ff 76 fe             	push   WORD PTR [bp-0x2]
     805:	8d be fc fe          	lea    di,[bp-0x104]
     809:	16                   	push   ss
     80a:	57                   	push   di
     80b:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     80f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     814:	06                   	push   es
     815:	57                   	push   di
     816:	26 c4 3d             	les    di,DWORD PTR es:[di]
     819:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
     81d:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
     821:	74 03                	je     0x826
     823:	e9 4a ff             	jmp    0x770
     826:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     829:	06                   	push   es
     82a:	57                   	push   di
     82b:	9a 7d 52 5c 08       	call   0x85c:0x527d
     830:	2d 01 00             	sub    ax,0x1
     833:	71 05                	jno    0x83a
     835:	9a 3e 04 6b 08       	call   0x86b:0x43e
     83a:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
     83e:	31 c0                	xor    ax,ax
     840:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
     844:	7e 03                	jle    0x849
     846:	e9 ab 00             	jmp    0x8f4
     849:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     84c:	eb 03                	jmp    0x851
     84e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     851:	ff 76 fe             	push   WORD PTR [bp-0x2]
     854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     857:	06                   	push   es
     858:	57                   	push   di
     859:	9a 46 52 7c 08       	call   0x87c:0x5246
     85e:	52                   	push   dx
     85f:	50                   	push   ax
     860:	bf 99 03             	mov    di,0x399
     863:	b8 84 08             	mov    ax,0x884
     866:	50                   	push   ax
     867:	57                   	push   di
     868:	9a 55 22 8b 08       	call   0x88b:0x2255
     86d:	08 c0                	or     al,al
     86f:	74 77                	je     0x8e8
     871:	ff 76 fe             	push   WORD PTR [bp-0x2]
     874:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     877:	06                   	push   es
     878:	57                   	push   di
     879:	9a 46 52 a9 0c       	call   0xca9:0x5246
     87e:	52                   	push   dx
     87f:	50                   	push   ax
     880:	bf 99 03             	mov    di,0x399
     883:	b8 e6 08             	mov    ax,0x8e6
     886:	50                   	push   ax
     887:	57                   	push   di
     888:	9a 73 22 ca 08       	call   0x8ca:0x2273
     88d:	89 c7                	mov    di,ax
     88f:	8e c2                	mov    es,dx
     891:	89 be f6 fe          	mov    WORD PTR [bp-0x10a],di
     895:	8c 86 f8 fe          	mov    WORD PTR [bp-0x108],es
     899:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
     89e:	74 48                	je     0x8e8
     8a0:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     8a4:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
     8a8:	74 3e                	je     0x8e8
     8aa:	a1 06 1e             	mov    ax,ds:0x1e06
     8ad:	99                   	cwd
     8ae:	8b c8                	mov    cx,ax
     8b0:	8b da                	mov    bx,dx
     8b2:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     8b6:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     8ba:	09 d2                	or     dx,dx
     8bc:	79 07                	jns    0x8c5
     8be:	f7 d2                	not    dx
     8c0:	f7 d8                	neg    ax
     8c2:	83 da ff             	sbb    dx,0xffff
     8c5:	71 05                	jno    0x8cc
     8c7:	9a 3e 04 df 09       	call   0x9df:0x43e
     8cc:	3b d3                	cmp    dx,bx
     8ce:	7c 0a                	jl     0x8da
     8d0:	7f 04                	jg     0x8d6
     8d2:	3b c1                	cmp    ax,cx
     8d4:	76 04                	jbe    0x8da
     8d6:	b0 00                	mov    al,0x0
     8d8:	eb 02                	jmp    0x8dc
     8da:	b0 01                	mov    al,0x1
     8dc:	50                   	push   ax
     8dd:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
     8e1:	06                   	push   es
     8e2:	57                   	push   di
     8e3:	9a 77 1c 66 09       	call   0x966:0x1c77
     8e8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     8eb:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
     8ef:	74 03                	je     0x8f4
     8f1:	e9 5a ff             	jmp    0x84e
     8f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8f7:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     8fc:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     901:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     905:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     909:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
     90e:	7f 0b                	jg     0x91b
     910:	6a 02                	push   0x2
     912:	06                   	push   es
     913:	57                   	push   di
     914:	26 c4 3d             	les    di,DWORD PTR es:[di]
     917:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     91b:	83 3e 06 1e 01       	cmp    WORD PTR ds:0x1e06,0x1
     920:	7f 0f                	jg     0x931
     922:	6a 01                	push   0x1
     924:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     928:	06                   	push   es
     929:	57                   	push   di
     92a:	26 c4 3d             	les    di,DWORD PTR es:[di]
     92d:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     934:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     939:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
     93e:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
     943:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     946:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
     94b:	06                   	push   es
     94c:	57                   	push   di
     94d:	9a 4d 5d 2e 10       	call   0x102e:0x5d4d
     952:	8d be fc fd          	lea    di,[bp-0x204]
     956:	16                   	push   ss
     957:	57                   	push   di
     958:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     95c:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
     961:	06                   	push   es
     962:	57                   	push   di
     963:	9a 53 1d 75 09       	call   0x975:0x1d53
     968:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     96b:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
     970:	06                   	push   es
     971:	57                   	push   di
     972:	9a 8c 1d 8b 09       	call   0x98b:0x1d8c
     977:	8d be fc fd          	lea    di,[bp-0x204]
     97b:	16                   	push   ss
     97c:	57                   	push   di
     97d:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     981:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
     986:	06                   	push   es
     987:	57                   	push   di
     988:	9a 53 1d 9a 09       	call   0x99a:0x1d53
     98d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     990:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
     995:	06                   	push   es
     996:	57                   	push   di
     997:	9a 8c 1d b0 09       	call   0x9b0:0x1d8c
     99c:	8d be fc fd          	lea    di,[bp-0x204]
     9a0:	16                   	push   ss
     9a1:	57                   	push   di
     9a2:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     9a6:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
     9ab:	06                   	push   es
     9ac:	57                   	push   di
     9ad:	9a 53 1d bf 09       	call   0x9bf:0x1d53
     9b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9b5:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
     9ba:	06                   	push   es
     9bb:	57                   	push   di
     9bc:	9a 8c 1d d5 09       	call   0x9d5:0x1d8c
     9c1:	8d be fc fd          	lea    di,[bp-0x204]
     9c5:	16                   	push   ss
     9c6:	57                   	push   di
     9c7:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     9cb:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
     9d0:	06                   	push   es
     9d1:	57                   	push   di
     9d2:	9a 53 1d 42 0a       	call   0xa42:0x1d53
     9d7:	bf 86 06             	mov    di,0x686
     9da:	0e                   	push   cs
     9db:	57                   	push   di
     9dc:	9a 4c 18 ff 09       	call   0x9ff:0x184c
     9e1:	8d be fc fc          	lea    di,[bp-0x304]
     9e5:	16                   	push   ss
     9e6:	57                   	push   di
     9e7:	9a fe 15 fa 09       	call   0x9fa:0x15fe
     9ec:	83 ec 08             	sub    sp,0x8
     9ef:	89 e3                	mov    bx,sp
     9f1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     9f5:	90                   	nop
     9f6:	9b                   	fwait
     9f7:	9a bf 1c 14 0a       	call   0xa14:0x1cbf
     9fc:	9a 4c 18 09 0a       	call   0xa09:0x184c
     a01:	bf 86 06             	mov    di,0x686
     a04:	0e                   	push   cs
     a05:	57                   	push   di
     a06:	9a 4c 18 29 0a       	call   0xa29:0x184c
     a0b:	8d be fc fb          	lea    di,[bp-0x404]
     a0f:	16                   	push   ss
     a10:	57                   	push   di
     a11:	9a fe 15 24 0a       	call   0xa24:0x15fe
     a16:	83 ec 08             	sub    sp,0x8
     a19:	89 e3                	mov    bx,sp
     a1b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     a1f:	90                   	nop
     a20:	9b                   	fwait
     a21:	9a e4 1c ed 10       	call   0x10ed:0x1ce4
     a26:	9a 4c 18 33 0a       	call   0xa33:0x184c
     a2b:	bf 86 06             	mov    di,0x686
     a2e:	0e                   	push   cs
     a2f:	57                   	push   di
     a30:	9a 4c 18 8c 0a       	call   0xa8c:0x184c
     a35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a38:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
     a3d:	06                   	push   es
     a3e:	57                   	push   di
     a3f:	9a 8c 1d 14 0f       	call   0xf14:0x1d8c
     a44:	bf 16 1e             	mov    di,0x1e16
     a47:	1e                   	push   ds
     a48:	57                   	push   di
     a49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a4c:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     a51:	06                   	push   es
     a52:	57                   	push   di
     a53:	9a 17 30 6a 0a       	call   0xa6a:0x3017
     a58:	bf 24 1e             	mov    di,0x1e24
     a5b:	1e                   	push   ds
     a5c:	57                   	push   di
     a5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a60:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
     a65:	06                   	push   es
     a66:	57                   	push   di
     a67:	9a 17 30 7e 0a       	call   0xa7e:0x3017
     a6c:	bf 24 1e             	mov    di,0x1e24
     a6f:	1e                   	push   ds
     a70:	57                   	push   di
     a71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a74:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
     a79:	06                   	push   es
     a7a:	57                   	push   di
     a7b:	9a 17 30 13 0b       	call   0xb13:0x3017
     a80:	c9                   	leave
     a81:	ca 08 00             	retf   0x8
     a84:	55                   	push   bp
     a85:	89 e5                	mov    bp,sp
     a87:	31 c0                	xor    ax,ax
     a89:	9a 44 04 c7 0a       	call   0xac7:0x444
     a8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a91:	06                   	push   es
     a92:	57                   	push   di
     a93:	9a 1b 0d 0d 0d       	call   0xd0d:0xd1b
     a98:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a9b:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
     a9f:	c9                   	leave
     aa0:	ca 0c 00             	retf   0xc
     aa3:	07                   	pop    es
     aa4:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
     aa8:	2b 30                	sub    si,WORD PTR [bx+si]
     aaa:	30 01                	xor    BYTE PTR [bx+di],al
     aac:	30 0a                	xor    BYTE PTR [bp+si],cl
     aae:	23 2c                	and    bp,WORD PTR [si]
     ab0:	23 23                	and    sp,WORD PTR [bp+di]
     ab2:	30 2e 30 30          	xor    BYTE PTR ds:0x3030,ch
     ab6:	23 23                	and    sp,WORD PTR [bp+di]
     ab8:	05 23 2c             	add    ax,0x2c23
     abb:	23 23                	and    sp,WORD PTR [bp+di]
     abd:	30 55 89             	xor    BYTE PTR [di-0x77],dl
     ac0:	e5 b8                	in     ax,0xb8
     ac2:	0c 02                	or     al,0x2
     ac4:	9a 44 04 1a 0b       	call   0xb1a:0x444
     ac9:	81 ec 0c 02          	sub    sp,0x20c
     acd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ad0:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     ad4:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     ad8:	8d be f8 fd          	lea    di,[bp-0x208]
     adc:	16                   	push   ss
     add:	57                   	push   di
     ade:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     ae2:	06                   	push   es
     ae3:	57                   	push   di
     ae4:	9a 9f 1a f2 0a       	call   0xaf2:0x1a9f
     ae9:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     aed:	06                   	push   es
     aee:	57                   	push   di
     aef:	9a 5f 1a da 0c       	call   0xcda:0x1a5f
     af4:	89 c7                	mov    di,ax
     af6:	8e c2                	mov    es,dx
     af8:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     afc:	06                   	push   es
     afd:	57                   	push   di
     afe:	9a 9b 3b 51 0b       	call   0xb51:0x3b9b
     b03:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b06:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     b09:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b0c:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b0f:	bf 58 0a             	mov    di,0xa58
     b12:	b8 2d 0b             	mov    ax,0xb2d
     b15:	50                   	push   ax
     b16:	57                   	push   di
     b17:	9a 55 22 34 0b       	call   0xb34:0x2255
     b1c:	08 c0                	or     al,al
     b1e:	75 03                	jne    0xb23
     b20:	e9 26 01             	jmp    0xc49
     b23:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b26:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b29:	bf 58 0a             	mov    di,0xa58
     b2c:	b8 33 0c             	mov    ax,0xc33
     b2f:	50                   	push   ax
     b30:	57                   	push   di
     b31:	9a 73 22 5f 0b       	call   0xb5f:0x2273
     b36:	89 c7                	mov    di,ax
     b38:	8e c2                	mov    es,dx
     b3a:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
     b3e:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
     b42:	8d be f4 fd          	lea    di,[bp-0x20c]
     b46:	16                   	push   ss
     b47:	57                   	push   di
     b48:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     b4c:	06                   	push   es
     b4d:	57                   	push   di
     b4e:	9a cf 68 32 0d       	call   0xd32:0x68cf
     b53:	8d be fc fe          	lea    di,[bp-0x104]
     b57:	16                   	push   ss
     b58:	57                   	push   di
     b59:	68 ff 00             	push   0xff
     b5c:	9a e7 17 bb 0b       	call   0xbbb:0x17e7
     b61:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     b65:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
     b69:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
     b6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b70:	06                   	push   es
     b71:	57                   	push   di
     b72:	9a d5 33 90 0b       	call   0xb90:0x33d5
     b77:	89 c7                	mov    di,ax
     b79:	8e c2                	mov    es,dx
     b7b:	06                   	push   es
     b7c:	57                   	push   di
     b7d:	9a 99 20 9b 0b       	call   0xb9b:0x2099
     b82:	8d be fc fe          	lea    di,[bp-0x104]
     b86:	16                   	push   ss
     b87:	57                   	push   di
     b88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b8b:	06                   	push   es
     b8c:	57                   	push   di
     b8d:	9a d5 33 cb 0b       	call   0xbcb:0x33d5
     b92:	89 c7                	mov    di,ax
     b94:	8e c2                	mov    es,dx
     b96:	06                   	push   es
     b97:	57                   	push   di
     b98:	9a 03 20 d6 0b       	call   0xbd6:0x2003
     b9d:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     ba1:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     ba5:	7d 03                	jge    0xbaa
     ba7:	e9 8d 00             	jmp    0xc37
     baa:	bf a3 0a             	mov    di,0xaa3
     bad:	0e                   	push   cs
     bae:	57                   	push   di
     baf:	8d be fc fe          	lea    di,[bp-0x104]
     bb3:	16                   	push   ss
     bb4:	57                   	push   di
     bb5:	68 ff 00             	push   0xff
     bb8:	9a e7 17 0a 0c       	call   0xc0a:0x17e7
     bbd:	8d be fc fe          	lea    di,[bp-0x104]
     bc1:	16                   	push   ss
     bc2:	57                   	push   di
     bc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bc6:	06                   	push   es
     bc7:	57                   	push   di
     bc8:	9a d5 33 bc 13       	call   0x13bc:0x33d5
     bcd:	89 c7                	mov    di,ax
     bcf:	8e c2                	mov    es,dx
     bd1:	06                   	push   es
     bd2:	57                   	push   di
     bd3:	9a 03 20 a3 15       	call   0x15a3:0x2003
     bd8:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     bdc:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     be0:	b0 00                	mov    al,0x0
     be2:	7d 01                	jge    0xbe5
     be4:	40                   	inc    ax
     be5:	8a d0                	mov    dl,al
     be7:	80 be fc fe 0c       	cmp    BYTE PTR [bp-0x104],0xc
     bec:	b0 00                	mov    al,0x0
     bee:	73 01                	jae    0xbf1
     bf0:	40                   	inc    ax
     bf1:	22 c2                	and    al,dl
     bf3:	08 c0                	or     al,al
     bf5:	74 17                	je     0xc0e
     bf7:	bf ab 0a             	mov    di,0xaab
     bfa:	0e                   	push   cs
     bfb:	57                   	push   di
     bfc:	8d be fc fe          	lea    di,[bp-0x104]
     c00:	16                   	push   ss
     c01:	57                   	push   di
     c02:	68 ff 00             	push   0xff
     c05:	6a 03                	push   0x3
     c07:	9a 16 19 22 0c       	call   0xc22:0x1916
     c0c:	eb af                	jmp    0xbbd
     c0e:	80 be fc fe 07       	cmp    BYTE PTR [bp-0x104],0x7
     c13:	76 0f                	jbe    0xc24
     c15:	8d be fc fe          	lea    di,[bp-0x104]
     c19:	16                   	push   ss
     c1a:	57                   	push   di
     c1b:	6a 03                	push   0x3
     c1d:	6a 01                	push   0x1
     c1f:	9a 75 19 5a 0c       	call   0xc5a:0x1975
     c24:	8d be fc fe          	lea    di,[bp-0x104]
     c28:	16                   	push   ss
     c29:	57                   	push   di
     c2a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     c2e:	06                   	push   es
     c2f:	57                   	push   di
     c30:	9a f9 60 45 0c       	call   0xc45:0x60f9
     c35:	eb 10                	jmp    0xc47
     c37:	bf ad 0a             	mov    di,0xaad
     c3a:	0e                   	push   cs
     c3b:	57                   	push   di
     c3c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     c40:	06                   	push   es
     c41:	57                   	push   di
     c42:	9a f9 60 53 0c       	call   0xc53:0x60f9
     c47:	eb 46                	jmp    0xc8f
     c49:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c4c:	ff 76 fc             	push   WORD PTR [bp-0x4]
     c4f:	bf c8 07             	mov    di,0x7c8
     c52:	b8 6a 0c             	mov    ax,0xc6a
     c55:	50                   	push   ax
     c56:	57                   	push   di
     c57:	9a 55 22 71 0c       	call   0xc71:0x2255
     c5c:	08 c0                	or     al,al
     c5e:	74 2f                	je     0xc8f
     c60:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c63:	ff 76 fc             	push   WORD PTR [bp-0x4]
     c66:	bf c8 07             	mov    di,0x7c8
     c69:	b8 8d 0c             	mov    ax,0xc8d
     c6c:	50                   	push   ax
     c6d:	57                   	push   di
     c6e:	9a 73 22 9c 0c       	call   0xc9c:0x2273
     c73:	89 c7                	mov    di,ax
     c75:	8e c2                	mov    es,dx
     c77:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
     c7b:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
     c7f:	bf b8 0a             	mov    di,0xab8
     c82:	0e                   	push   cs
     c83:	57                   	push   di
     c84:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     c88:	06                   	push   es
     c89:	57                   	push   di
     c8a:	9a f9 60 83 0d       	call   0xd83:0x60f9
     c8f:	c9                   	leave
     c90:	ca 08 00             	retf   0x8
     c93:	55                   	push   bp
     c94:	89 e5                	mov    bp,sp
     c96:	b8 04 00             	mov    ax,0x4
     c99:	9a 44 04 b3 0c       	call   0xcb3:0x444
     c9e:	83 ec 04             	sub    sp,0x4
     ca1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ca4:	06                   	push   es
     ca5:	57                   	push   di
     ca6:	9a 7d 52 d2 0c       	call   0xcd2:0x527d
     cab:	2d 01 00             	sub    ax,0x1
     cae:	71 05                	jno    0xcb5
     cb0:	9a 3e 04 e1 0c       	call   0xce1:0x43e
     cb5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cb8:	31 c0                	xor    ax,ax
     cba:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     cbd:	7f 58                	jg     0xd17
     cbf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     cc2:	eb 03                	jmp    0xcc7
     cc4:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     cc7:	ff 76 fe             	push   WORD PTR [bp-0x2]
     cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ccd:	06                   	push   es
     cce:	57                   	push   di
     ccf:	9a 46 52 f2 0c       	call   0xcf2:0x5246
     cd4:	52                   	push   dx
     cd5:	50                   	push   ax
     cd6:	bf 22 00             	mov    di,0x22
     cd9:	b8 fa 0c             	mov    ax,0xcfa
     cdc:	50                   	push   ax
     cdd:	57                   	push   di
     cde:	9a 55 22 01 0d       	call   0xd01:0x2255
     ce3:	08 c0                	or     al,al
     ce5:	74 28                	je     0xd0f
     ce7:	ff 76 fe             	push   WORD PTR [bp-0x2]
     cea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ced:	06                   	push   es
     cee:	57                   	push   di
     cef:	9a 46 52 ff ff       	call   0xffff:0x5246
     cf4:	52                   	push   dx
     cf5:	50                   	push   ax
     cf6:	bf 22 00             	mov    di,0x22
     cf9:	b8 43 1c             	mov    ax,0x1c43
     cfc:	50                   	push   ax
     cfd:	57                   	push   di
     cfe:	9a 73 22 23 0d       	call   0xd23:0x2273
     d03:	52                   	push   dx
     d04:	50                   	push   ax
     d05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d08:	06                   	push   es
     d09:	57                   	push   di
     d0a:	9a be 0a 7b 0e       	call   0xe7b:0xabe
     d0f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d12:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     d15:	75 ad                	jne    0xcc4
     d17:	c9                   	leave
     d18:	ca 04 00             	retf   0x4
     d1b:	55                   	push   bp
     d1c:	89 e5                	mov    bp,sp
     d1e:	31 c0                	xor    ax,ax
     d20:	9a 44 04 5f 0d       	call   0xd5f:0x444
     d25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d28:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     d2d:	06                   	push   es
     d2e:	57                   	push   di
     d2f:	9a d2 31 41 0d       	call   0xd41:0x31d2
     d34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d37:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
     d3c:	06                   	push   es
     d3d:	57                   	push   di
     d3e:	9a d2 31 50 0d       	call   0xd50:0x31d2
     d43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d46:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
     d4b:	06                   	push   es
     d4c:	57                   	push   di
     d4d:	9a d2 31 77 0d       	call   0xd77:0x31d2
     d52:	c9                   	leave
     d53:	ca 04 00             	retf   0x4
     d56:	55                   	push   bp
     d57:	89 e5                	mov    bp,sp
     d59:	b8 04 00             	mov    ax,0x4
     d5c:	9a 44 04 86 0e       	call   0xe86:0x444
     d61:	83 ec 04             	sub    sp,0x4
     d64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d67:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     d6c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     d6f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     d72:	06                   	push   es
     d73:	57                   	push   di
     d74:	9a d2 31 99 0d       	call   0xd99:0x31d2
     d79:	6a 01                	push   0x1
     d7b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d7e:	06                   	push   es
     d7f:	57                   	push   di
     d80:	9a fb 2f 8f 0d       	call   0xd8f:0x2ffb
     d85:	6a 00                	push   0x0
     d87:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d8a:	06                   	push   es
     d8b:	57                   	push   di
     d8c:	9a d2 2e ba 0d       	call   0xdba:0x2ed2
     d91:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d94:	06                   	push   es
     d95:	57                   	push   di
     d96:	9a bf 31 ae 0d       	call   0xdae:0x31bf
     d9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d9e:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
     da3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     da6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     da9:	06                   	push   es
     daa:	57                   	push   di
     dab:	9a d2 31 d0 0d       	call   0xdd0:0x31d2
     db0:	6a 01                	push   0x1
     db2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     db5:	06                   	push   es
     db6:	57                   	push   di
     db7:	9a fb 2f c6 0d       	call   0xdc6:0x2ffb
     dbc:	6a 00                	push   0x0
     dbe:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dc1:	06                   	push   es
     dc2:	57                   	push   di
     dc3:	9a d2 2e f1 0d       	call   0xdf1:0x2ed2
     dc8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dcb:	06                   	push   es
     dcc:	57                   	push   di
     dcd:	9a bf 31 e5 0d       	call   0xde5:0x31bf
     dd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dd5:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
     dda:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     ddd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     de0:	06                   	push   es
     de1:	57                   	push   di
     de2:	9a d2 31 07 0e       	call   0xe07:0x31d2
     de7:	6a 01                	push   0x1
     de9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dec:	06                   	push   es
     ded:	57                   	push   di
     dee:	9a fb 2f fd 0d       	call   0xdfd:0x2ffb
     df3:	6a 00                	push   0x0
     df5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     df8:	06                   	push   es
     df9:	57                   	push   di
     dfa:	9a d2 2e c5 0e       	call   0xec5:0x2ed2
     dff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e02:	06                   	push   es
     e03:	57                   	push   di
     e04:	9a bf 31 77 0e       	call   0xe77:0x31bf
     e09:	c9                   	leave
     e0a:	ca 04 00             	retf   0x4
     e0d:	11 4d 6f             	adc    WORD PTR [di+0x6f],cx
     e10:	64 65 41             	fs gs inc cx
     e13:	6d                   	ins    WORD PTR es:[di],dx
     e14:	6f                   	outs   dx,WORD PTR ds:[si]
     e15:	72 74                	jb     0xe8b
     e17:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     e1c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     e1e:	74 00                	je     0xe20
     e20:	80 ff ff             	cmp    bh,0xff
     e23:	ff                   	(bad)
     e24:	7f 00                	jg     0xe26
     e26:	00 08                	add    BYTE PTR [bx+si],cl
     e28:	4c                   	dec    sp
     e29:	69 6e e9 61 69       	imul   bp,WORD PTR [bp-0x17],0x6961
     e2e:	72 65                	jb     0xe95
     e30:	09 44 e9             	or     WORD PTR [si-0x17],ax
     e33:	67 72 65             	addr32 jb 0xe9b
     e36:	73 73                	jae    0xeab
     e38:	69 66 0d 49 46       	imul   sp,WORD PTR [bp+0xd],0x4649
     e3d:	41                   	inc    cx
     e3e:	4e                   	dec    si
     e3f:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
     e42:	61                   	popa
     e43:	6e                   	outs   dx,BYTE PTR ds:[si]
     e44:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     e47:	73 10                	jae    0xe59
     e49:	44                   	inc    sp
     e4a:	65 6d                	gs ins WORD PTR es:[di],dx
     e4c:	61                   	popa
     e4d:	6e                   	outs   dx,BYTE PTR ds:[si]
     e4e:	64 65 45             	fs gs inc bp
     e51:	76 6f                	jbe    0xec2
     e53:	6c                   	ins    BYTE PTR es:[di],dx
     e54:	75 74                	jne    0xeca
     e56:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
     e5b:	00 00                	add    BYTE PTR [bx+si],al
     e5d:	02 00                	add    al,BYTE PTR [bx+si]
     e5f:	00 00                	add    BYTE PTR [bx+si],al
     e61:	11 46 61             	adc    WORD PTR [bp+0x61],ax
     e64:	63 74 65             	arpl   WORD PTR [si+0x65],si
     e67:	75 72                	jne    0xedb
     e69:	54                   	push   sp
     e6a:	65 6d                	gs ins WORD PTR es:[di],dx
     e6c:	70 73                	jo     0xee1
     e6e:	46                   	inc    si
     e6f:	61                   	popa
     e70:	62 50 63             	bound  dx,DWORD PTR [bx+si+0x63]
     e73:	01 00                	add    WORD PTR [bx+si],ax
     e75:	2f                   	das
     e76:	00 e2                	add    dl,ah
     e78:	0e                   	push   cs
     e79:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     e7a:	12 d3                	adc    dl,bl
     e7c:	0e                   	push   cs
     e7d:	55                   	push   bp
     e7e:	89 e5                	mov    bp,sp
     e80:	b8 12 01             	mov    ax,0x112
     e83:	9a 44 04 f7 0e       	call   0xef7:0x444
     e88:	81 ec 12 01          	sub    sp,0x112
     e8c:	b8 73 0e             	mov    ax,0xe73
     e8f:	0e                   	push   cs
     e90:	50                   	push   ax
     e91:	55                   	push   bp
     e92:	ff 36 58 18          	push   WORD PTR ds:0x1858
     e96:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     e9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e9d:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     ea2:	89 7e f2             	mov    WORD PTR [bp-0xe],di
     ea5:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
     ea8:	c7 46 ea 01 00       	mov    WORD PTR [bp-0x16],0x1
     ead:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
     eb2:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
     eb6:	8d 7e ea             	lea    di,[bp-0x16]
     eb9:	16                   	push   ss
     eba:	57                   	push   di
     ebb:	6a 00                	push   0x0
     ebd:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     ec0:	06                   	push   es
     ec1:	57                   	push   di
     ec2:	9a 95 28 cb 0f       	call   0xfcb:0x2895
     ec7:	08 c0                	or     al,al
     ec9:	75 0a                	jne    0xed5
     ecb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ece:	06                   	push   es
     ecf:	57                   	push   di
     ed0:	9a 4f 06 9e 0f       	call   0xf9e:0x64f
     ed5:	bf 0d 0e             	mov    di,0xe0d
     ed8:	0e                   	push   cs
     ed9:	57                   	push   di
     eda:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     edd:	06                   	push   es
     ede:	57                   	push   di
     edf:	9a 9b 3b 65 0f       	call   0xf65:0x3b9b
     ee4:	89 c7                	mov    di,ax
     ee6:	8e c2                	mov    es,dx
     ee8:	06                   	push   es
     ee9:	57                   	push   di
     eea:	26 c4 3d             	les    di,DWORD PTR es:[di]
     eed:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     ef1:	bf 1f 0e             	mov    di,0xe1f
     ef4:	9a 16 04 87 0f       	call   0xf87:0x416
     ef9:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     efc:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
     f00:	75 16                	jne    0xf18
     f02:	bf 27 0e             	mov    di,0xe27
     f05:	0e                   	push   cs
     f06:	57                   	push   di
     f07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f0a:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
     f0f:	06                   	push   es
     f10:	57                   	push   di
     f11:	9a 8c 1d 2a 0f       	call   0xf2a:0x1d8c
     f16:	eb 14                	jmp    0xf2c
     f18:	bf 30 0e             	mov    di,0xe30
     f1b:	0e                   	push   cs
     f1c:	57                   	push   di
     f1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f20:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
     f25:	06                   	push   es
     f26:	57                   	push   di
     f27:	9a 8c 1d 51 0f       	call   0xf51:0x1d8c
     f2c:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
     f31:	b0 00                	mov    al,0x0
     f33:	7c 01                	jl     0xf36
     f35:	40                   	inc    ax
     f36:	8a d0                	mov    dl,al
     f38:	83 7e f6 01          	cmp    WORD PTR [bp-0xa],0x1
     f3c:	b0 00                	mov    al,0x0
     f3e:	75 01                	jne    0xf41
     f40:	40                   	inc    ax
     f41:	22 c2                	and    al,dl
     f43:	50                   	push   ax
     f44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f47:	26 c4 bd 20 03       	les    di,DWORD PTR es:[di+0x320]
     f4c:	06                   	push   es
     f4d:	57                   	push   di
     f4e:	9a 77 1c 86 10       	call   0x1086:0x1c77
     f53:	bf 3a 0e             	mov    di,0xe3a
     f56:	0e                   	push   cs
     f57:	57                   	push   di
     f58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f5b:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     f60:	06                   	push   es
     f61:	57                   	push   di
     f62:	9a 43 3c e8 0f       	call   0xfe8:0x3c43
     f67:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     f6a:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     f6d:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     f70:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
     f73:	74 19                	je     0xf8e
     f75:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     f78:	06                   	push   es
     f79:	57                   	push   di
     f7a:	26 c4 3d             	les    di,DWORD PTR es:[di]
     f7d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     f81:	bf 1f 0e             	mov    di,0xe1f
     f84:	9a 16 04 fd 0f       	call   0xffd:0x416
     f89:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     f8c:	eb 05                	jmp    0xf93
     f8e:	c7 46 f8 08 00       	mov    WORD PTR [bp-0x8],0x8
     f93:	ff 76 f8             	push   WORD PTR [bp-0x8]
     f96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f99:	06                   	push   es
     f9a:	57                   	push   di
     f9b:	9a c9 12 d9 0f       	call   0xfd9:0x12c9
     fa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fa3:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
     fa8:	89 7e f2             	mov    WORD PTR [bp-0xe],di
     fab:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
     fae:	c7 46 ea 01 00       	mov    WORD PTR [bp-0x16],0x1
     fb3:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
     fb8:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
     fbc:	8d 7e ea             	lea    di,[bp-0x16]
     fbf:	16                   	push   ss
     fc0:	57                   	push   di
     fc1:	6a 00                	push   0x0
     fc3:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     fc6:	06                   	push   es
     fc7:	57                   	push   di
     fc8:	9a 95 28 49 11       	call   0x1149:0x2895
     fcd:	08 c0                	or     al,al
     fcf:	75 0a                	jne    0xfdb
     fd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd4:	06                   	push   es
     fd5:	57                   	push   di
     fd6:	9a 4f 06 57 11       	call   0x1157:0x64f
     fdb:	bf 48 0e             	mov    di,0xe48
     fde:	0e                   	push   cs
     fdf:	57                   	push   di
     fe0:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     fe3:	06                   	push   es
     fe4:	57                   	push   di
     fe5:	9a 9b 3b c6 10       	call   0x10c6:0x3b9b
     fea:	89 c7                	mov    di,ax
     fec:	8e c2                	mov    es,dx
     fee:	06                   	push   es
     fef:	57                   	push   di
     ff0:	26 c4 3d             	les    di,DWORD PTR es:[di]
     ff3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     ff7:	bf 1f 0e             	mov    di,0xe1f
     ffa:	9a 16 04 4b 10       	call   0x104b:0x416
     fff:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1002:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1005:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    100a:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    100d:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    1010:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1015:	06                   	push   es
    1016:	57                   	push   di
    1017:	26 c4 3d             	les    di,DWORD PTR es:[di]
    101a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    101e:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1021:	7e 0f                	jle    0x1032
    1023:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1026:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1029:	06                   	push   es
    102a:	57                   	push   di
    102b:	9a 2e 5c 56 10       	call   0x1056:0x5c2e
    1030:	eb 26                	jmp    0x1058
    1032:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1035:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    103a:	06                   	push   es
    103b:	57                   	push   di
    103c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    103f:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1043:	2d 01 00             	sub    ax,0x1
    1046:	71 05                	jno    0x104d
    1048:	9a 3e 04 69 10       	call   0x1069:0x43e
    104d:	50                   	push   ax
    104e:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1051:	06                   	push   es
    1052:	57                   	push   di
    1053:	9a 2e 5c 60 10       	call   0x1060:0x5c2e
    1058:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    105b:	06                   	push   es
    105c:	57                   	push   di
    105d:	9a 07 5c 96 10       	call   0x1096:0x5c07
    1062:	99                   	cwd
    1063:	bf 59 0e             	mov    di,0xe59
    1066:	9a 16 04 7b 11       	call   0x117b:0x416
    106b:	c1 e0 08             	shl    ax,0x8
    106e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1071:	03 f8                	add    di,ax
    1073:	81 c7 2c 03          	add    di,0x32c
    1077:	06                   	push   es
    1078:	57                   	push   di
    1079:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    107c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1081:	06                   	push   es
    1082:	57                   	push   di
    1083:	9a 8c 1d b7 10       	call   0x10b7:0x1d8c
    1088:	8d be ee fe          	lea    di,[bp-0x112]
    108c:	16                   	push   ss
    108d:	57                   	push   di
    108e:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1091:	06                   	push   es
    1092:	57                   	push   di
    1093:	9a 07 5c ac 11       	call   0x11ac:0x5c07
    1098:	50                   	push   ax
    1099:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    109c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    10a1:	06                   	push   es
    10a2:	57                   	push   di
    10a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10a6:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    10aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ad:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    10b2:	06                   	push   es
    10b3:	57                   	push   di
    10b4:	9a 8c 1d fc 10       	call   0x10fc:0x1d8c
    10b9:	bf 61 0e             	mov    di,0xe61
    10bc:	0e                   	push   cs
    10bd:	57                   	push   di
    10be:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    10c1:	06                   	push   es
    10c2:	57                   	push   di
    10c3:	9a 43 3c 66 11       	call   0x1166:0x3c43
    10c8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    10cb:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    10ce:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    10d1:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    10d4:	74 2a                	je     0x1100
    10d6:	8d be f2 fe          	lea    di,[bp-0x10e]
    10da:	16                   	push   ss
    10db:	57                   	push   di
    10dc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    10df:	06                   	push   es
    10e0:	57                   	push   di
    10e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10e4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    10e8:	52                   	push   dx
    10e9:	50                   	push   ax
    10ea:	9a a9 08 0d 11       	call   0x110d:0x8a9
    10ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10f2:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
    10f7:	06                   	push   es
    10f8:	57                   	push   di
    10f9:	9a 8c 1d 1c 11       	call   0x111c:0x1d8c
    10fe:	eb 1e                	jmp    0x111e
    1100:	8d be f2 fe          	lea    di,[bp-0x10e]
    1104:	16                   	push   ss
    1105:	57                   	push   di
    1106:	6a 00                	push   0x0
    1108:	6a 64                	push   0x64
    110a:	9a a9 08 6b 12       	call   0x126b:0x8a9
    110f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1112:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
    1117:	06                   	push   es
    1118:	57                   	push   di
    1119:	9a 8c 1d 04 12       	call   0x1204:0x1d8c
    111e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1121:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    1126:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1129:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    112c:	c7 46 ea 02 00       	mov    WORD PTR [bp-0x16],0x2
    1131:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    1136:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    113a:	8d 7e ea             	lea    di,[bp-0x16]
    113d:	16                   	push   ss
    113e:	57                   	push   di
    113f:	6a 00                	push   0x0
    1141:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1144:	06                   	push   es
    1145:	57                   	push   di
    1146:	9a 95 28 ff ff       	call   0xffff:0x2895
    114b:	08 c0                	or     al,al
    114d:	75 0a                	jne    0x1159
    114f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1152:	06                   	push   es
    1153:	57                   	push   di
    1154:	9a 4f 06 c3 12       	call   0x12c3:0x64f
    1159:	bf 48 0e             	mov    di,0xe48
    115c:	0e                   	push   cs
    115d:	57                   	push   di
    115e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1161:	06                   	push   es
    1162:	57                   	push   di
    1163:	9a 9b 3b 44 12       	call   0x1244:0x3b9b
    1168:	89 c7                	mov    di,ax
    116a:	8e c2                	mov    es,dx
    116c:	06                   	push   es
    116d:	57                   	push   di
    116e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1171:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1175:	bf 1f 0e             	mov    di,0xe1f
    1178:	9a 16 04 c9 11       	call   0x11c9:0x416
    117d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1180:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1183:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    1188:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    118b:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    118e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1193:	06                   	push   es
    1194:	57                   	push   di
    1195:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1198:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    119c:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    119f:	7e 0f                	jle    0x11b0
    11a1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    11a4:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    11a7:	06                   	push   es
    11a8:	57                   	push   di
    11a9:	9a 2e 5c d4 11       	call   0x11d4:0x5c2e
    11ae:	eb 26                	jmp    0x11d6
    11b0:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    11b3:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    11b8:	06                   	push   es
    11b9:	57                   	push   di
    11ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    11bd:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    11c1:	2d 01 00             	sub    ax,0x1
    11c4:	71 05                	jno    0x11cb
    11c6:	9a 3e 04 e7 11       	call   0x11e7:0x43e
    11cb:	50                   	push   ax
    11cc:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    11cf:	06                   	push   es
    11d0:	57                   	push   di
    11d1:	9a 2e 5c de 11       	call   0x11de:0x5c2e
    11d6:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    11d9:	06                   	push   es
    11da:	57                   	push   di
    11db:	9a 07 5c 14 12       	call   0x1214:0x5c07
    11e0:	99                   	cwd
    11e1:	bf 59 0e             	mov    di,0xe59
    11e4:	9a 16 04 b9 12       	call   0x12b9:0x416
    11e9:	c1 e0 08             	shl    ax,0x8
    11ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11ef:	03 f8                	add    di,ax
    11f1:	81 c7 2c 03          	add    di,0x32c
    11f5:	06                   	push   es
    11f6:	57                   	push   di
    11f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11fa:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    11ff:	06                   	push   es
    1200:	57                   	push   di
    1201:	9a 8c 1d 35 12       	call   0x1235:0x1d8c
    1206:	8d be ee fe          	lea    di,[bp-0x112]
    120a:	16                   	push   ss
    120b:	57                   	push   di
    120c:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    120f:	06                   	push   es
    1210:	57                   	push   di
    1211:	9a 07 5c 32 1a       	call   0x1a32:0x5c07
    1216:	50                   	push   ax
    1217:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    121a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    121f:	06                   	push   es
    1220:	57                   	push   di
    1221:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1224:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1228:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    122b:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    1230:	06                   	push   es
    1231:	57                   	push   di
    1232:	9a 8c 1d 7a 12       	call   0x127a:0x1d8c
    1237:	bf 61 0e             	mov    di,0xe61
    123a:	0e                   	push   cs
    123b:	57                   	push   di
    123c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    123f:	06                   	push   es
    1240:	57                   	push   di
    1241:	9a 43 3c ff ff       	call   0xffff:0x3c43
    1246:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1249:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    124c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    124f:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    1252:	74 2a                	je     0x127e
    1254:	8d be f2 fe          	lea    di,[bp-0x10e]
    1258:	16                   	push   ss
    1259:	57                   	push   di
    125a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    125d:	06                   	push   es
    125e:	57                   	push   di
    125f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1262:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1266:	52                   	push   dx
    1267:	50                   	push   ax
    1268:	9a a9 08 8b 12       	call   0x128b:0x8a9
    126d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1270:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    1275:	06                   	push   es
    1276:	57                   	push   di
    1277:	9a 8c 1d 9a 12       	call   0x129a:0x1d8c
    127c:	eb 1e                	jmp    0x129c
    127e:	8d be f2 fe          	lea    di,[bp-0x10e]
    1282:	16                   	push   ss
    1283:	57                   	push   di
    1284:	6a 00                	push   0x0
    1286:	6a 64                	push   0x64
    1288:	9a a9 08 ff ff       	call   0xffff:0x8a9
    128d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1290:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    1295:	06                   	push   es
    1296:	57                   	push   di
    1297:	9a 8c 1d ea 12       	call   0x12ea:0x1d8c
    129c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    12a0:	83 c4 06             	add    sp,0x6
    12a3:	eb 16                	jmp    0x12bb
    12a5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    12a8:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    12ab:	ff 76 f4             	push   WORD PTR [bp-0xc]
    12ae:	ff 76 f2             	push   WORD PTR [bp-0xe]
    12b1:	9a 2d 34 ff ff       	call   0xffff:0x342d
    12b6:	9a 34 14 d1 12       	call   0x12d1:0x1434
    12bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12be:	06                   	push   es
    12bf:	57                   	push   di
    12c0:	9a 93 0c a3 13       	call   0x13a3:0xc93
    12c5:	c9                   	leave
    12c6:	ca 04 00             	retf   0x4
    12c9:	55                   	push   bp
    12ca:	89 e5                	mov    bp,sp
    12cc:	31 c0                	xor    ax,ax
    12ce:	9a 44 04 ae 13       	call   0x13ae:0x444
    12d3:	83 7e 0a 0b          	cmp    WORD PTR [bp+0xa],0xb
    12d7:	b0 00                	mov    al,0x0
    12d9:	7c 01                	jl     0x12dc
    12db:	40                   	inc    ax
    12dc:	50                   	push   ax
    12dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e0:	26 c4 bd 10 03       	les    di,DWORD PTR es:[di+0x310]
    12e5:	06                   	push   es
    12e6:	57                   	push   di
    12e7:	9a 77 1c 03 13       	call   0x1303:0x1c77
    12ec:	83 7e 0a 0b          	cmp    WORD PTR [bp+0xa],0xb
    12f0:	b0 00                	mov    al,0x0
    12f2:	7c 01                	jl     0x12f5
    12f4:	40                   	inc    ax
    12f5:	50                   	push   ax
    12f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12f9:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    12fe:	06                   	push   es
    12ff:	57                   	push   di
    1300:	9a 77 1c 1c 13       	call   0x131c:0x1c77
    1305:	83 7e 0a 0a          	cmp    WORD PTR [bp+0xa],0xa
    1309:	b0 00                	mov    al,0x0
    130b:	7c 01                	jl     0x130e
    130d:	40                   	inc    ax
    130e:	50                   	push   ax
    130f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1312:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    1317:	06                   	push   es
    1318:	57                   	push   di
    1319:	9a 77 1c 35 13       	call   0x1335:0x1c77
    131e:	83 7e 0a 0a          	cmp    WORD PTR [bp+0xa],0xa
    1322:	b0 00                	mov    al,0x0
    1324:	7c 01                	jl     0x1327
    1326:	40                   	inc    ax
    1327:	50                   	push   ax
    1328:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    132b:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    1330:	06                   	push   es
    1331:	57                   	push   di
    1332:	9a 77 1c 4e 13       	call   0x134e:0x1c77
    1337:	83 7e 0a 09          	cmp    WORD PTR [bp+0xa],0x9
    133b:	b0 00                	mov    al,0x0
    133d:	7c 01                	jl     0x1340
    133f:	40                   	inc    ax
    1340:	50                   	push   ax
    1341:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1344:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
    1349:	06                   	push   es
    134a:	57                   	push   di
    134b:	9a 77 1c 67 13       	call   0x1367:0x1c77
    1350:	83 7e 0a 09          	cmp    WORD PTR [bp+0xa],0x9
    1354:	b0 00                	mov    al,0x0
    1356:	7c 01                	jl     0x1359
    1358:	40                   	inc    ax
    1359:	50                   	push   ax
    135a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    135d:	26 c4 bd 0c 03       	les    di,DWORD PTR es:[di+0x30c]
    1362:	06                   	push   es
    1363:	57                   	push   di
    1364:	9a 77 1c 80 13       	call   0x1380:0x1c77
    1369:	83 7e 0a 08          	cmp    WORD PTR [bp+0xa],0x8
    136d:	b0 00                	mov    al,0x0
    136f:	7c 01                	jl     0x1372
    1371:	40                   	inc    ax
    1372:	50                   	push   ax
    1373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1376:	26 c4 bd 90 02       	les    di,DWORD PTR es:[di+0x290]
    137b:	06                   	push   es
    137c:	57                   	push   di
    137d:	9a 77 1c 99 13       	call   0x1399:0x1c77
    1382:	83 7e 0a 08          	cmp    WORD PTR [bp+0xa],0x8
    1386:	b0 00                	mov    al,0x0
    1388:	7c 01                	jl     0x138b
    138a:	40                   	inc    ax
    138b:	50                   	push   ax
    138c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    138f:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    1394:	06                   	push   es
    1395:	57                   	push   di
    1396:	9a 77 1c 3c 14       	call   0x143c:0x1c77
    139b:	c9                   	leave
    139c:	ca 06 00             	retf   0x6
    139f:	00 00                	add    BYTE PTR [bx+si],al
    13a1:	c8 14 f8 13          	enter  0xf814,0x13
    13a5:	55                   	push   bp
    13a6:	89 e5                	mov    bp,sp
    13a8:	b8 0a 00             	mov    ax,0xa
    13ab:	9a 44 04 e6 14       	call   0x14e6:0x444
    13b0:	83 ec 0a             	sub    sp,0xa
    13b3:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    13b7:	06                   	push   es
    13b8:	57                   	push   di
    13b9:	9a 03 73 ff 13       	call   0x13ff:0x7303
    13be:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    13c2:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    13c6:	75 14                	jne    0x13dc
    13c8:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    13cc:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    13d2:	b0 00                	mov    al,0x0
    13d4:	75 01                	jne    0x13d7
    13d6:	40                   	inc    ax
    13d7:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    13da:	eb 04                	jmp    0x13e0
    13dc:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    13e0:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    13e4:	75 03                	jne    0x13e9
    13e6:	e9 ea 00             	jmp    0x14d3
    13e9:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    13ed:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    13f1:	b0 01                	mov    al,0x1
    13f3:	50                   	push   ax
    13f4:	b8 22 00             	mov    ax,0x22
    13f7:	ba 23 14             	mov    dx,0x1423
    13fa:	52                   	push   dx
    13fb:	50                   	push   ax
    13fc:	9a 53 25 4a 14       	call   0x144a:0x2553
    1401:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1404:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1407:	b8 9f 13             	mov    ax,0x139f
    140a:	0e                   	push   cs
    140b:	50                   	push   ax
    140c:	55                   	push   bp
    140d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1411:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1415:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1418:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    141b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    141e:	06                   	push   es
    141f:	57                   	push   di
    1420:	9a 56 0d 2d 14       	call   0x142d:0xd56
    1425:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1428:	06                   	push   es
    1429:	57                   	push   di
    142a:	9a 7d 0e 8f 14       	call   0x148f:0xe7d
    142f:	68 ff 00             	push   0xff
    1432:	6a ff                	push   0xffff
    1434:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1437:	06                   	push   es
    1438:	57                   	push   di
    1439:	9a d5 1e 6c 14       	call   0x146c:0x1ed5
    143e:	6a 00                	push   0x0
    1440:	6a 00                	push   0x0
    1442:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1445:	06                   	push   es
    1446:	57                   	push   di
    1447:	9a b2 36 56 14       	call   0x1456:0x36b2
    144c:	6a 02                	push   0x2
    144e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1451:	06                   	push   es
    1452:	57                   	push   di
    1453:	9a 14 3a 62 14       	call   0x1462:0x3a14
    1458:	6a 01                	push   0x1
    145a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    145d:	06                   	push   es
    145e:	57                   	push   di
    145f:	9a e5 34 7f 14       	call   0x147f:0x34e5
    1464:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1467:	06                   	push   es
    1468:	57                   	push   di
    1469:	9a b9 62 48 15       	call   0x1548:0x62b9
    146e:	50                   	push   ax
    146f:	6a 04                	push   0x4
    1471:	9a ff ff 00 00       	call   0x0:0xffff
    1476:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    147a:	06                   	push   es
    147b:	57                   	push   di
    147c:	9a 03 73 ba 14       	call   0x14ba:0x7303
    1481:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1485:	74 0c                	je     0x1493
    1487:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    148a:	06                   	push   es
    148b:	57                   	push   di
    148c:	9a dd 15 db 14       	call   0x14db:0x15dd
    1491:	eb 1e                	jmp    0x14b1
    1493:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1496:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1499:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    149c:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    14a1:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    14a6:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    14aa:	06                   	push   es
    14ab:	57                   	push   di
    14ac:	9a 1a 31 ff ff       	call   0xffff:0x311a
    14b1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    14b5:	06                   	push   es
    14b6:	57                   	push   di
    14b7:	9a 03 73 d0 14       	call   0x14d0:0x7303
    14bc:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    14c0:	83 c4 06             	add    sp,0x6
    14c3:	b8 d3 14             	mov    ax,0x14d3
    14c6:	0e                   	push   cs
    14c7:	50                   	push   ax
    14c8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14cb:	06                   	push   es
    14cc:	57                   	push   di
    14cd:	9a 1d 5f f4 14       	call   0x14f4:0x5f1d
    14d2:	cb                   	retf
    14d3:	c9                   	leave
    14d4:	ca 02 00             	retf   0x2
    14d7:	00 00                	add    BYTE PTR [bx+si],al
    14d9:	6c                   	ins    BYTE PTR es:[di],dx
    14da:	15 05 15             	adc    ax,0x1505
    14dd:	55                   	push   bp
    14de:	89 e5                	mov    bp,sp
    14e0:	b8 08 00             	mov    ax,0x8
    14e3:	9a 44 04 8a 15       	call   0x158a:0x444
    14e8:	83 ec 08             	sub    sp,0x8
    14eb:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    14ef:	06                   	push   es
    14f0:	57                   	push   di
    14f1:	9a 03 73 0c 15       	call   0x150c:0x7303
    14f6:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    14fa:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    14fe:	b0 01                	mov    al,0x1
    1500:	50                   	push   ax
    1501:	b8 22 00             	mov    ax,0x22
    1504:	ba 30 15             	mov    dx,0x1530
    1507:	52                   	push   dx
    1508:	50                   	push   ax
    1509:	9a 53 25 54 15       	call   0x1554:0x2553
    150e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1511:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1514:	b8 d7 14             	mov    ax,0x14d7
    1517:	0e                   	push   cs
    1518:	50                   	push   ax
    1519:	55                   	push   bp
    151a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    151e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1522:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1525:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1528:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    152b:	06                   	push   es
    152c:	57                   	push   di
    152d:	9a 56 0d 3a 15       	call   0x153a:0xd56
    1532:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1535:	06                   	push   es
    1536:	57                   	push   di
    1537:	9a 7d 0e db 15       	call   0x15db:0xe7d
    153c:	6a ff                	push   0xffff
    153e:	6a f0                	push   0xfff0
    1540:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1543:	06                   	push   es
    1544:	57                   	push   di
    1545:	9a d5 1e 38 18       	call   0x1838:0x1ed5
    154a:	6a 02                	push   0x2
    154c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    154f:	06                   	push   es
    1550:	57                   	push   di
    1551:	9a 14 3a 5e 15       	call   0x155e:0x3a14
    1556:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1559:	06                   	push   es
    155a:	57                   	push   di
    155b:	9a 45 5d 74 15       	call   0x1574:0x5d45
    1560:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1564:	83 c4 06             	add    sp,0x6
    1567:	b8 77 15             	mov    ax,0x1577
    156a:	0e                   	push   cs
    156b:	50                   	push   ax
    156c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    156f:	06                   	push   es
    1570:	57                   	push   di
    1571:	9a 1d 5f ff ff       	call   0xffff:0x5f1d
    1576:	cb                   	retf
    1577:	c9                   	leave
    1578:	cb                   	retf
    1579:	00 00                	add    BYTE PTR [bx+si],al
    157b:	00 00                	add    BYTE PTR [bx+si],al
    157d:	ff                   	(bad)
    157e:	ff 00                	inc    WORD PTR [bx+si]
    1580:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1583:	e5 b8                	in     ax,0xb8
    1585:	22 00                	and    al,BYTE PTR [bx+si]
    1587:	9a 44 04 ba 15       	call   0x15ba:0x444
    158c:	83 ec 22             	sub    sp,0x22
    158f:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1593:	06                   	push   es
    1594:	57                   	push   di
    1595:	9a 04 2a 01 16       	call   0x1601:0x2a04
    159a:	89 c7                	mov    di,ax
    159c:	8e c2                	mov    es,dx
    159e:	06                   	push   es
    159f:	57                   	push   di
    15a0:	9a d2 21 52 16       	call   0x1652:0x21d2
    15a5:	50                   	push   ax
    15a6:	8d 7e de             	lea    di,[bp-0x22]
    15a9:	16                   	push   ss
    15aa:	57                   	push   di
    15ab:	9a ff ff 00 00       	call   0x0:0xffff
    15b0:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    15b3:	99                   	cwd
    15b4:	bf 79 15             	mov    di,0x1579
    15b7:	9a 16 04 e6 15       	call   0x15e6:0x416
    15bc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    15bf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    15c2:	c9                   	leave
    15c3:	ca 02 00             	retf   0x2
    15c6:	00 01                	add    BYTE PTR [bx+di],al
    15c8:	09 01                	or     WORD PTR [bx+di],ax
    15ca:	20 03                	and    BYTE PTR [bp+di],al
    15cc:	20 20                	and    BYTE PTR [bx+si],ah
    15ce:	20 00                	and    BYTE PTR [bx+si],al
    15d0:	80 ff ff             	cmp    bh,0xff
    15d3:	ff                   	(bad)
    15d4:	7f 00                	jg     0x15d6
    15d6:	00 00                	add    BYTE PTR [bx+si],al
    15d8:	00 15                	add    BYTE PTR [di],dl
    15da:	1a f6                	sbb    dh,dh
    15dc:	15 55 89             	adc    ax,0x8955
    15df:	e5 b8                	in     ax,0xb8
    15e1:	0e                   	push   cs
    15e2:	04 9a                	add    al,0x9a
    15e4:	44                   	inc    sp
    15e5:	04 0c                	add    al,0xc
    15e7:	16                   	push   ss
    15e8:	81 ec 0e 04          	sub    sp,0x40e
    15ec:	6a 01                	push   0x1
    15ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15f1:	06                   	push   es
    15f2:	57                   	push   di
    15f3:	9a 9e 1d fb 17       	call   0x17fb:0x1d9e
    15f8:	8d be fc fe          	lea    di,[bp-0x104]
    15fc:	16                   	push   ss
    15fd:	57                   	push   di
    15fe:	9a 4e 20 2a 16       	call   0x162a:0x204e
    1603:	8d be fc fe          	lea    di,[bp-0x104]
    1607:	16                   	push   ss
    1608:	57                   	push   di
    1609:	9a f5 09 11 16       	call   0x1611:0x9f5
    160e:	9a 08 04 a6 16       	call   0x16a6:0x408
    1613:	b8 d7 15             	mov    ax,0x15d7
    1616:	0e                   	push   cs
    1617:	50                   	push   ax
    1618:	55                   	push   bp
    1619:	ff 36 58 18          	push   WORD PTR ds:0x1858
    161d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1621:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1625:	06                   	push   es
    1626:	57                   	push   di
    1627:	9a 04 2a 5f 16       	call   0x165f:0x2a04
    162c:	89 c7                	mov    di,ax
    162e:	8e c2                	mov    es,dx
    1630:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    1634:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    1638:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    163c:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    1641:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1645:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1649:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    164d:	06                   	push   es
    164e:	57                   	push   di
    164f:	9a 99 20 6e 16       	call   0x166e:0x2099
    1654:	6a 0a                	push   0xa
    1656:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    165a:	06                   	push   es
    165b:	57                   	push   di
    165c:	9a 04 2a 7b 16       	call   0x167b:0x2a04
    1661:	89 c7                	mov    di,ax
    1663:	8e c2                	mov    es,dx
    1665:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1669:	06                   	push   es
    166a:	57                   	push   di
    166b:	9a f5 11 8a 16       	call   0x168a:0x11f5
    1670:	6a 02                	push   0x2
    1672:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1676:	06                   	push   es
    1677:	57                   	push   di
    1678:	9a 04 2a ca 17       	call   0x17ca:0x2a04
    167d:	89 c7                	mov    di,ax
    167f:	8e c2                	mov    es,dx
    1681:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1685:	06                   	push   es
    1686:	57                   	push   di
    1687:	9a 78 12 d9 17       	call   0x17d9:0x1278
    168c:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    1691:	eb 03                	jmp    0x1696
    1693:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1696:	8d be fc fe          	lea    di,[bp-0x104]
    169a:	16                   	push   ss
    169b:	57                   	push   di
    169c:	bf c6 15             	mov    di,0x15c6
    169f:	0e                   	push   cs
    16a0:	57                   	push   di
    16a1:	6a 00                	push   0x0
    16a3:	9a b5 0d ab 16       	call   0x16ab:0xdb5
    16a8:	9a 78 0c b0 16       	call   0x16b0:0xc78
    16ad:	9a 08 04 de 16       	call   0x16de:0x408
    16b2:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    16b6:	75 db                	jne    0x1693
    16b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16bb:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    16c0:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    16c4:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    16c8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    16cd:	06                   	push   es
    16ce:	57                   	push   di
    16cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16d2:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    16d6:	2d 01 00             	sub    ax,0x1
    16d9:	71 05                	jno    0x16e0
    16db:	9a 3e 04 1e 17       	call   0x171e:0x43e
    16e0:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    16e4:	31 c0                	xor    ax,ax
    16e6:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    16ea:	7e 03                	jle    0x16ef
    16ec:	e9 c8 00             	jmp    0x17b7
    16ef:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    16f2:	eb 03                	jmp    0x16f7
    16f4:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    16f7:	8d be f0 fc          	lea    di,[bp-0x310]
    16fb:	16                   	push   ss
    16fc:	57                   	push   di
    16fd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1700:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1704:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1709:	06                   	push   es
    170a:	57                   	push   di
    170b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    170e:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1712:	8d be fc fd          	lea    di,[bp-0x204]
    1716:	16                   	push   ss
    1717:	57                   	push   di
    1718:	68 ff 00             	push   0xff
    171b:	9a e7 17 2e 17       	call   0x172e:0x17e7
    1720:	bf c7 15             	mov    di,0x15c7
    1723:	0e                   	push   cs
    1724:	57                   	push   di
    1725:	8d be fc fd          	lea    di,[bp-0x204]
    1729:	16                   	push   ss
    172a:	57                   	push   di
    172b:	9a 78 18 47 17       	call   0x1747:0x1878
    1730:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1733:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1737:	7e 26                	jle    0x175f
    1739:	8d be fc fd          	lea    di,[bp-0x204]
    173d:	16                   	push   ss
    173e:	57                   	push   di
    173f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1742:	6a 01                	push   0x1
    1744:	9a 75 19 5d 17       	call   0x175d:0x1975
    1749:	bf c9 15             	mov    di,0x15c9
    174c:	0e                   	push   cs
    174d:	57                   	push   di
    174e:	8d be fc fd          	lea    di,[bp-0x204]
    1752:	16                   	push   ss
    1753:	57                   	push   di
    1754:	68 ff 00             	push   0xff
    1757:	ff 76 fc             	push   WORD PTR [bp-0x4]
    175a:	9a 16 19 73 17       	call   0x1773:0x1916
    175f:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1763:	75 bb                	jne    0x1720
    1765:	8d be f0 fc          	lea    di,[bp-0x310]
    1769:	16                   	push   ss
    176a:	57                   	push   di
    176b:	bf cb 15             	mov    di,0x15cb
    176e:	0e                   	push   cs
    176f:	57                   	push   di
    1770:	9a cd 17 7e 17       	call   0x177e:0x17cd
    1775:	8d be fc fd          	lea    di,[bp-0x204]
    1779:	16                   	push   ss
    177a:	57                   	push   di
    177b:	9a 4c 18 8c 17       	call   0x178c:0x184c
    1780:	8d be fc fd          	lea    di,[bp-0x204]
    1784:	16                   	push   ss
    1785:	57                   	push   di
    1786:	68 ff 00             	push   0xff
    1789:	9a e7 17 9f 17       	call   0x179f:0x17e7
    178e:	8d be fc fe          	lea    di,[bp-0x104]
    1792:	16                   	push   ss
    1793:	57                   	push   di
    1794:	8d be fc fd          	lea    di,[bp-0x204]
    1798:	16                   	push   ss
    1799:	57                   	push   di
    179a:	6a 00                	push   0x0
    179c:	9a b5 0d a4 17       	call   0x17a4:0xdb5
    17a1:	9a 78 0c a9 17       	call   0x17a9:0xc78
    17a6:	9a 08 04 05 18       	call   0x1805:0x408
    17ab:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    17ae:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    17b2:	74 03                	je     0x17b7
    17b4:	e9 3d ff             	jmp    0x16f4
    17b7:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    17bb:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    17bf:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    17c3:	6a 06                	push   0x6
    17c5:	06                   	push   es
    17c6:	57                   	push   di
    17c7:	9a 04 2a e6 17       	call   0x17e6:0x2a04
    17cc:	89 c7                	mov    di,ax
    17ce:	8e c2                	mov    es,dx
    17d0:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    17d4:	06                   	push   es
    17d5:	57                   	push   di
    17d6:	9a f5 11 f5 17       	call   0x17f5:0x11f5
    17db:	6a 00                	push   0x0
    17dd:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    17e1:	06                   	push   es
    17e2:	57                   	push   di
    17e3:	9a 04 2a 69 18       	call   0x1869:0x2a04
    17e8:	89 c7                	mov    di,ax
    17ea:	8e c2                	mov    es,dx
    17ec:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    17f0:	06                   	push   es
    17f1:	57                   	push   di
    17f2:	9a 78 12 90 18       	call   0x1890:0x1278
    17f7:	55                   	push   bp
    17f8:	9a 81 15 e7 1d       	call   0x1de7:0x1581
    17fd:	05 02 00             	add    ax,0x2
    1800:	73 05                	jae    0x1807
    1802:	9a 3e 04 0f 18       	call   0x180f:0x43e
    1807:	31 d2                	xor    dx,dx
    1809:	bf cf 15             	mov    di,0x15cf
    180c:	9a 16 04 23 18       	call   0x1823:0x416
    1811:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    1815:	8d be f2 fb          	lea    di,[bp-0x40e]
    1819:	16                   	push   ss
    181a:	57                   	push   di
    181b:	bf cb 15             	mov    di,0x15cb
    181e:	0e                   	push   cs
    181f:	57                   	push   di
    1820:	9a cd 17 3d 18       	call   0x183d:0x17cd
    1825:	8d be f2 fc          	lea    di,[bp-0x30e]
    1829:	16                   	push   ss
    182a:	57                   	push   di
    182b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    182e:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
    1833:	06                   	push   es
    1834:	57                   	push   di
    1835:	9a 53 1d b5 18       	call   0x18b5:0x1d53
    183a:	9a 4c 18 4b 18       	call   0x184b:0x184c
    183f:	8d be fc fd          	lea    di,[bp-0x204]
    1843:	16                   	push   ss
    1844:	57                   	push   di
    1845:	68 ff 00             	push   0xff
    1848:	9a e7 17 5d 18       	call   0x185d:0x17e7
    184d:	6a 00                	push   0x0
    184f:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    1853:	b9 05 00             	mov    cx,0x5
    1856:	f7 e9                	imul   cx
    1858:	71 05                	jno    0x185f
    185a:	9a 3e 04 73 18       	call   0x1873:0x43e
    185f:	50                   	push   ax
    1860:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1864:	06                   	push   es
    1865:	57                   	push   di
    1866:	9a 72 2a 85 18       	call   0x1885:0x2a72
    186b:	5a                   	pop    dx
    186c:	2b c2                	sub    ax,dx
    186e:	71 05                	jno    0x1875
    1870:	9a 3e 04 a0 18       	call   0x18a0:0x43e
    1875:	50                   	push   ax
    1876:	8d be fc fd          	lea    di,[bp-0x204]
    187a:	16                   	push   ss
    187b:	57                   	push   di
    187c:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1880:	06                   	push   es
    1881:	57                   	push   di
    1882:	9a 04 2a e6 18       	call   0x18e6:0x2a04
    1887:	89 c7                	mov    di,ax
    1889:	8e c2                	mov    es,dx
    188b:	06                   	push   es
    188c:	57                   	push   di
    188d:	9a 09 1f 0d 19       	call   0x190d:0x1f09
    1892:	8d be f2 fb          	lea    di,[bp-0x40e]
    1896:	16                   	push   ss
    1897:	57                   	push   di
    1898:	bf cb 15             	mov    di,0x15cb
    189b:	0e                   	push   cs
    189c:	57                   	push   di
    189d:	9a cd 17 ba 18       	call   0x18ba:0x17cd
    18a2:	8d be f2 fc          	lea    di,[bp-0x30e]
    18a6:	16                   	push   ss
    18a7:	57                   	push   di
    18a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ab:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    18b0:	06                   	push   es
    18b1:	57                   	push   di
    18b2:	9a 53 1d 32 19       	call   0x1932:0x1d53
    18b7:	9a 4c 18 c8 18       	call   0x18c8:0x184c
    18bc:	8d be fc fd          	lea    di,[bp-0x204]
    18c0:	16                   	push   ss
    18c1:	57                   	push   di
    18c2:	68 ff 00             	push   0xff
    18c5:	9a e7 17 da 18       	call   0x18da:0x17e7
    18ca:	6a 00                	push   0x0
    18cc:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    18d0:	b9 04 00             	mov    cx,0x4
    18d3:	f7 e9                	imul   cx
    18d5:	71 05                	jno    0x18dc
    18d7:	9a 3e 04 f0 18       	call   0x18f0:0x43e
    18dc:	50                   	push   ax
    18dd:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    18e1:	06                   	push   es
    18e2:	57                   	push   di
    18e3:	9a 72 2a 02 19       	call   0x1902:0x2a72
    18e8:	5a                   	pop    dx
    18e9:	2b c2                	sub    ax,dx
    18eb:	71 05                	jno    0x18f2
    18ed:	9a 3e 04 1d 19       	call   0x191d:0x43e
    18f2:	50                   	push   ax
    18f3:	8d be fc fd          	lea    di,[bp-0x204]
    18f7:	16                   	push   ss
    18f8:	57                   	push   di
    18f9:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    18fd:	06                   	push   es
    18fe:	57                   	push   di
    18ff:	9a 04 2a 63 19       	call   0x1963:0x2a04
    1904:	89 c7                	mov    di,ax
    1906:	8e c2                	mov    es,dx
    1908:	06                   	push   es
    1909:	57                   	push   di
    190a:	9a 09 1f 8a 19       	call   0x198a:0x1f09
    190f:	8d be f2 fb          	lea    di,[bp-0x40e]
    1913:	16                   	push   ss
    1914:	57                   	push   di
    1915:	bf cb 15             	mov    di,0x15cb
    1918:	0e                   	push   cs
    1919:	57                   	push   di
    191a:	9a cd 17 37 19       	call   0x1937:0x17cd
    191f:	8d be f2 fc          	lea    di,[bp-0x30e]
    1923:	16                   	push   ss
    1924:	57                   	push   di
    1925:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1928:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    192d:	06                   	push   es
    192e:	57                   	push   di
    192f:	9a 53 1d af 19       	call   0x19af:0x1d53
    1934:	9a 4c 18 45 19       	call   0x1945:0x184c
    1939:	8d be fc fd          	lea    di,[bp-0x204]
    193d:	16                   	push   ss
    193e:	57                   	push   di
    193f:	68 ff 00             	push   0xff
    1942:	9a e7 17 57 19       	call   0x1957:0x17e7
    1947:	6a 00                	push   0x0
    1949:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    194d:	b9 03 00             	mov    cx,0x3
    1950:	f7 e9                	imul   cx
    1952:	71 05                	jno    0x1959
    1954:	9a 3e 04 6d 19       	call   0x196d:0x43e
    1959:	50                   	push   ax
    195a:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    195e:	06                   	push   es
    195f:	57                   	push   di
    1960:	9a 72 2a 7f 19       	call   0x197f:0x2a72
    1965:	5a                   	pop    dx
    1966:	2b c2                	sub    ax,dx
    1968:	71 05                	jno    0x196f
    196a:	9a 3e 04 9a 19       	call   0x199a:0x43e
    196f:	50                   	push   ax
    1970:	8d be fc fd          	lea    di,[bp-0x204]
    1974:	16                   	push   ss
    1975:	57                   	push   di
    1976:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    197a:	06                   	push   es
    197b:	57                   	push   di
    197c:	9a 04 2a e0 19       	call   0x19e0:0x2a04
    1981:	89 c7                	mov    di,ax
    1983:	8e c2                	mov    es,dx
    1985:	06                   	push   es
    1986:	57                   	push   di
    1987:	9a 09 1f 07 1a       	call   0x1a07:0x1f09
    198c:	8d be f2 fb          	lea    di,[bp-0x40e]
    1990:	16                   	push   ss
    1991:	57                   	push   di
    1992:	bf cb 15             	mov    di,0x15cb
    1995:	0e                   	push   cs
    1996:	57                   	push   di
    1997:	9a cd 17 b4 19       	call   0x19b4:0x17cd
    199c:	8d be f2 fc          	lea    di,[bp-0x30e]
    19a0:	16                   	push   ss
    19a1:	57                   	push   di
    19a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a5:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    19aa:	06                   	push   es
    19ab:	57                   	push   di
    19ac:	9a 53 1d 2a 1b       	call   0x1b2a:0x1d53
    19b1:	9a 4c 18 c2 19       	call   0x19c2:0x184c
    19b6:	8d be fc fd          	lea    di,[bp-0x204]
    19ba:	16                   	push   ss
    19bb:	57                   	push   di
    19bc:	68 ff 00             	push   0xff
    19bf:	9a e7 17 d4 19       	call   0x19d4:0x17e7
    19c4:	6a 00                	push   0x0
    19c6:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    19ca:	b9 02 00             	mov    cx,0x2
    19cd:	f7 e9                	imul   cx
    19cf:	71 05                	jno    0x19d6
    19d1:	9a 3e 04 ea 19       	call   0x19ea:0x43e
    19d6:	50                   	push   ax
    19d7:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    19db:	06                   	push   es
    19dc:	57                   	push   di
    19dd:	9a 72 2a fc 19       	call   0x19fc:0x2a72
    19e2:	5a                   	pop    dx
    19e3:	2b c2                	sub    ax,dx
    19e5:	71 05                	jno    0x19ec
    19e7:	9a 3e 04 1e 1a       	call   0x1a1e:0x43e
    19ec:	50                   	push   ax
    19ed:	8d be fc fd          	lea    di,[bp-0x204]
    19f1:	16                   	push   ss
    19f2:	57                   	push   di
    19f3:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    19f7:	06                   	push   es
    19f8:	57                   	push   di
    19f9:	9a 04 2a ff ff       	call   0xffff:0x2a04
    19fe:	89 c7                	mov    di,ax
    1a00:	8e c2                	mov    es,dx
    1a02:	06                   	push   es
    1a03:	57                   	push   di
    1a04:	9a 09 1f ff ff       	call   0xffff:0x1f09
    1a09:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1a0d:	83 c4 06             	add    sp,0x6
    1a10:	b8 35 1a             	mov    ax,0x1a35
    1a13:	0e                   	push   cs
    1a14:	50                   	push   ax
    1a15:	8d be fc fe          	lea    di,[bp-0x104]
    1a19:	16                   	push   ss
    1a1a:	57                   	push   di
    1a1b:	9a 4f 0a 23 1a       	call   0x1a23:0xa4f
    1a20:	9a 08 04 46 1a       	call   0x1a46:0x408
    1a25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a28:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    1a2d:	06                   	push   es
    1a2e:	57                   	push   di
    1a2f:	9a e3 49 ef 1a       	call   0x1aef:0x49e3
    1a34:	cb                   	retf
    1a35:	c9                   	leave
    1a36:	ca 04 00             	retf   0x4
    1a39:	01 09                	add    WORD PTR [bx+di],cx
    1a3b:	01 20                	add    WORD PTR [bx+si],sp
    1a3d:	55                   	push   bp
    1a3e:	89 e5                	mov    bp,sp
    1a40:	b8 06 02             	mov    ax,0x206
    1a43:	9a 44 04 81 1a       	call   0x1a81:0x444
    1a48:	81 ec 06 02          	sub    sp,0x206
    1a4c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1a4f:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1a54:	75 03                	jne    0x1a59
    1a56:	e9 3a 03             	jmp    0x1d93
    1a59:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1a5e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    1a61:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    1a65:	3d 00 00             	cmp    ax,0x0
    1a68:	75 32                	jne    0x1a9c
    1a6a:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1a6d:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1a71:	76 27                	jbe    0x1a9a
    1a73:	8d be fe fd          	lea    di,[bp-0x202]
    1a77:	16                   	push   ss
    1a78:	57                   	push   di
    1a79:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1a7c:	06                   	push   es
    1a7d:	57                   	push   di
    1a7e:	9a cd 17 8b 1a       	call   0x1a8b:0x17cd
    1a83:	bf 39 1a             	mov    di,0x1a39
    1a86:	0e                   	push   cs
    1a87:	57                   	push   di
    1a88:	9a 4c 18 98 1a       	call   0x1a98:0x184c
    1a8d:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1a90:	06                   	push   es
    1a91:	57                   	push   di
    1a92:	ff 76 10             	push   WORD PTR [bp+0x10]
    1a95:	9a e7 17 c8 1a       	call   0x1ac8:0x17e7
    1a9a:	eb 49                	jmp    0x1ae5
    1a9c:	3d 01 00             	cmp    ax,0x1
    1a9f:	75 44                	jne    0x1ae5
    1aa1:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1aa4:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1aa7:	30 e4                	xor    ah,ah
    1aa9:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1aad:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    1ab1:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    1ab4:	7d 2d                	jge    0x1ae3
    1ab6:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    1aba:	8d be fe fd          	lea    di,[bp-0x202]
    1abe:	16                   	push   ss
    1abf:	57                   	push   di
    1ac0:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1ac3:	06                   	push   es
    1ac4:	57                   	push   di
    1ac5:	9a cd 17 d2 1a       	call   0x1ad2:0x17cd
    1aca:	bf 3b 1a             	mov    di,0x1a3b
    1acd:	0e                   	push   cs
    1ace:	57                   	push   di
    1acf:	9a 4c 18 df 1a       	call   0x1adf:0x184c
    1ad4:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1ad7:	06                   	push   es
    1ad8:	57                   	push   di
    1ad9:	ff 76 10             	push   WORD PTR [bp+0x10]
    1adc:	9a e7 17 f6 1a       	call   0x1af6:0x17e7
    1ae1:	eb ca                	jmp    0x1aad
    1ae3:	eb 00                	jmp    0x1ae5
    1ae5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1ae8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1aeb:	bf 0c 01             	mov    di,0x10c
    1aee:	b8 06 1b             	mov    ax,0x1b06
    1af1:	50                   	push   ax
    1af2:	57                   	push   di
    1af3:	9a 55 22 0d 1b       	call   0x1b0d:0x2255
    1af8:	08 c0                	or     al,al
    1afa:	74 3e                	je     0x1b3a
    1afc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1aff:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b02:	bf 0c 01             	mov    di,0x10c
    1b05:	b8 99 1b             	mov    ax,0x1b99
    1b08:	50                   	push   ax
    1b09:	57                   	push   di
    1b0a:	9a 73 22 38 1b       	call   0x1b38:0x2273
    1b0f:	89 c7                	mov    di,ax
    1b11:	8e c2                	mov    es,dx
    1b13:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1b17:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1b1b:	8d be fa fd          	lea    di,[bp-0x206]
    1b1f:	16                   	push   ss
    1b20:	57                   	push   di
    1b21:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1b25:	06                   	push   es
    1b26:	57                   	push   di
    1b27:	9a 53 1d 7f 1b       	call   0x1b7f:0x1d53
    1b2c:	8d be 00 ff          	lea    di,[bp-0x100]
    1b30:	16                   	push   ss
    1b31:	57                   	push   di
    1b32:	68 ff 00             	push   0xff
    1b35:	9a e7 17 4b 1b       	call   0x1b4b:0x17e7
    1b3a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b3d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b40:	bf ad 0d             	mov    di,0xdad
    1b43:	b8 5b 1b             	mov    ax,0x1b5b
    1b46:	50                   	push   ax
    1b47:	57                   	push   di
    1b48:	9a 55 22 62 1b       	call   0x1b62:0x2255
    1b4d:	08 c0                	or     al,al
    1b4f:	74 3e                	je     0x1b8f
    1b51:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b54:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b57:	bf ad 0d             	mov    di,0xdad
    1b5a:	b8 ff ff             	mov    ax,0xffff
    1b5d:	50                   	push   ax
    1b5e:	57                   	push   di
    1b5f:	9a 73 22 8d 1b       	call   0x1b8d:0x2273
    1b64:	89 c7                	mov    di,ax
    1b66:	8e c2                	mov    es,dx
    1b68:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1b6c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1b70:	8d be fa fd          	lea    di,[bp-0x206]
    1b74:	16                   	push   ss
    1b75:	57                   	push   di
    1b76:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1b7a:	06                   	push   es
    1b7b:	57                   	push   di
    1b7c:	9a 53 1d d4 1b       	call   0x1bd4:0x1d53
    1b81:	8d be 00 ff          	lea    di,[bp-0x100]
    1b85:	16                   	push   ss
    1b86:	57                   	push   di
    1b87:	68 ff 00             	push   0xff
    1b8a:	9a e7 17 a0 1b       	call   0x1ba0:0x17e7
    1b8f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b92:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b95:	bf 17 06             	mov    di,0x617
    1b98:	b8 b0 1b             	mov    ax,0x1bb0
    1b9b:	50                   	push   ax
    1b9c:	57                   	push   di
    1b9d:	9a 55 22 b7 1b       	call   0x1bb7:0x2255
    1ba2:	08 c0                	or     al,al
    1ba4:	74 3e                	je     0x1be4
    1ba6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1ba9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bac:	bf 17 06             	mov    di,0x617
    1baf:	b8 ee 1b             	mov    ax,0x1bee
    1bb2:	50                   	push   ax
    1bb3:	57                   	push   di
    1bb4:	9a 73 22 e2 1b       	call   0x1be2:0x2273
    1bb9:	89 c7                	mov    di,ax
    1bbb:	8e c2                	mov    es,dx
    1bbd:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1bc1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1bc5:	8d be fa fd          	lea    di,[bp-0x206]
    1bc9:	16                   	push   ss
    1bca:	57                   	push   di
    1bcb:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1bcf:	06                   	push   es
    1bd0:	57                   	push   di
    1bd1:	9a 53 1d 29 1c       	call   0x1c29:0x1d53
    1bd6:	8d be 00 ff          	lea    di,[bp-0x100]
    1bda:	16                   	push   ss
    1bdb:	57                   	push   di
    1bdc:	68 ff 00             	push   0xff
    1bdf:	9a e7 17 f5 1b       	call   0x1bf5:0x17e7
    1be4:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1be7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bea:	bf 19 2c             	mov    di,0x2c19
    1bed:	b8 05 1c             	mov    ax,0x1c05
    1bf0:	50                   	push   ax
    1bf1:	57                   	push   di
    1bf2:	9a 55 22 0c 1c       	call   0x1c0c:0x2255
    1bf7:	08 c0                	or     al,al
    1bf9:	74 3e                	je     0x1c39
    1bfb:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1bfe:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c01:	bf 19 2c             	mov    di,0x2c19
    1c04:	b8 98 1c             	mov    ax,0x1c98
    1c07:	50                   	push   ax
    1c08:	57                   	push   di
    1c09:	9a 73 22 37 1c       	call   0x1c37:0x2273
    1c0e:	89 c7                	mov    di,ax
    1c10:	8e c2                	mov    es,dx
    1c12:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1c16:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1c1a:	8d be fa fd          	lea    di,[bp-0x206]
    1c1e:	16                   	push   ss
    1c1f:	57                   	push   di
    1c20:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1c24:	06                   	push   es
    1c25:	57                   	push   di
    1c26:	9a 53 1d d3 1c       	call   0x1cd3:0x1d53
    1c2b:	8d be 00 ff          	lea    di,[bp-0x100]
    1c2f:	16                   	push   ss
    1c30:	57                   	push   di
    1c31:	68 ff 00             	push   0xff
    1c34:	9a e7 17 4a 1c       	call   0x1c4a:0x17e7
    1c39:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c3c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c3f:	bf 22 00             	mov    di,0x22
    1c42:	b8 5a 1c             	mov    ax,0x1c5a
    1c45:	50                   	push   ax
    1c46:	57                   	push   di
    1c47:	9a 55 22 61 1c       	call   0x1c61:0x2255
    1c4c:	08 c0                	or     al,al
    1c4e:	74 3e                	je     0x1c8e
    1c50:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c53:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c56:	bf 22 00             	mov    di,0x22
    1c59:	b8 ff ff             	mov    ax,0xffff
    1c5c:	50                   	push   ax
    1c5d:	57                   	push   di
    1c5e:	9a 73 22 8c 1c       	call   0x1c8c:0x2273
    1c63:	89 c7                	mov    di,ax
    1c65:	8e c2                	mov    es,dx
    1c67:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1c6b:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1c6f:	8d be fa fd          	lea    di,[bp-0x206]
    1c73:	16                   	push   ss
    1c74:	57                   	push   di
    1c75:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1c79:	06                   	push   es
    1c7a:	57                   	push   di
    1c7b:	9a 24 15 ff ff       	call   0xffff:0x1524
    1c80:	8d be 00 ff          	lea    di,[bp-0x100]
    1c84:	16                   	push   ss
    1c85:	57                   	push   di
    1c86:	68 ff 00             	push   0xff
    1c89:	9a e7 17 9f 1c       	call   0x1c9f:0x17e7
    1c8e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c91:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c94:	bf 90 0b             	mov    di,0xb90
    1c97:	b8 af 1c             	mov    ax,0x1caf
    1c9a:	50                   	push   ax
    1c9b:	57                   	push   di
    1c9c:	9a 55 22 b6 1c       	call   0x1cb6:0x2255
    1ca1:	08 c0                	or     al,al
    1ca3:	74 3e                	je     0x1ce3
    1ca5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1ca8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cab:	bf 90 0b             	mov    di,0xb90
    1cae:	b8 c2 1d             	mov    ax,0x1dc2
    1cb1:	50                   	push   ax
    1cb2:	57                   	push   di
    1cb3:	9a 73 22 e1 1c       	call   0x1ce1:0x2273
    1cb8:	89 c7                	mov    di,ax
    1cba:	8e c2                	mov    es,dx
    1cbc:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1cc0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1cc4:	8d be fa fd          	lea    di,[bp-0x206]
    1cc8:	16                   	push   ss
    1cc9:	57                   	push   di
    1cca:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1cce:	06                   	push   es
    1ccf:	57                   	push   di
    1cd0:	9a 53 1d 17 1e       	call   0x1e17:0x1d53
    1cd5:	8d be 00 ff          	lea    di,[bp-0x100]
    1cd9:	16                   	push   ss
    1cda:	57                   	push   di
    1cdb:	68 ff 00             	push   0xff
    1cde:	9a e7 17 ea 1c       	call   0x1cea:0x17e7
    1ce3:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    1ce6:	50                   	push   ax
    1ce7:	9a f9 1e 19 1d       	call   0x1d19:0x1ef9
    1cec:	3c 47                	cmp    al,0x47
    1cee:	75 2f                	jne    0x1d1f
    1cf0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1cf5:	b0 00                	mov    al,0x0
    1cf7:	76 01                	jbe    0x1cfa
    1cf9:	40                   	inc    ax
    1cfa:	8a d0                	mov    dl,al
    1cfc:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    1d01:	b0 00                	mov    al,0x0
    1d03:	75 01                	jne    0x1d06
    1d05:	40                   	inc    ax
    1d06:	22 c2                	and    al,dl
    1d08:	08 c0                	or     al,al
    1d0a:	74 11                	je     0x1d1d
    1d0c:	8d be 00 ff          	lea    di,[bp-0x100]
    1d10:	16                   	push   ss
    1d11:	57                   	push   di
    1d12:	6a 01                	push   0x1
    1d14:	6a 01                	push   0x1
    1d16:	9a 75 19 46 1d       	call   0x1d46:0x1975
    1d1b:	eb d3                	jmp    0x1cf0
    1d1d:	eb 4c                	jmp    0x1d6b
    1d1f:	3c 44                	cmp    al,0x44
    1d21:	75 42                	jne    0x1d65
    1d23:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    1d27:	30 e4                	xor    ah,ah
    1d29:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1d2d:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    1d32:	7d 2f                	jge    0x1d63
    1d34:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    1d38:	8d be fe fd          	lea    di,[bp-0x202]
    1d3c:	16                   	push   ss
    1d3d:	57                   	push   di
    1d3e:	bf 3b 1a             	mov    di,0x1a3b
    1d41:	0e                   	push   cs
    1d42:	57                   	push   di
    1d43:	9a cd 17 51 1d       	call   0x1d51:0x17cd
    1d48:	8d be 00 ff          	lea    di,[bp-0x100]
    1d4c:	16                   	push   ss
    1d4d:	57                   	push   di
    1d4e:	9a 4c 18 5f 1d       	call   0x1d5f:0x184c
    1d53:	8d be 00 ff          	lea    di,[bp-0x100]
    1d57:	16                   	push   ss
    1d58:	57                   	push   di
    1d59:	68 ff 00             	push   0xff
    1d5c:	9a e7 17 79 1d       	call   0x1d79:0x17e7
    1d61:	eb ca                	jmp    0x1d2d
    1d63:	eb 06                	jmp    0x1d6b
    1d65:	3c 43                	cmp    al,0x43
    1d67:	75 02                	jne    0x1d6b
    1d69:	eb 00                	jmp    0x1d6b
    1d6b:	8d be fe fd          	lea    di,[bp-0x202]
    1d6f:	16                   	push   ss
    1d70:	57                   	push   di
    1d71:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1d74:	06                   	push   es
    1d75:	57                   	push   di
    1d76:	9a cd 17 84 1d       	call   0x1d84:0x17cd
    1d7b:	8d be 00 ff          	lea    di,[bp-0x100]
    1d7f:	16                   	push   ss
    1d80:	57                   	push   di
    1d81:	9a 4c 18 91 1d       	call   0x1d91:0x184c
    1d86:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1d89:	06                   	push   es
    1d8a:	57                   	push   di
    1d8b:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d8e:	9a e7 17 a7 1d       	call   0x1da7:0x17e7
    1d93:	c9                   	leave
    1d94:	ca 10 00             	retf   0x10
    1d97:	01 09                	add    WORD PTR [bx+di],cx
    1d99:	00 03                	add    BYTE PTR [bp+di],al
    1d9b:	20 2f                	and    BYTE PTR [bx],ch
    1d9d:	20 55 89             	and    BYTE PTR [di-0x77],dl
    1da0:	e5 b8                	in     ax,0xb8
    1da2:	04 05                	add    al,0x5
    1da4:	9a 44 04 f8 1d       	call   0x1df8:0x444
    1da9:	81 ec 04 05          	sub    sp,0x504
    1dad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db0:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    1db5:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    1db9:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    1dbd:	06                   	push   es
    1dbe:	57                   	push   di
    1dbf:	9a e3 49 ff ff       	call   0xffff:0x49e3
    1dc4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1dc9:	8d be 00 ff          	lea    di,[bp-0x100]
    1dcd:	16                   	push   ss
    1dce:	57                   	push   di
    1dcf:	68 ff 00             	push   0xff
    1dd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd5:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    1dda:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    1ddf:	6a 00                	push   0x0
    1de1:	6a 67                	push   0x67
    1de3:	55                   	push   bp
    1de4:	9a 3d 1a 84 1e       	call   0x1e84:0x1a3d
    1de9:	8d be fc fd          	lea    di,[bp-0x204]
    1ded:	16                   	push   ss
    1dee:	57                   	push   di
    1def:	8d be 00 ff          	lea    di,[bp-0x100]
    1df3:	16                   	push   ss
    1df4:	57                   	push   di
    1df5:	9a cd 17 02 1e       	call   0x1e02:0x17cd
    1dfa:	bf 97 1d             	mov    di,0x1d97
    1dfd:	0e                   	push   cs
    1dfe:	57                   	push   di
    1dff:	9a 4c 18 1c 1e       	call   0x1e1c:0x184c
    1e04:	8d be fc fc          	lea    di,[bp-0x304]
    1e08:	16                   	push   ss
    1e09:	57                   	push   di
    1e0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0d:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    1e12:	06                   	push   es
    1e13:	57                   	push   di
    1e14:	9a 53 1d 5d 25       	call   0x255d:0x1d53
    1e19:	9a 4c 18 2a 1e       	call   0x1e2a:0x184c
    1e1e:	8d be 00 ff          	lea    di,[bp-0x100]
    1e22:	16                   	push   ss
    1e23:	57                   	push   di
    1e24:	68 ff 00             	push   0xff
    1e27:	9a e7 17 77 25       	call   0x2577:0x17e7
    1e2c:	8d be 00 ff          	lea    di,[bp-0x100]
    1e30:	16                   	push   ss
    1e31:	57                   	push   di
    1e32:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1e36:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1e3b:	06                   	push   es
    1e3c:	57                   	push   di
    1e3d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e40:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1e44:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1e48:	75 17                	jne    0x1e61
    1e4a:	bf 99 1d             	mov    di,0x1d99
    1e4d:	0e                   	push   cs
    1e4e:	57                   	push   di
    1e4f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1e53:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1e58:	06                   	push   es
    1e59:	57                   	push   di
    1e5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e5d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1e61:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1e66:	8d be 00 ff          	lea    di,[bp-0x100]
    1e6a:	16                   	push   ss
    1e6b:	57                   	push   di
    1e6c:	68 ff 00             	push   0xff
    1e6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e72:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    1e77:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    1e7c:	6a 0a                	push   0xa
    1e7e:	6a 67                	push   0x67
    1e80:	55                   	push   bp
    1e81:	9a 3d 1a a4 1e       	call   0x1ea4:0x1a3d
    1e86:	8d be 00 ff          	lea    di,[bp-0x100]
    1e8a:	16                   	push   ss
    1e8b:	57                   	push   di
    1e8c:	68 ff 00             	push   0xff
    1e8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e92:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    1e97:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    1e9c:	6a 23                	push   0x23
    1e9e:	6a 67                	push   0x67
    1ea0:	55                   	push   bp
    1ea1:	9a 3d 1a 00 1f       	call   0x1f00:0x1a3d
    1ea6:	8d be 00 ff          	lea    di,[bp-0x100]
    1eaa:	16                   	push   ss
    1eab:	57                   	push   di
    1eac:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1eb0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1eb5:	06                   	push   es
    1eb6:	57                   	push   di
    1eb7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1eba:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1ebe:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1ec2:	75 17                	jne    0x1edb
    1ec4:	bf 99 1d             	mov    di,0x1d99
    1ec7:	0e                   	push   cs
    1ec8:	57                   	push   di
    1ec9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1ecd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1ed2:	06                   	push   es
    1ed3:	57                   	push   di
    1ed4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ed7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1edb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1ee0:	8d be 00 ff          	lea    di,[bp-0x100]
    1ee4:	16                   	push   ss
    1ee5:	57                   	push   di
    1ee6:	68 ff 00             	push   0xff
    1ee9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eec:	26 ff b5 4a 02       	push   WORD PTR es:[di+0x24a]
    1ef1:	26 ff b5 48 02       	push   WORD PTR es:[di+0x248]
    1ef6:	ff 36 92 04          	push   WORD PTR ds:0x492
    1efa:	6a 67                	push   0x67
    1efc:	55                   	push   bp
    1efd:	9a 3d 1a 46 1f       	call   0x1f46:0x1a3d
    1f02:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1f07:	76 18                	jbe    0x1f21
    1f09:	8d be 00 ff          	lea    di,[bp-0x100]
    1f0d:	16                   	push   ss
    1f0e:	57                   	push   di
    1f0f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1f13:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1f18:	06                   	push   es
    1f19:	57                   	push   di
    1f1a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f1d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1f21:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1f26:	8d be 00 ff          	lea    di,[bp-0x100]
    1f2a:	16                   	push   ss
    1f2b:	57                   	push   di
    1f2c:	68 ff 00             	push   0xff
    1f2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f32:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    1f37:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    1f3c:	ff 36 92 04          	push   WORD PTR ds:0x492
    1f40:	6a 67                	push   0x67
    1f42:	55                   	push   bp
    1f43:	9a 3d 1a 68 1f       	call   0x1f68:0x1a3d
    1f48:	8d be 00 ff          	lea    di,[bp-0x100]
    1f4c:	16                   	push   ss
    1f4d:	57                   	push   di
    1f4e:	68 ff 00             	push   0xff
    1f51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f54:	26 ff b5 0e 02       	push   WORD PTR es:[di+0x20e]
    1f59:	26 ff b5 0c 02       	push   WORD PTR es:[di+0x20c]
    1f5e:	ff 36 98 04          	push   WORD PTR ds:0x498
    1f62:	6a 64                	push   0x64
    1f64:	55                   	push   bp
    1f65:	9a 3d 1a cb 1f       	call   0x1fcb:0x1a3d
    1f6a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1f6f:	76 18                	jbe    0x1f89
    1f71:	8d be 00 ff          	lea    di,[bp-0x100]
    1f75:	16                   	push   ss
    1f76:	57                   	push   di
    1f77:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1f7b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1f80:	06                   	push   es
    1f81:	57                   	push   di
    1f82:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f85:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1f89:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1f8d:	75 17                	jne    0x1fa6
    1f8f:	bf 99 1d             	mov    di,0x1d99
    1f92:	0e                   	push   cs
    1f93:	57                   	push   di
    1f94:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1f98:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1f9d:	06                   	push   es
    1f9e:	57                   	push   di
    1f9f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fa2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1fa6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1fab:	8d be 00 ff          	lea    di,[bp-0x100]
    1faf:	16                   	push   ss
    1fb0:	57                   	push   di
    1fb1:	68 ff 00             	push   0xff
    1fb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb7:	26 ff b5 16 02       	push   WORD PTR es:[di+0x216]
    1fbc:	26 ff b5 14 02       	push   WORD PTR es:[di+0x214]
    1fc1:	ff 36 92 04          	push   WORD PTR ds:0x492
    1fc5:	6a 67                	push   0x67
    1fc7:	55                   	push   bp
    1fc8:	9a 3d 1a ed 1f       	call   0x1fed:0x1a3d
    1fcd:	8d be 00 ff          	lea    di,[bp-0x100]
    1fd1:	16                   	push   ss
    1fd2:	57                   	push   di
    1fd3:	68 ff 00             	push   0xff
    1fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd9:	26 ff b5 1e 02       	push   WORD PTR es:[di+0x21e]
    1fde:	26 ff b5 1c 02       	push   WORD PTR es:[di+0x21c]
    1fe3:	ff 36 98 04          	push   WORD PTR ds:0x498
    1fe7:	6a 64                	push   0x64
    1fe9:	55                   	push   bp
    1fea:	9a 3d 1a 33 20       	call   0x2033:0x1a3d
    1fef:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1ff4:	76 18                	jbe    0x200e
    1ff6:	8d be 00 ff          	lea    di,[bp-0x100]
    1ffa:	16                   	push   ss
    1ffb:	57                   	push   di
    1ffc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2000:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2005:	06                   	push   es
    2006:	57                   	push   di
    2007:	26 c4 3d             	les    di,DWORD PTR es:[di]
    200a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    200e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2013:	8d be 00 ff          	lea    di,[bp-0x100]
    2017:	16                   	push   ss
    2018:	57                   	push   di
    2019:	68 ff 00             	push   0xff
    201c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    201f:	26 ff b5 1a 02       	push   WORD PTR es:[di+0x21a]
    2024:	26 ff b5 18 02       	push   WORD PTR es:[di+0x218]
    2029:	ff 36 92 04          	push   WORD PTR ds:0x492
    202d:	6a 67                	push   0x67
    202f:	55                   	push   bp
    2030:	9a 3d 1a 55 20       	call   0x2055:0x1a3d
    2035:	8d be 00 ff          	lea    di,[bp-0x100]
    2039:	16                   	push   ss
    203a:	57                   	push   di
    203b:	68 ff 00             	push   0xff
    203e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2041:	26 ff b5 22 02       	push   WORD PTR es:[di+0x222]
    2046:	26 ff b5 20 02       	push   WORD PTR es:[di+0x220]
    204b:	ff 36 98 04          	push   WORD PTR ds:0x498
    204f:	6a 64                	push   0x64
    2051:	55                   	push   bp
    2052:	9a 3d 1a 9b 20       	call   0x209b:0x1a3d
    2057:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    205c:	76 18                	jbe    0x2076
    205e:	8d be 00 ff          	lea    di,[bp-0x100]
    2062:	16                   	push   ss
    2063:	57                   	push   di
    2064:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2068:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    206d:	06                   	push   es
    206e:	57                   	push   di
    206f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2072:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2076:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    207b:	8d be 00 ff          	lea    di,[bp-0x100]
    207f:	16                   	push   ss
    2080:	57                   	push   di
    2081:	68 ff 00             	push   0xff
    2084:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2087:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    208c:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    2091:	ff 36 92 04          	push   WORD PTR ds:0x492
    2095:	6a 67                	push   0x67
    2097:	55                   	push   bp
    2098:	9a 3d 1a bd 20       	call   0x20bd:0x1a3d
    209d:	8d be 00 ff          	lea    di,[bp-0x100]
    20a1:	16                   	push   ss
    20a2:	57                   	push   di
    20a3:	68 ff 00             	push   0xff
    20a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a9:	26 ff b5 1e 03       	push   WORD PTR es:[di+0x31e]
    20ae:	26 ff b5 1c 03       	push   WORD PTR es:[di+0x31c]
    20b3:	ff 36 98 04          	push   WORD PTR ds:0x498
    20b7:	6a 64                	push   0x64
    20b9:	55                   	push   bp
    20ba:	9a 3d 1a 03 21       	call   0x2103:0x1a3d
    20bf:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    20c4:	76 18                	jbe    0x20de
    20c6:	8d be 00 ff          	lea    di,[bp-0x100]
    20ca:	16                   	push   ss
    20cb:	57                   	push   di
    20cc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    20d0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    20d5:	06                   	push   es
    20d6:	57                   	push   di
    20d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20da:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    20de:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    20e3:	8d be 00 ff          	lea    di,[bp-0x100]
    20e7:	16                   	push   ss
    20e8:	57                   	push   di
    20e9:	68 ff 00             	push   0xff
    20ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ef:	26 ff b5 2a 02       	push   WORD PTR es:[di+0x22a]
    20f4:	26 ff b5 28 02       	push   WORD PTR es:[di+0x228]
    20f9:	ff 36 94 04          	push   WORD PTR ds:0x494
    20fd:	6a 67                	push   0x67
    20ff:	55                   	push   bp
    2100:	9a 3d 1a 25 21       	call   0x2125:0x1a3d
    2105:	8d be 00 ff          	lea    di,[bp-0x100]
    2109:	16                   	push   ss
    210a:	57                   	push   di
    210b:	68 ff 00             	push   0xff
    210e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2111:	26 ff b5 2e 02       	push   WORD PTR es:[di+0x22e]
    2116:	26 ff b5 2c 02       	push   WORD PTR es:[di+0x22c]
    211b:	ff 36 98 04          	push   WORD PTR ds:0x498
    211f:	6a 64                	push   0x64
    2121:	55                   	push   bp
    2122:	9a 3d 1a 7a 21       	call   0x217a:0x1a3d
    2127:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    212c:	76 18                	jbe    0x2146
    212e:	8d be 00 ff          	lea    di,[bp-0x100]
    2132:	16                   	push   ss
    2133:	57                   	push   di
    2134:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2138:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    213d:	06                   	push   es
    213e:	57                   	push   di
    213f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2142:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2146:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2149:	26 c4 bd 20 03       	les    di,DWORD PTR es:[di+0x320]
    214e:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2153:	74 68                	je     0x21bd
    2155:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    215a:	8d be 00 ff          	lea    di,[bp-0x100]
    215e:	16                   	push   ss
    215f:	57                   	push   di
    2160:	68 ff 00             	push   0xff
    2163:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2166:	26 ff b5 26 03       	push   WORD PTR es:[di+0x326]
    216b:	26 ff b5 24 03       	push   WORD PTR es:[di+0x324]
    2170:	ff 36 94 04          	push   WORD PTR ds:0x494
    2174:	6a 67                	push   0x67
    2176:	55                   	push   bp
    2177:	9a 3d 1a 9c 21       	call   0x219c:0x1a3d
    217c:	8d be 00 ff          	lea    di,[bp-0x100]
    2180:	16                   	push   ss
    2181:	57                   	push   di
    2182:	68 ff 00             	push   0xff
    2185:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2188:	26 ff b5 2a 03       	push   WORD PTR es:[di+0x32a]
    218d:	26 ff b5 28 03       	push   WORD PTR es:[di+0x328]
    2192:	ff 36 98 04          	push   WORD PTR ds:0x498
    2196:	6a 64                	push   0x64
    2198:	55                   	push   bp
    2199:	9a 3d 1a ec 21       	call   0x21ec:0x1a3d
    219e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    21a3:	76 18                	jbe    0x21bd
    21a5:	8d be 00 ff          	lea    di,[bp-0x100]
    21a9:	16                   	push   ss
    21aa:	57                   	push   di
    21ab:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    21af:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    21b4:	06                   	push   es
    21b5:	57                   	push   di
    21b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21b9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    21bd:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    21c2:	7f 03                	jg     0x21c7
    21c4:	e9 16 01             	jmp    0x22dd
    21c7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    21cc:	8d be 00 ff          	lea    di,[bp-0x100]
    21d0:	16                   	push   ss
    21d1:	57                   	push   di
    21d2:	68 ff 00             	push   0xff
    21d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d8:	26 ff b5 32 02       	push   WORD PTR es:[di+0x232]
    21dd:	26 ff b5 30 02       	push   WORD PTR es:[di+0x230]
    21e2:	ff 36 92 04          	push   WORD PTR ds:0x492
    21e6:	6a 67                	push   0x67
    21e8:	55                   	push   bp
    21e9:	9a 3d 1a 32 22       	call   0x2232:0x1a3d
    21ee:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    21f3:	76 18                	jbe    0x220d
    21f5:	8d be 00 ff          	lea    di,[bp-0x100]
    21f9:	16                   	push   ss
    21fa:	57                   	push   di
    21fb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    21ff:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2204:	06                   	push   es
    2205:	57                   	push   di
    2206:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2209:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    220d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2212:	8d be 00 ff          	lea    di,[bp-0x100]
    2216:	16                   	push   ss
    2217:	57                   	push   di
    2218:	68 ff 00             	push   0xff
    221b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    221e:	26 ff b5 36 02       	push   WORD PTR es:[di+0x236]
    2223:	26 ff b5 34 02       	push   WORD PTR es:[di+0x234]
    2228:	ff 36 94 04          	push   WORD PTR ds:0x494
    222c:	6a 67                	push   0x67
    222e:	55                   	push   bp
    222f:	9a 3d 1a 54 22       	call   0x2254:0x1a3d
    2234:	8d be 00 ff          	lea    di,[bp-0x100]
    2238:	16                   	push   ss
    2239:	57                   	push   di
    223a:	68 ff 00             	push   0xff
    223d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2240:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    2245:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    224a:	ff 36 98 04          	push   WORD PTR ds:0x498
    224e:	6a 64                	push   0x64
    2250:	55                   	push   bp
    2251:	9a 3d 1a 9a 22       	call   0x229a:0x1a3d
    2256:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    225b:	76 18                	jbe    0x2275
    225d:	8d be 00 ff          	lea    di,[bp-0x100]
    2261:	16                   	push   ss
    2262:	57                   	push   di
    2263:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2267:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    226c:	06                   	push   es
    226d:	57                   	push   di
    226e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2271:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2275:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    227a:	8d be 00 ff          	lea    di,[bp-0x100]
    227e:	16                   	push   ss
    227f:	57                   	push   di
    2280:	68 ff 00             	push   0xff
    2283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2286:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    228b:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    2290:	ff 36 94 04          	push   WORD PTR ds:0x494
    2294:	6a 67                	push   0x67
    2296:	55                   	push   bp
    2297:	9a 3d 1a bc 22       	call   0x22bc:0x1a3d
    229c:	8d be 00 ff          	lea    di,[bp-0x100]
    22a0:	16                   	push   ss
    22a1:	57                   	push   di
    22a2:	68 ff 00             	push   0xff
    22a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a8:	26 ff b5 42 02       	push   WORD PTR es:[di+0x242]
    22ad:	26 ff b5 40 02       	push   WORD PTR es:[di+0x240]
    22b2:	ff 36 98 04          	push   WORD PTR ds:0x498
    22b6:	6a 64                	push   0x64
    22b8:	55                   	push   bp
    22b9:	9a 3d 1a 1f 23       	call   0x231f:0x1a3d
    22be:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    22c3:	76 18                	jbe    0x22dd
    22c5:	8d be 00 ff          	lea    di,[bp-0x100]
    22c9:	16                   	push   ss
    22ca:	57                   	push   di
    22cb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    22cf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    22d4:	06                   	push   es
    22d5:	57                   	push   di
    22d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22d9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    22dd:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    22e1:	75 17                	jne    0x22fa
    22e3:	bf 99 1d             	mov    di,0x1d99
    22e6:	0e                   	push   cs
    22e7:	57                   	push   di
    22e8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    22ec:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    22f1:	06                   	push   es
    22f2:	57                   	push   di
    22f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22f6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    22fa:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    22ff:	8d be 00 ff          	lea    di,[bp-0x100]
    2303:	16                   	push   ss
    2304:	57                   	push   di
    2305:	68 ff 00             	push   0xff
    2308:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    230b:	26 ff b5 be 01       	push   WORD PTR es:[di+0x1be]
    2310:	26 ff b5 bc 01       	push   WORD PTR es:[di+0x1bc]
    2315:	ff 36 98 04          	push   WORD PTR ds:0x498
    2319:	6a 64                	push   0x64
    231b:	55                   	push   bp
    231c:	9a 3d 1a 48 23       	call   0x2348:0x1a3d
    2321:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    2326:	7e 22                	jle    0x234a
    2328:	8d be 00 ff          	lea    di,[bp-0x100]
    232c:	16                   	push   ss
    232d:	57                   	push   di
    232e:	68 ff 00             	push   0xff
    2331:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2334:	26 ff b5 ee 01       	push   WORD PTR es:[di+0x1ee]
    2339:	26 ff b5 ec 01       	push   WORD PTR es:[di+0x1ec]
    233e:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    2342:	6a 64                	push   0x64
    2344:	55                   	push   bp
    2345:	9a 3d 1a 8e 23       	call   0x238e:0x1a3d
    234a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    234f:	76 18                	jbe    0x2369
    2351:	8d be 00 ff          	lea    di,[bp-0x100]
    2355:	16                   	push   ss
    2356:	57                   	push   di
    2357:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    235b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2360:	06                   	push   es
    2361:	57                   	push   di
    2362:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2365:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2369:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    236e:	8d be 00 ff          	lea    di,[bp-0x100]
    2372:	16                   	push   ss
    2373:	57                   	push   di
    2374:	68 ff 00             	push   0xff
    2377:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    237a:	26 ff b5 c6 01       	push   WORD PTR es:[di+0x1c6]
    237f:	26 ff b5 c4 01       	push   WORD PTR es:[di+0x1c4]
    2384:	ff 36 92 04          	push   WORD PTR ds:0x492
    2388:	6a 67                	push   0x67
    238a:	55                   	push   bp
    238b:	9a 3d 1a b0 23       	call   0x23b0:0x1a3d
    2390:	8d be 00 ff          	lea    di,[bp-0x100]
    2394:	16                   	push   ss
    2395:	57                   	push   di
    2396:	68 ff 00             	push   0xff
    2399:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    239c:	26 ff b5 d2 01       	push   WORD PTR es:[di+0x1d2]
    23a1:	26 ff b5 d0 01       	push   WORD PTR es:[di+0x1d0]
    23a6:	ff 36 98 04          	push   WORD PTR ds:0x498
    23aa:	6a 64                	push   0x64
    23ac:	55                   	push   bp
    23ad:	9a 3d 1a d9 23       	call   0x23d9:0x1a3d
    23b2:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    23b7:	7e 22                	jle    0x23db
    23b9:	8d be 00 ff          	lea    di,[bp-0x100]
    23bd:	16                   	push   ss
    23be:	57                   	push   di
    23bf:	68 ff 00             	push   0xff
    23c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c5:	26 ff b5 f6 01       	push   WORD PTR es:[di+0x1f6]
    23ca:	26 ff b5 f4 01       	push   WORD PTR es:[di+0x1f4]
    23cf:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    23d3:	6a 64                	push   0x64
    23d5:	55                   	push   bp
    23d6:	9a 3d 1a 1f 24       	call   0x241f:0x1a3d
    23db:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    23e0:	76 18                	jbe    0x23fa
    23e2:	8d be 00 ff          	lea    di,[bp-0x100]
    23e6:	16                   	push   ss
    23e7:	57                   	push   di
    23e8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    23ec:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    23f1:	06                   	push   es
    23f2:	57                   	push   di
    23f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23f6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    23fa:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    23ff:	8d be 00 ff          	lea    di,[bp-0x100]
    2403:	16                   	push   ss
    2404:	57                   	push   di
    2405:	68 ff 00             	push   0xff
    2408:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240b:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    2410:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    2415:	ff 36 92 04          	push   WORD PTR ds:0x492
    2419:	6a 67                	push   0x67
    241b:	55                   	push   bp
    241c:	9a 3d 1a 41 24       	call   0x2441:0x1a3d
    2421:	8d be 00 ff          	lea    di,[bp-0x100]
    2425:	16                   	push   ss
    2426:	57                   	push   di
    2427:	68 ff 00             	push   0xff
    242a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242d:	26 ff b5 d6 01       	push   WORD PTR es:[di+0x1d6]
    2432:	26 ff b5 d4 01       	push   WORD PTR es:[di+0x1d4]
    2437:	ff 36 98 04          	push   WORD PTR ds:0x498
    243b:	6a 64                	push   0x64
    243d:	55                   	push   bp
    243e:	9a 3d 1a 6a 24       	call   0x246a:0x1a3d
    2443:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    2448:	7e 22                	jle    0x246c
    244a:	8d be 00 ff          	lea    di,[bp-0x100]
    244e:	16                   	push   ss
    244f:	57                   	push   di
    2450:	68 ff 00             	push   0xff
    2453:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2456:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    245b:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    2460:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    2464:	6a 64                	push   0x64
    2466:	55                   	push   bp
    2467:	9a 3d 1a b0 24       	call   0x24b0:0x1a3d
    246c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2471:	76 18                	jbe    0x248b
    2473:	8d be 00 ff          	lea    di,[bp-0x100]
    2477:	16                   	push   ss
    2478:	57                   	push   di
    2479:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    247d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2482:	06                   	push   es
    2483:	57                   	push   di
    2484:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2487:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    248b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2490:	8d be 00 ff          	lea    di,[bp-0x100]
    2494:	16                   	push   ss
    2495:	57                   	push   di
    2496:	68 ff 00             	push   0xff
    2499:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    249c:	26 ff b5 ce 01       	push   WORD PTR es:[di+0x1ce]
    24a1:	26 ff b5 cc 01       	push   WORD PTR es:[di+0x1cc]
    24a6:	ff 36 92 04          	push   WORD PTR ds:0x492
    24aa:	6a 67                	push   0x67
    24ac:	55                   	push   bp
    24ad:	9a 3d 1a d2 24       	call   0x24d2:0x1a3d
    24b2:	8d be 00 ff          	lea    di,[bp-0x100]
    24b6:	16                   	push   ss
    24b7:	57                   	push   di
    24b8:	68 ff 00             	push   0xff
    24bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24be:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    24c3:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    24c8:	ff 36 98 04          	push   WORD PTR ds:0x498
    24cc:	6a 64                	push   0x64
    24ce:	55                   	push   bp
    24cf:	9a 3d 1a fb 24       	call   0x24fb:0x1a3d
    24d4:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    24d9:	7e 22                	jle    0x24fd
    24db:	8d be 00 ff          	lea    di,[bp-0x100]
    24df:	16                   	push   ss
    24e0:	57                   	push   di
    24e1:	68 ff 00             	push   0xff
    24e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e7:	26 ff b5 fe 01       	push   WORD PTR es:[di+0x1fe]
    24ec:	26 ff b5 fc 01       	push   WORD PTR es:[di+0x1fc]
    24f1:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    24f5:	6a 64                	push   0x64
    24f7:	55                   	push   bp
    24f8:	9a 3d 1a 41 25       	call   0x2541:0x1a3d
    24fd:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2502:	76 18                	jbe    0x251c
    2504:	8d be 00 ff          	lea    di,[bp-0x100]
    2508:	16                   	push   ss
    2509:	57                   	push   di
    250a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    250e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2513:	06                   	push   es
    2514:	57                   	push   di
    2515:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2518:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    251c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2521:	8d be 00 ff          	lea    di,[bp-0x100]
    2525:	16                   	push   ss
    2526:	57                   	push   di
    2527:	68 ff 00             	push   0xff
    252a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    252d:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    2532:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    2537:	ff 36 94 04          	push   WORD PTR ds:0x494
    253b:	6a 67                	push   0x67
    253d:	55                   	push   bp
    253e:	9a 3d 1a de 25       	call   0x25de:0x1a3d
    2543:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    2548:	7e 74                	jle    0x25be
    254a:	8d be fc fd          	lea    di,[bp-0x204]
    254e:	16                   	push   ss
    254f:	57                   	push   di
    2550:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2553:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2558:	06                   	push   es
    2559:	57                   	push   di
    255a:	9a 53 1d 72 25       	call   0x2572:0x1d53
    255f:	8d be fc fc          	lea    di,[bp-0x304]
    2563:	16                   	push   ss
    2564:	57                   	push   di
    2565:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2568:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    256d:	06                   	push   es
    256e:	57                   	push   di
    256f:	9a 53 1d a9 25       	call   0x25a9:0x1d53
    2574:	9a be 18 8a 25       	call   0x258a:0x18be
    2579:	74 43                	je     0x25be
    257b:	8d be fc fb          	lea    di,[bp-0x404]
    257f:	16                   	push   ss
    2580:	57                   	push   di
    2581:	8d be 00 ff          	lea    di,[bp-0x100]
    2585:	16                   	push   ss
    2586:	57                   	push   di
    2587:	9a cd 17 94 25       	call   0x2594:0x17cd
    258c:	bf 9a 1d             	mov    di,0x1d9a
    258f:	0e                   	push   cs
    2590:	57                   	push   di
    2591:	9a 4c 18 ae 25       	call   0x25ae:0x184c
    2596:	8d be fc fa          	lea    di,[bp-0x504]
    259a:	16                   	push   ss
    259b:	57                   	push   di
    259c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259f:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    25a4:	06                   	push   es
    25a5:	57                   	push   di
    25a6:	9a 53 1d ff ff       	call   0xffff:0x1d53
    25ab:	9a 4c 18 bc 25       	call   0x25bc:0x184c
    25b0:	8d be 00 ff          	lea    di,[bp-0x100]
    25b4:	16                   	push   ss
    25b5:	57                   	push   di
    25b6:	68 ff 00             	push   0xff
    25b9:	9a e7 17 ff ff       	call   0xffff:0x17e7
    25be:	8d be 00 ff          	lea    di,[bp-0x100]
    25c2:	16                   	push   ss
    25c3:	57                   	push   di
    25c4:	68 ff 00             	push   0xff
    25c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ca:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    25cf:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    25d4:	ff 36 98 04          	push   WORD PTR ds:0x498
    25d8:	6a 64                	push   0x64
    25da:	55                   	push   bp
    25db:	9a 3d 1a 07 26       	call   0x2607:0x1a3d
    25e0:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    25e5:	7e 22                	jle    0x2609
    25e7:	8d be 00 ff          	lea    di,[bp-0x100]
    25eb:	16                   	push   ss
    25ec:	57                   	push   di
    25ed:	68 ff 00             	push   0xff
    25f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f3:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    25f8:	26 ff b5 00 02       	push   WORD PTR es:[di+0x200]
    25fd:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    2601:	6a 64                	push   0x64
    2603:	55                   	push   bp
    2604:	9a 3d 1a 74 26       	call   0x2674:0x1a3d
    2609:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    260e:	76 18                	jbe    0x2628
    2610:	8d be 00 ff          	lea    di,[bp-0x100]
    2614:	16                   	push   ss
    2615:	57                   	push   di
    2616:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    261a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    261f:	06                   	push   es
    2620:	57                   	push   di
    2621:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2624:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2628:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    262d:	74 03                	je     0x2632
    262f:	e9 21 05             	jmp    0x2b53
    2632:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2636:	75 17                	jne    0x264f
    2638:	bf 99 1d             	mov    di,0x1d99
    263b:	0e                   	push   cs
    263c:	57                   	push   di
    263d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2641:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2646:	06                   	push   es
    2647:	57                   	push   di
    2648:	26 c4 3d             	les    di,DWORD PTR es:[di]
    264b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    264f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2654:	8d be 00 ff          	lea    di,[bp-0x100]
    2658:	16                   	push   ss
    2659:	57                   	push   di
    265a:	68 ff 00             	push   0xff
    265d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2660:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    2665:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    266a:	ff 36 92 04          	push   WORD PTR ds:0x492
    266e:	6a 67                	push   0x67
    2670:	55                   	push   bp
    2671:	9a 3d 1a ba 26       	call   0x26ba:0x1a3d
    2676:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    267b:	76 18                	jbe    0x2695
    267d:	8d be 00 ff          	lea    di,[bp-0x100]
    2681:	16                   	push   ss
    2682:	57                   	push   di
    2683:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2687:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    268c:	06                   	push   es
    268d:	57                   	push   di
    268e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2691:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2695:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    269a:	8d be 00 ff          	lea    di,[bp-0x100]
    269e:	16                   	push   ss
    269f:	57                   	push   di
    26a0:	68 ff 00             	push   0xff
    26a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a6:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    26ab:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    26b0:	ff 36 94 04          	push   WORD PTR ds:0x494
    26b4:	6a 63                	push   0x63
    26b6:	55                   	push   bp
    26b7:	9a 3d 1a dc 26       	call   0x26dc:0x1a3d
    26bc:	8d be 00 ff          	lea    di,[bp-0x100]
    26c0:	16                   	push   ss
    26c1:	57                   	push   di
    26c2:	68 ff 00             	push   0xff
    26c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c8:	26 ff b5 b6 02       	push   WORD PTR es:[di+0x2b6]
    26cd:	26 ff b5 b4 02       	push   WORD PTR es:[di+0x2b4]
    26d2:	ff 36 98 04          	push   WORD PTR ds:0x498
    26d6:	6a 64                	push   0x64
    26d8:	55                   	push   bp
    26d9:	9a 3d 1a 22 27       	call   0x2722:0x1a3d
    26de:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    26e3:	76 18                	jbe    0x26fd
    26e5:	8d be 00 ff          	lea    di,[bp-0x100]
    26e9:	16                   	push   ss
    26ea:	57                   	push   di
    26eb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    26ef:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    26f4:	06                   	push   es
    26f5:	57                   	push   di
    26f6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26f9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    26fd:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2702:	8d be 00 ff          	lea    di,[bp-0x100]
    2706:	16                   	push   ss
    2707:	57                   	push   di
    2708:	68 ff 00             	push   0xff
    270b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    270e:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    2713:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    2718:	ff 36 94 04          	push   WORD PTR ds:0x494
    271c:	6a 64                	push   0x64
    271e:	55                   	push   bp
    271f:	9a 3d 1a 44 27       	call   0x2744:0x1a3d
    2724:	8d be 00 ff          	lea    di,[bp-0x100]
    2728:	16                   	push   ss
    2729:	57                   	push   di
    272a:	68 ff 00             	push   0xff
    272d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2730:	26 ff b5 b2 02       	push   WORD PTR es:[di+0x2b2]
    2735:	26 ff b5 b0 02       	push   WORD PTR es:[di+0x2b0]
    273a:	ff 36 98 04          	push   WORD PTR ds:0x498
    273e:	6a 64                	push   0x64
    2740:	55                   	push   bp
    2741:	9a 3d 1a 8a 27       	call   0x278a:0x1a3d
    2746:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    274b:	76 18                	jbe    0x2765
    274d:	8d be 00 ff          	lea    di,[bp-0x100]
    2751:	16                   	push   ss
    2752:	57                   	push   di
    2753:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2757:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    275c:	06                   	push   es
    275d:	57                   	push   di
    275e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2761:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2765:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    276a:	8d be 00 ff          	lea    di,[bp-0x100]
    276e:	16                   	push   ss
    276f:	57                   	push   di
    2770:	68 ff 00             	push   0xff
    2773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2776:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    277b:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    2780:	ff 36 94 04          	push   WORD PTR ds:0x494
    2784:	6a 64                	push   0x64
    2786:	55                   	push   bp
    2787:	9a 3d 1a ac 27       	call   0x27ac:0x1a3d
    278c:	8d be 00 ff          	lea    di,[bp-0x100]
    2790:	16                   	push   ss
    2791:	57                   	push   di
    2792:	68 ff 00             	push   0xff
    2795:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2798:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    279d:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    27a2:	ff 36 98 04          	push   WORD PTR ds:0x498
    27a6:	6a 64                	push   0x64
    27a8:	55                   	push   bp
    27a9:	9a 3d 1a f2 27       	call   0x27f2:0x1a3d
    27ae:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    27b3:	76 18                	jbe    0x27cd
    27b5:	8d be 00 ff          	lea    di,[bp-0x100]
    27b9:	16                   	push   ss
    27ba:	57                   	push   di
    27bb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    27bf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    27c4:	06                   	push   es
    27c5:	57                   	push   di
    27c6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27c9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    27cd:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    27d2:	8d be 00 ff          	lea    di,[bp-0x100]
    27d6:	16                   	push   ss
    27d7:	57                   	push   di
    27d8:	68 ff 00             	push   0xff
    27db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27de:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    27e3:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    27e8:	ff 36 94 04          	push   WORD PTR ds:0x494
    27ec:	6a 64                	push   0x64
    27ee:	55                   	push   bp
    27ef:	9a 3d 1a 14 28       	call   0x2814:0x1a3d
    27f4:	8d be 00 ff          	lea    di,[bp-0x100]
    27f8:	16                   	push   ss
    27f9:	57                   	push   di
    27fa:	68 ff 00             	push   0xff
    27fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2800:	26 ff b5 aa 02       	push   WORD PTR es:[di+0x2aa]
    2805:	26 ff b5 a8 02       	push   WORD PTR es:[di+0x2a8]
    280a:	ff 36 98 04          	push   WORD PTR ds:0x498
    280e:	6a 64                	push   0x64
    2810:	55                   	push   bp
    2811:	9a 3d 1a 5a 28       	call   0x285a:0x1a3d
    2816:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    281b:	76 18                	jbe    0x2835
    281d:	8d be 00 ff          	lea    di,[bp-0x100]
    2821:	16                   	push   ss
    2822:	57                   	push   di
    2823:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2827:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    282c:	06                   	push   es
    282d:	57                   	push   di
    282e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2831:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2835:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    283a:	8d be 00 ff          	lea    di,[bp-0x100]
    283e:	16                   	push   ss
    283f:	57                   	push   di
    2840:	68 ff 00             	push   0xff
    2843:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2846:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    284b:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    2850:	ff 36 94 04          	push   WORD PTR ds:0x494
    2854:	6a 64                	push   0x64
    2856:	55                   	push   bp
    2857:	9a 3d 1a 7c 28       	call   0x287c:0x1a3d
    285c:	8d be 00 ff          	lea    di,[bp-0x100]
    2860:	16                   	push   ss
    2861:	57                   	push   di
    2862:	68 ff 00             	push   0xff
    2865:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2868:	26 ff b5 a6 02       	push   WORD PTR es:[di+0x2a6]
    286d:	26 ff b5 a4 02       	push   WORD PTR es:[di+0x2a4]
    2872:	ff 36 98 04          	push   WORD PTR ds:0x498
    2876:	6a 64                	push   0x64
    2878:	55                   	push   bp
    2879:	9a 3d 1a c2 28       	call   0x28c2:0x1a3d
    287e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2883:	76 18                	jbe    0x289d
    2885:	8d be 00 ff          	lea    di,[bp-0x100]
    2889:	16                   	push   ss
    288a:	57                   	push   di
    288b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    288f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2894:	06                   	push   es
    2895:	57                   	push   di
    2896:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2899:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    289d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    28a2:	8d be 00 ff          	lea    di,[bp-0x100]
    28a6:	16                   	push   ss
    28a7:	57                   	push   di
    28a8:	68 ff 00             	push   0xff
    28ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ae:	26 ff b5 8a 02       	push   WORD PTR es:[di+0x28a]
    28b3:	26 ff b5 88 02       	push   WORD PTR es:[di+0x288]
    28b8:	ff 36 94 04          	push   WORD PTR ds:0x494
    28bc:	6a 64                	push   0x64
    28be:	55                   	push   bp
    28bf:	9a 3d 1a e4 28       	call   0x28e4:0x1a3d
    28c4:	8d be 00 ff          	lea    di,[bp-0x100]
    28c8:	16                   	push   ss
    28c9:	57                   	push   di
    28ca:	68 ff 00             	push   0xff
    28cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d0:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    28d5:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    28da:	ff 36 98 04          	push   WORD PTR ds:0x498
    28de:	6a 64                	push   0x64
    28e0:	55                   	push   bp
    28e1:	9a 3d 1a 2a 29       	call   0x292a:0x1a3d
    28e6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    28eb:	76 18                	jbe    0x2905
    28ed:	8d be 00 ff          	lea    di,[bp-0x100]
    28f1:	16                   	push   ss
    28f2:	57                   	push   di
    28f3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    28f7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    28fc:	06                   	push   es
    28fd:	57                   	push   di
    28fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2901:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2905:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    290a:	8d be 00 ff          	lea    di,[bp-0x100]
    290e:	16                   	push   ss
    290f:	57                   	push   di
    2910:	68 ff 00             	push   0xff
    2913:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2916:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    291b:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    2920:	ff 36 94 04          	push   WORD PTR ds:0x494
    2924:	6a 64                	push   0x64
    2926:	55                   	push   bp
    2927:	9a 3d 1a 4c 29       	call   0x294c:0x1a3d
    292c:	8d be 00 ff          	lea    di,[bp-0x100]
    2930:	16                   	push   ss
    2931:	57                   	push   di
    2932:	68 ff 00             	push   0xff
    2935:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2938:	26 ff b5 9e 02       	push   WORD PTR es:[di+0x29e]
    293d:	26 ff b5 9c 02       	push   WORD PTR es:[di+0x29c]
    2942:	ff 36 98 04          	push   WORD PTR ds:0x498
    2946:	6a 64                	push   0x64
    2948:	55                   	push   bp
    2949:	9a 3d 1a 92 29       	call   0x2992:0x1a3d
    294e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2953:	76 18                	jbe    0x296d
    2955:	8d be 00 ff          	lea    di,[bp-0x100]
    2959:	16                   	push   ss
    295a:	57                   	push   di
    295b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    295f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2964:	06                   	push   es
    2965:	57                   	push   di
    2966:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2969:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    296d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2972:	8d be 00 ff          	lea    di,[bp-0x100]
    2976:	16                   	push   ss
    2977:	57                   	push   di
    2978:	68 ff 00             	push   0xff
    297b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    297e:	26 ff b5 92 02       	push   WORD PTR es:[di+0x292]
    2983:	26 ff b5 90 02       	push   WORD PTR es:[di+0x290]
    2988:	ff 36 94 04          	push   WORD PTR ds:0x494
    298c:	6a 64                	push   0x64
    298e:	55                   	push   bp
    298f:	9a 3d 1a b4 29       	call   0x29b4:0x1a3d
    2994:	8d be 00 ff          	lea    di,[bp-0x100]
    2998:	16                   	push   ss
    2999:	57                   	push   di
    299a:	68 ff 00             	push   0xff
    299d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a0:	26 ff b5 9a 02       	push   WORD PTR es:[di+0x29a]
    29a5:	26 ff b5 98 02       	push   WORD PTR es:[di+0x298]
    29aa:	ff 36 98 04          	push   WORD PTR ds:0x498
    29ae:	6a 64                	push   0x64
    29b0:	55                   	push   bp
    29b1:	9a 3d 1a fa 29       	call   0x29fa:0x1a3d
    29b6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    29bb:	76 18                	jbe    0x29d5
    29bd:	8d be 00 ff          	lea    di,[bp-0x100]
    29c1:	16                   	push   ss
    29c2:	57                   	push   di
    29c3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    29c7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    29cc:	06                   	push   es
    29cd:	57                   	push   di
    29ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29d1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    29d5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    29da:	8d be 00 ff          	lea    di,[bp-0x100]
    29de:	16                   	push   ss
    29df:	57                   	push   di
    29e0:	68 ff 00             	push   0xff
    29e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e6:	26 ff b5 06 03       	push   WORD PTR es:[di+0x306]
    29eb:	26 ff b5 04 03       	push   WORD PTR es:[di+0x304]
    29f0:	ff 36 94 04          	push   WORD PTR ds:0x494
    29f4:	6a 64                	push   0x64
    29f6:	55                   	push   bp
    29f7:	9a 3d 1a 1c 2a       	call   0x2a1c:0x1a3d
    29fc:	8d be 00 ff          	lea    di,[bp-0x100]
    2a00:	16                   	push   ss
    2a01:	57                   	push   di
    2a02:	68 ff 00             	push   0xff
    2a05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a08:	26 ff b5 96 02       	push   WORD PTR es:[di+0x296]
    2a0d:	26 ff b5 94 02       	push   WORD PTR es:[di+0x294]
    2a12:	ff 36 98 04          	push   WORD PTR ds:0x498
    2a16:	6a 64                	push   0x64
    2a18:	55                   	push   bp
    2a19:	9a 3d 1a 62 2a       	call   0x2a62:0x1a3d
    2a1e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2a23:	76 18                	jbe    0x2a3d
    2a25:	8d be 00 ff          	lea    di,[bp-0x100]
    2a29:	16                   	push   ss
    2a2a:	57                   	push   di
    2a2b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2a2f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a34:	06                   	push   es
    2a35:	57                   	push   di
    2a36:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a39:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2a3d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2a42:	8d be 00 ff          	lea    di,[bp-0x100]
    2a46:	16                   	push   ss
    2a47:	57                   	push   di
    2a48:	68 ff 00             	push   0xff
    2a4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4e:	26 ff b5 0a 03       	push   WORD PTR es:[di+0x30a]
    2a53:	26 ff b5 08 03       	push   WORD PTR es:[di+0x308]
    2a58:	ff 36 94 04          	push   WORD PTR ds:0x494
    2a5c:	6a 64                	push   0x64
    2a5e:	55                   	push   bp
    2a5f:	9a 3d 1a 84 2a       	call   0x2a84:0x1a3d
    2a64:	8d be 00 ff          	lea    di,[bp-0x100]
    2a68:	16                   	push   ss
    2a69:	57                   	push   di
    2a6a:	68 ff 00             	push   0xff
    2a6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a70:	26 ff b5 0e 03       	push   WORD PTR es:[di+0x30e]
    2a75:	26 ff b5 0c 03       	push   WORD PTR es:[di+0x30c]
    2a7a:	ff 36 98 04          	push   WORD PTR ds:0x498
    2a7e:	6a 64                	push   0x64
    2a80:	55                   	push   bp
    2a81:	9a 3d 1a ca 2a       	call   0x2aca:0x1a3d
    2a86:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2a8b:	76 18                	jbe    0x2aa5
    2a8d:	8d be 00 ff          	lea    di,[bp-0x100]
    2a91:	16                   	push   ss
    2a92:	57                   	push   di
    2a93:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2a97:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a9c:	06                   	push   es
    2a9d:	57                   	push   di
    2a9e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2aa1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2aa5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2aaa:	8d be 00 ff          	lea    di,[bp-0x100]
    2aae:	16                   	push   ss
    2aaf:	57                   	push   di
    2ab0:	68 ff 00             	push   0xff
    2ab3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ab6:	26 ff b5 12 03       	push   WORD PTR es:[di+0x312]
    2abb:	26 ff b5 10 03       	push   WORD PTR es:[di+0x310]
    2ac0:	ff 36 94 04          	push   WORD PTR ds:0x494
    2ac4:	6a 64                	push   0x64
    2ac6:	55                   	push   bp
    2ac7:	9a 3d 1a ec 2a       	call   0x2aec:0x1a3d
    2acc:	8d be 00 ff          	lea    di,[bp-0x100]
    2ad0:	16                   	push   ss
    2ad1:	57                   	push   di
    2ad2:	68 ff 00             	push   0xff
    2ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad8:	26 ff b5 16 03       	push   WORD PTR es:[di+0x316]
    2add:	26 ff b5 14 03       	push   WORD PTR es:[di+0x314]
    2ae2:	ff 36 98 04          	push   WORD PTR ds:0x498
    2ae6:	6a 64                	push   0x64
    2ae8:	55                   	push   bp
    2ae9:	9a 3d 1a 32 2b       	call   0x2b32:0x1a3d
    2aee:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2af3:	76 18                	jbe    0x2b0d
    2af5:	8d be 00 ff          	lea    di,[bp-0x100]
    2af9:	16                   	push   ss
    2afa:	57                   	push   di
    2afb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2aff:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b04:	06                   	push   es
    2b05:	57                   	push   di
    2b06:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b09:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b0d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2b12:	8d be 00 ff          	lea    di,[bp-0x100]
    2b16:	16                   	push   ss
    2b17:	57                   	push   di
    2b18:	68 ff 00             	push   0xff
    2b1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b1e:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
    2b23:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    2b28:	ff 36 98 04          	push   WORD PTR ds:0x498
    2b2c:	6a 64                	push   0x64
    2b2e:	55                   	push   bp
    2b2f:	9a 3d 1a 9f 2b       	call   0x2b9f:0x1a3d
    2b34:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2b39:	76 18                	jbe    0x2b53
    2b3b:	8d be 00 ff          	lea    di,[bp-0x100]
    2b3f:	16                   	push   ss
    2b40:	57                   	push   di
    2b41:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2b45:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b4a:	06                   	push   es
    2b4b:	57                   	push   di
    2b4c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b4f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b53:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    2b58:	7d 03                	jge    0x2b5d
    2b5a:	e9 1d 01             	jmp    0x2c7a
    2b5d:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2b61:	75 17                	jne    0x2b7a
    2b63:	bf 99 1d             	mov    di,0x1d99
    2b66:	0e                   	push   cs
    2b67:	57                   	push   di
    2b68:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2b6c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b71:	06                   	push   es
    2b72:	57                   	push   di
    2b73:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b76:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b7a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2b7f:	8d be 00 ff          	lea    di,[bp-0x100]
    2b83:	16                   	push   ss
    2b84:	57                   	push   di
    2b85:	68 ff 00             	push   0xff
    2b88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b8b:	26 ff b5 e6 02       	push   WORD PTR es:[di+0x2e6]
    2b90:	26 ff b5 e4 02       	push   WORD PTR es:[di+0x2e4]
    2b95:	ff 36 98 04          	push   WORD PTR ds:0x498
    2b99:	6a 64                	push   0x64
    2b9b:	55                   	push   bp
    2b9c:	9a 3d 1a c8 2b       	call   0x2bc8:0x1a3d
    2ba1:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    2ba6:	7e 22                	jle    0x2bca
    2ba8:	8d be 00 ff          	lea    di,[bp-0x100]
    2bac:	16                   	push   ss
    2bad:	57                   	push   di
    2bae:	68 ff 00             	push   0xff
    2bb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb4:	26 ff b5 de 02       	push   WORD PTR es:[di+0x2de]
    2bb9:	26 ff b5 dc 02       	push   WORD PTR es:[di+0x2dc]
    2bbe:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    2bc2:	6a 64                	push   0x64
    2bc4:	55                   	push   bp
    2bc5:	9a 3d 1a 0e 2c       	call   0x2c0e:0x1a3d
    2bca:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2bcf:	76 18                	jbe    0x2be9
    2bd1:	8d be 00 ff          	lea    di,[bp-0x100]
    2bd5:	16                   	push   ss
    2bd6:	57                   	push   di
    2bd7:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2bdb:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2be0:	06                   	push   es
    2be1:	57                   	push   di
    2be2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2be5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2be9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2bee:	8d be 00 ff          	lea    di,[bp-0x100]
    2bf2:	16                   	push   ss
    2bf3:	57                   	push   di
    2bf4:	68 ff 00             	push   0xff
    2bf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bfa:	26 ff b5 ea 02       	push   WORD PTR es:[di+0x2ea]
    2bff:	26 ff b5 e8 02       	push   WORD PTR es:[di+0x2e8]
    2c04:	ff 36 92 04          	push   WORD PTR ds:0x492
    2c08:	6a 67                	push   0x67
    2c0a:	55                   	push   bp
    2c0b:	9a 3d 1a 30 2c       	call   0x2c30:0x1a3d
    2c10:	8d be 00 ff          	lea    di,[bp-0x100]
    2c14:	16                   	push   ss
    2c15:	57                   	push   di
    2c16:	68 ff 00             	push   0xff
    2c19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c1c:	26 ff b5 ee 02       	push   WORD PTR es:[di+0x2ee]
    2c21:	26 ff b5 ec 02       	push   WORD PTR es:[di+0x2ec]
    2c26:	ff 36 98 04          	push   WORD PTR ds:0x498
    2c2a:	6a 64                	push   0x64
    2c2c:	55                   	push   bp
    2c2d:	9a 3d 1a 59 2c       	call   0x2c59:0x1a3d
    2c32:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    2c37:	7e 22                	jle    0x2c5b
    2c39:	8d be 00 ff          	lea    di,[bp-0x100]
    2c3d:	16                   	push   ss
    2c3e:	57                   	push   di
    2c3f:	68 ff 00             	push   0xff
    2c42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c45:	26 ff b5 f2 02       	push   WORD PTR es:[di+0x2f2]
    2c4a:	26 ff b5 f0 02       	push   WORD PTR es:[di+0x2f0]
    2c4f:	ff 36 9a 04          	push   WORD PTR ds:0x49a
    2c53:	6a 64                	push   0x64
    2c55:	55                   	push   bp
    2c56:	9a 3d 1a ff ff       	call   0xffff:0x1a3d
    2c5b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2c60:	76 18                	jbe    0x2c7a
    2c62:	8d be 00 ff          	lea    di,[bp-0x100]
    2c66:	16                   	push   ss
    2c67:	57                   	push   di
    2c68:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2c6c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2c71:	06                   	push   es
    2c72:	57                   	push   di
    2c73:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c76:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2c7a:	c9                   	leave
    2c7b:	ca 06 00             	retf   0x6
    2c7e:	55                   	push   bp
    2c7f:	89 e5                	mov    bp,sp
    2c81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c84:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    2c88:	b7 00                	mov    bh,0x0
    2c8a:	8d 41 02             	lea    ax,[bx+di+0x2]
    2c8d:	8c c2                	mov    dx,es
    2c8f:	c9                   	leave
    2c90:	ca 04 00             	retf   0x4
    2c93:	55                   	push   bp
    2c94:	89 e5                	mov    bp,sp
    2c96:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2c99:	31 db                	xor    bx,bx
    2c9b:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    2c9f:	26 c4 79 0b          	les    di,DWORD PTR es:[bx+di+0xb]
    2ca3:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    2ca7:	8d 79 0f             	lea    di,[bx+di+0xf]
    2caa:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    2cad:	e3 08                	jcxz   0x2cb7
    2caf:	26 8a 1d             	mov    bl,BYTE PTR es:[di]
    2cb2:	8d 79 01             	lea    di,[bx+di+0x1]
    2cb5:	e2 f8                	loop   0x2caf
    2cb7:	89 f8                	mov    ax,di
    2cb9:	8c c2                	mov    dx,es
    2cbb:	c9                   	leave
    2cbc:	ca 06 00             	retf   0x6
    2cbf:	55                   	push   bp
    2cc0:	89 e5                	mov    bp,sp
    2cc2:	1e                   	push   ds
    2cc3:	fc                   	cld
    2cc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc7:	26 8a 25             	mov    ah,BYTE PTR es:[di]
    2cca:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2ccd:	31 db                	xor    bx,bx
    2ccf:	8a 5c 01             	mov    bl,BYTE PTR [si+0x1]
    2cd2:	c5 70 0b             	lds    si,DWORD PTR [bx+si+0xb]
    2cd5:	8a 5c 01             	mov    bl,BYTE PTR [si+0x1]
    2cd8:	8b 50 07             	mov    dx,WORD PTR [bx+si+0x7]
    2cdb:	8d 70 0f             	lea    si,[bx+si+0xf]
    2cde:	42                   	inc    dx
    2cdf:	52                   	push   dx
    2ce0:	8a 1c                	mov    bl,BYTE PTR [si]
    2ce2:	38 e3                	cmp    bl,ah
    2ce4:	74 0c                	je     0x2cf2
    2ce6:	8d 70 01             	lea    si,[bx+si+0x1]
    2ce9:	4a                   	dec    dx
    2cea:	75 f4                	jne    0x2ce0
    2cec:	58                   	pop    ax
    2ced:	b8 ff ff             	mov    ax,0xffff
    2cf0:	eb 1b                	jmp    0x2d0d
    2cf2:	57                   	push   di
    2cf3:	56                   	push   si
    2cf4:	88 e1                	mov    cl,ah
    2cf6:	b5 00                	mov    ch,0x0
    2cf8:	46                   	inc    si
    2cf9:	47                   	inc    di
    2cfa:	8a 04                	mov    al,BYTE PTR [si]
    2cfc:	26 32 05             	xor    al,BYTE PTR es:[di]
    2cff:	24 df                	and    al,0xdf
    2d01:	75 03                	jne    0x2d06
    2d03:	49                   	dec    cx
    2d04:	75 f2                	jne    0x2cf8
    2d06:	5e                   	pop    si
    2d07:	5f                   	pop    di
    2d08:	75 dc                	jne    0x2ce6
    2d0a:	58                   	pop    ax
    2d0b:	29 d0                	sub    ax,dx
    2d0d:	99                   	cwd
    2d0e:	1f                   	pop    ds
    2d0f:	c9                   	leave
    2d10:	ca 08 00             	retf   0x8
    2d13:	55                   	push   bp
    2d14:	89 e5                	mov    bp,sp
    2d16:	1e                   	push   ds
    2d17:	fc                   	cld
    2d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d1b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2d1e:	80 e4 df             	and    ah,0xdf
    2d21:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2d24:	8a 5c 01             	mov    bl,BYTE PTR [si+0x1]
    2d27:	b7 00                	mov    bh,0x0
    2d29:	8d 70 02             	lea    si,[bx+si+0x2]
    2d2c:	8a 5c 0a             	mov    bl,BYTE PTR [si+0xa]
    2d2f:	8b 50 0b             	mov    dx,WORD PTR [bx+si+0xb]
    2d32:	09 d2                	or     dx,dx
    2d34:	74 15                	je     0x2d4b
    2d36:	8d 78 0d             	lea    di,[bx+si+0xd]
    2d39:	8b 5d 18             	mov    bx,WORD PTR [di+0x18]
    2d3c:	80 e7 df             	and    bh,0xdf
    2d3f:	39 c3                	cmp    bx,ax
    2d41:	74 16                	je     0x2d59
    2d43:	b7 00                	mov    bh,0x0
    2d45:	8d 79 19             	lea    di,[bx+di+0x19]
    2d48:	4a                   	dec    dx
    2d49:	75 ee                	jne    0x2d39
    2d4b:	c5 74 04             	lds    si,DWORD PTR [si+0x4]
    2d4e:	8c d9                	mov    cx,ds
    2d50:	09 f1                	or     cx,si
    2d52:	75 d0                	jne    0x2d24
    2d54:	31 c0                	xor    ax,ax
    2d56:	99                   	cwd
    2d57:	eb 23                	jmp    0x2d7c
    2d59:	57                   	push   di
    2d5a:	56                   	push   si
    2d5b:	8d 75 18             	lea    si,[di+0x18]
    2d5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d61:	88 c1                	mov    cl,al
    2d63:	30 ed                	xor    ch,ch
    2d65:	46                   	inc    si
    2d66:	47                   	inc    di
    2d67:	8a 3c                	mov    bh,BYTE PTR [si]
    2d69:	26 32 3d             	xor    bh,BYTE PTR es:[di]
    2d6c:	80 e7 df             	and    bh,0xdf
    2d6f:	75 03                	jne    0x2d74
    2d71:	49                   	dec    cx
    2d72:	75 f1                	jne    0x2d65
    2d74:	5e                   	pop    si
    2d75:	5f                   	pop    di
    2d76:	75 cb                	jne    0x2d43
    2d78:	89 f8                	mov    ax,di
    2d7a:	8c da                	mov    dx,ds
    2d7c:	1f                   	pop    ds
    2d7d:	c9                   	leave
    2d7e:	ca 08 00             	retf   0x8
    2d81:	55                   	push   bp
    2d82:	89 e5                	mov    bp,sp
    2d84:	1e                   	push   ds
    2d85:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2d88:	8a 5c 01             	mov    bl,BYTE PTR [si+0x1]
    2d8b:	b7 00                	mov    bh,0x0
    2d8d:	8b 48 0a             	mov    cx,WORD PTR [bx+si+0xa]
    2d90:	d1 e1                	shl    cx,1
    2d92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d95:	31 c0                	xor    ax,ax
    2d97:	fc                   	cld
    2d98:	f3 ab                	rep stos WORD PTR es:[di],ax
    2d9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d9d:	8a 5c 01             	mov    bl,BYTE PTR [si+0x1]
    2da0:	b7 00                	mov    bh,0x0
    2da2:	8d 70 02             	lea    si,[bx+si+0x2]
    2da5:	ff 74 06             	push   WORD PTR [si+0x6]
    2da8:	ff 74 04             	push   WORD PTR [si+0x4]
    2dab:	8a 5c 0a             	mov    bl,BYTE PTR [si+0xa]
    2dae:	8b 50 0b             	mov    dx,WORD PTR [bx+si+0xb]
    2db1:	09 d2                	or     dx,dx
    2db3:	74 25                	je     0x2dda
    2db5:	8d 70 0d             	lea    si,[bx+si+0xd]
    2db8:	8b 5c 16             	mov    bx,WORD PTR [si+0x16]
    2dbb:	d1 e3                	shl    bx,1
    2dbd:	d1 e3                	shl    bx,1
    2dbf:	26 8b 01             	mov    ax,WORD PTR es:[bx+di]
    2dc2:	26 0b 41 02          	or     ax,WORD PTR es:[bx+di+0x2]
    2dc6:	75 07                	jne    0x2dcf
    2dc8:	26 89 31             	mov    WORD PTR es:[bx+di],si
    2dcb:	26 8c 59 02          	mov    WORD PTR es:[bx+di+0x2],ds
    2dcf:	8a 5c 18             	mov    bl,BYTE PTR [si+0x18]
    2dd2:	b7 00                	mov    bh,0x0
    2dd4:	8d 70 19             	lea    si,[bx+si+0x19]
    2dd7:	4a                   	dec    dx
    2dd8:	75 de                	jne    0x2db8
    2dda:	5e                   	pop    si
    2ddb:	1f                   	pop    ds
    2ddc:	8c d8                	mov    ax,ds
    2dde:	09 f0                	or     ax,si
    2de0:	75 bb                	jne    0x2d9d
    2de2:	1f                   	pop    ds
    2de3:	c9                   	leave
    2de4:	ca 08 00             	retf   0x8
    2de7:	55                   	push   bp
    2de8:	89 e5                	mov    bp,sp
    2dea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ded:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2df1:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2df5:	09 d2                	or     dx,dx
    2df7:	74 35                	je     0x2e2e
    2df9:	89 c3                	mov    bx,ax
    2dfb:	81 fa ff ff          	cmp    dx,0xffff
    2dff:	74 27                	je     0x2e28
    2e01:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2e05:	3d 00 80             	cmp    ax,0x8000
    2e08:	74 01                	je     0x2e0b
    2e0a:	50                   	push   ax
    2e0b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e0e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2e11:	81 fa fe ff          	cmp    dx,0xfffe
    2e15:	74 06                	je     0x2e1d
    2e17:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2e1b:	eb 11                	jmp    0x2e2e
    2e1d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e20:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e23:	26 ff 19             	call   DWORD PTR es:[bx+di]
    2e26:	eb 06                	jmp    0x2e2e
    2e28:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e2b:	26 8a 01             	mov    al,BYTE PTR es:[bx+di]
    2e2e:	c9                   	leave
    2e2f:	ca 08 00             	retf   0x8
    2e32:	55                   	push   bp
    2e33:	89 e5                	mov    bp,sp
    2e35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e3b:	b1 04                	mov    cl,0x4
    2e3d:	26 80 3d 07          	cmp    BYTE PTR es:[di],0x7
    2e41:	74 0a                	je     0x2e4d
    2e43:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    2e47:	b7 00                	mov    bh,0x0
    2e49:	26 8a 49 02          	mov    cl,BYTE PTR es:[bx+di+0x2]
    2e4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e50:	26 81 7d 06 ff ff    	cmp    WORD PTR es:[di+0x6],0xffff
    2e56:	74 30                	je     0x2e88
    2e58:	51                   	push   cx
    2e59:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2e5d:	3d 00 80             	cmp    ax,0x8000
    2e60:	74 01                	je     0x2e63
    2e62:	50                   	push   ax
    2e63:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e66:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2e69:	26 81 7d 06 fe ff    	cmp    WORD PTR es:[di+0x6],0xfffe
    2e6f:	74 07                	je     0x2e78
    2e71:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    2e75:	59                   	pop    cx
    2e76:	eb 2b                	jmp    0x2ea3
    2e78:	26 8b 5d 04          	mov    bx,WORD PTR es:[di+0x4]
    2e7c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e7f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e82:	26 ff 19             	call   DWORD PTR es:[bx+di]
    2e85:	59                   	pop    cx
    2e86:	eb 1b                	jmp    0x2ea3
    2e88:	26 8b 5d 04          	mov    bx,WORD PTR es:[di+0x4]
    2e8c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e8f:	26 8a 01             	mov    al,BYTE PTR es:[bx+di]
    2e92:	80 f9 02             	cmp    cl,0x2
    2e95:	72 0c                	jb     0x2ea3
    2e97:	26 8b 01             	mov    ax,WORD PTR es:[bx+di]
    2e9a:	80 f9 04             	cmp    cl,0x4
    2e9d:	72 04                	jb     0x2ea3
    2e9f:	26 8b 51 02          	mov    dx,WORD PTR es:[bx+di+0x2]
    2ea3:	80 f9 04             	cmp    cl,0x4
    2ea6:	73 16                	jae    0x2ebe
    2ea8:	80 f9 02             	cmp    cl,0x2
    2eab:	73 0c                	jae    0x2eb9
    2ead:	80 f9 00             	cmp    cl,0x0
    2eb0:	98                   	cbw
    2eb1:	99                   	cwd
    2eb2:	74 0a                	je     0x2ebe
    2eb4:	30 e4                	xor    ah,ah
    2eb6:	99                   	cwd
    2eb7:	eb 05                	jmp    0x2ebe
    2eb9:	99                   	cwd
    2eba:	74 02                	je     0x2ebe
    2ebc:	31 d2                	xor    dx,dx
    2ebe:	c9                   	leave
    2ebf:	ca 08 00             	retf   0x8
    2ec2:	55                   	push   bp
    2ec3:	89 e5                	mov    bp,sp
    2ec5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ec8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ecb:	b1 04                	mov    cl,0x4
    2ecd:	26 80 3d 07          	cmp    BYTE PTR es:[di],0x7
    2ed1:	74 0a                	je     0x2edd
    2ed3:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    2ed7:	b7 00                	mov    bh,0x0
    2ed9:	26 8a 49 02          	mov    cl,BYTE PTR es:[bx+di+0x2]
    2edd:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2ee0:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2ee3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ee6:	26 81 7d 0a ff ff    	cmp    WORD PTR es:[di+0xa],0xffff
    2eec:	74 35                	je     0x2f23
    2eee:	26 8b 5d 10          	mov    bx,WORD PTR es:[di+0x10]
    2ef2:	81 fb 00 80          	cmp    bx,0x8000
    2ef6:	74 01                	je     0x2ef9
    2ef8:	53                   	push   bx
    2ef9:	80 f9 04             	cmp    cl,0x4
    2efc:	72 01                	jb     0x2eff
    2efe:	52                   	push   dx
    2eff:	50                   	push   ax
    2f00:	ff 76 10             	push   WORD PTR [bp+0x10]
    2f03:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2f06:	26 81 7d 0a fe ff    	cmp    WORD PTR es:[di+0xa],0xfffe
    2f0c:	74 06                	je     0x2f14
    2f0e:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2f12:	eb 2a                	jmp    0x2f3e
    2f14:	26 8b 5d 08          	mov    bx,WORD PTR es:[di+0x8]
    2f18:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2f1b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f1e:	26 ff 19             	call   DWORD PTR es:[bx+di]
    2f21:	eb 1b                	jmp    0x2f3e
    2f23:	26 8b 5d 08          	mov    bx,WORD PTR es:[di+0x8]
    2f27:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2f2a:	26 88 01             	mov    BYTE PTR es:[bx+di],al
    2f2d:	80 f9 02             	cmp    cl,0x2
    2f30:	72 0c                	jb     0x2f3e
    2f32:	26 89 01             	mov    WORD PTR es:[bx+di],ax
    2f35:	80 f9 04             	cmp    cl,0x4
    2f38:	72 04                	jb     0x2f3e
    2f3a:	26 89 51 02          	mov    WORD PTR es:[bx+di+0x2],dx
    2f3e:	c9                   	leave
    2f3f:	ca 0c 00             	retf   0xc
    2f42:	55                   	push   bp
    2f43:	89 e5                	mov    bp,sp
    2f45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f48:	26 81 7d 06 ff ff    	cmp    WORD PTR es:[di+0x6],0xffff
    2f4e:	74 33                	je     0x2f83
    2f50:	ff 76 10             	push   WORD PTR [bp+0x10]
    2f53:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2f56:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2f5a:	3d 00 80             	cmp    ax,0x8000
    2f5d:	74 01                	je     0x2f60
    2f5f:	50                   	push   ax
    2f60:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f63:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2f66:	26 81 7d 06 fe ff    	cmp    WORD PTR es:[di+0x6],0xfffe
    2f6c:	74 06                	je     0x2f74
    2f6e:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    2f72:	eb 24                	jmp    0x2f98
    2f74:	26 8b 5d 04          	mov    bx,WORD PTR es:[di+0x4]
    2f78:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f7e:	26 ff 19             	call   DWORD PTR es:[bx+di]
    2f81:	eb 15                	jmp    0x2f98
    2f83:	1e                   	push   ds
    2f84:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2f87:	26 03 75 04          	add    si,WORD PTR es:[di+0x4]
    2f8b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2f8e:	fc                   	cld
    2f8f:	ac                   	lods   al,BYTE PTR ds:[si]
    2f90:	aa                   	stos   BYTE PTR es:[di],al
    2f91:	88 c1                	mov    cl,al
    2f93:	30 ed                	xor    ch,ch
    2f95:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2f97:	1f                   	pop    ds
    2f98:	c9                   	leave
    2f99:	ca 08 00             	retf   0x8
    2f9c:	55                   	push   bp
    2f9d:	89 e5                	mov    bp,sp
    2f9f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fa2:	26 81 7d 0a ff ff    	cmp    WORD PTR es:[di+0xa],0xffff
    2fa8:	74 33                	je     0x2fdd
    2faa:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2fae:	3d 00 80             	cmp    ax,0x8000
    2fb1:	74 01                	je     0x2fb4
    2fb3:	50                   	push   ax
    2fb4:	ff 76 08             	push   WORD PTR [bp+0x8]
    2fb7:	ff 76 06             	push   WORD PTR [bp+0x6]
    2fba:	ff 76 10             	push   WORD PTR [bp+0x10]
    2fbd:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2fc0:	26 81 7d 0a fe ff    	cmp    WORD PTR es:[di+0xa],0xfffe
    2fc6:	74 06                	je     0x2fce
    2fc8:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2fcc:	eb 39                	jmp    0x3007
    2fce:	26 8b 5d 08          	mov    bx,WORD PTR es:[di+0x8]
    2fd2:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2fd5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2fd8:	26 ff 19             	call   DWORD PTR es:[bx+di]
    2fdb:	eb 2a                	jmp    0x3007
    2fdd:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2fe1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2fe4:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    2fe8:	b7 00                	mov    bh,0x0
    2fea:	26 8a 49 02          	mov    cl,BYTE PTR es:[bx+di+0x2]
    2fee:	1e                   	push   ds
    2fef:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    2ff2:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2ff5:	01 c7                	add    di,ax
    2ff7:	fc                   	cld
    2ff8:	ac                   	lods   al,BYTE PTR ds:[si]
    2ff9:	38 c8                	cmp    al,cl
    2ffb:	72 02                	jb     0x2fff
    2ffd:	88 c8                	mov    al,cl
    2fff:	aa                   	stos   BYTE PTR es:[di],al
    3000:	88 c1                	mov    cl,al
    3002:	30 ed                	xor    ch,ch
    3004:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    3006:	1f                   	pop    ds
    3007:	c9                   	leave
    3008:	ca 0c 00             	retf   0xc
    300b:	55                   	push   bp
    300c:	89 e5                	mov    bp,sp
    300e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3011:	26 81 7d 06 ff ff    	cmp    WORD PTR es:[di+0x6],0xffff
    3017:	74 49                	je     0x3062
    3019:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    301d:	3d 00 80             	cmp    ax,0x8000
    3020:	74 01                	je     0x3023
    3022:	50                   	push   ax
    3023:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3026:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3029:	26 81 7d 06 fe ff    	cmp    WORD PTR es:[di+0x6],0xfffe
    302f:	74 06                	je     0x3037
    3031:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3035:	eb 48                	jmp    0x307f
    3037:	26 8b 5d 04          	mov    bx,WORD PTR es:[di+0x4]
    303b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    303e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3041:	26 ff 19             	call   DWORD PTR es:[bx+di]
    3044:	eb 39                	jmp    0x307f
    3046:	4e                   	dec    si
    3047:	30 53 30             	xor    BYTE PTR [bp+di+0x30],dl
    304a:	58                   	pop    ax
    304b:	30 5d 30             	xor    BYTE PTR [di+0x30],bl
    304e:	9b 26 d9 05          	fld    DWORD PTR es:[di]
    3052:	c3                   	ret
    3053:	9b 26 dd 05          	fld    QWORD PTR es:[di]
    3057:	c3                   	ret
    3058:	9b 26 db 2d          	fld    TBYTE PTR es:[di]
    305c:	c3                   	ret
    305d:	9b 26 df 2d          	fild   QWORD PTR es:[di]
    3061:	c3                   	ret
    3062:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3066:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3069:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    306d:	b7 00                	mov    bh,0x0
    306f:	26 8a 59 02          	mov    bl,BYTE PTR es:[bx+di+0x2]
    3073:	d1 e3                	shl    bx,1
    3075:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3078:	01 c7                	add    di,ax
    307a:	2e ff 97 46 30       	call   WORD PTR cs:[bx+0x3046]
    307f:	c9                   	leave
    3080:	ca 08 00             	retf   0x8
    3083:	55                   	push   bp
    3084:	89 e5                	mov    bp,sp
    3086:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    3089:	26 c4 3d             	les    di,DWORD PTR es:[di]
    308c:	26 8a 5d 01          	mov    bl,BYTE PTR es:[di+0x1]
    3090:	b7 00                	mov    bh,0x0
    3092:	26 8a 59 02          	mov    bl,BYTE PTR es:[bx+di+0x2]
    3096:	d1 e3                	shl    bx,1
    3098:	9b db 6e 06          	fld    TBYTE PTR [bp+0x6]
    309c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    309f:	26 81 7d 0a ff ff    	cmp    WORD PTR es:[di+0xa],0xffff
    30a5:	74 62                	je     0x3109
    30a7:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    30ab:	3d 00 80             	cmp    ax,0x8000
    30ae:	74 01                	je     0x30b1
    30b0:	50                   	push   ax
    30b1:	2e 2b a7 e5 30       	sub    sp,WORD PTR cs:[bx+0x30e5]
    30b6:	89 e7                	mov    di,sp
    30b8:	16                   	push   ss
    30b9:	07                   	pop    es
    30ba:	2e ff 97 ed 30       	call   WORD PTR cs:[bx+0x30ed]
    30bf:	ff 76 16             	push   WORD PTR [bp+0x16]
    30c2:	ff 76 14             	push   WORD PTR [bp+0x14]
    30c5:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    30c8:	26 81 7d 0a fe ff    	cmp    WORD PTR es:[di+0xa],0xfffe
    30ce:	74 06                	je     0x30d6
    30d0:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    30d4:	eb 41                	jmp    0x3117
    30d6:	26 8b 5d 08          	mov    bx,WORD PTR es:[di+0x8]
    30da:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    30dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30e0:	26 ff 19             	call   DWORD PTR es:[bx+di]
    30e3:	eb 32                	jmp    0x3117
    30e5:	04 00                	add    al,0x0
    30e7:	08 00                	or     BYTE PTR [bx+si],al
    30e9:	0a 00                	or     al,BYTE PTR [bx+si]
    30eb:	08 00                	or     BYTE PTR [bx+si],al
    30ed:	f5                   	cmc
    30ee:	30 fa                	xor    dl,bh
    30f0:	30 ff                	xor    bh,bh
    30f2:	30 04                	xor    BYTE PTR [si],al
    30f4:	31 9b 26 d9          	xor    WORD PTR [bp+di-0x26da],bx
    30f8:	1d c3 9b             	sbb    ax,0x9bc3
    30fb:	26 dd 1d             	fstp   QWORD PTR es:[di]
    30fe:	c3                   	ret
    30ff:	9b 26 db 3d          	fstp   TBYTE PTR es:[di]
    3103:	c3                   	ret
    3104:	9b 26 df 3d          	fistp  QWORD PTR es:[di]
    3108:	c3                   	ret
    3109:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    310d:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    3110:	01 c7                	add    di,ax
    3112:	2e ff 97 ed 30       	call   WORD PTR cs:[bx+0x30ed]
    3117:	c9                   	leave
    3118:	ca 12 00             	retf   0x12
    311b:	55                   	push   bp
    311c:	89 e5                	mov    bp,sp
    311e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3121:	26 81 7d 06 ff ff    	cmp    WORD PTR es:[di+0x6],0xffff
    3127:	74 2d                	je     0x3156
    3129:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    312d:	3d 00 80             	cmp    ax,0x8000
    3130:	74 01                	je     0x3133
    3132:	50                   	push   ax
    3133:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3136:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3139:	26 81 7d 06 fe ff    	cmp    WORD PTR es:[di+0x6],0xfffe
    313f:	74 06                	je     0x3147
    3141:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3145:	eb 25                	jmp    0x316c
    3147:	26 8b 5d 04          	mov    bx,WORD PTR es:[di+0x4]
    314b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    314e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3151:	26 ff 19             	call   DWORD PTR es:[bx+di]
    3154:	eb 16                	jmp    0x316c
    3156:	26 8b 5d 04          	mov    bx,WORD PTR es:[di+0x4]
    315a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    315d:	26 8b 01             	mov    ax,WORD PTR es:[bx+di]
    3160:	26 8b 51 02          	mov    dx,WORD PTR es:[bx+di+0x2]
    3164:	26 8b 49 04          	mov    cx,WORD PTR es:[bx+di+0x4]
    3168:	26 8b 59 06          	mov    bx,WORD PTR es:[bx+di+0x6]
    316c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    316f:	fc                   	cld
    3170:	ab                   	stos   WORD PTR es:[di],ax
    3171:	92                   	xchg   dx,ax
    3172:	ab                   	stos   WORD PTR es:[di],ax
    3173:	91                   	xchg   cx,ax
    3174:	ab                   	stos   WORD PTR es:[di],ax
    3175:	93                   	xchg   bx,ax
    3176:	ab                   	stos   WORD PTR es:[di],ax
    3177:	c9                   	leave
    3178:	ca 08 00             	retf   0x8
    317b:	55                   	push   bp
    317c:	89 e5                	mov    bp,sp
    317e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3181:	26 81 7d 0a ff ff    	cmp    WORD PTR es:[di+0xa],0xffff
    3187:	74 42                	je     0x31cb
    3189:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    318d:	3d 00 80             	cmp    ax,0x8000
    3190:	74 01                	je     0x3193
    3192:	50                   	push   ax
    3193:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3196:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    319a:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    319e:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    31a2:	26 ff 35             	push   WORD PTR es:[di]
    31a5:	ff 76 10             	push   WORD PTR [bp+0x10]
    31a8:	ff 76 0e             	push   WORD PTR [bp+0xe]
    31ab:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31ae:	26 81 7d 0a fe ff    	cmp    WORD PTR es:[di+0xa],0xfffe
    31b4:	74 06                	je     0x31bc
    31b6:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    31ba:	eb 22                	jmp    0x31de
    31bc:	26 8b 5d 08          	mov    bx,WORD PTR es:[di+0x8]
    31c0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    31c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31c6:	26 ff 19             	call   DWORD PTR es:[bx+di]
    31c9:	eb 13                	jmp    0x31de
    31cb:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    31cf:	1e                   	push   ds
    31d0:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    31d3:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    31d6:	01 c7                	add    di,ax
    31d8:	fc                   	cld
    31d9:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    31da:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    31db:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    31dc:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    31dd:	1f                   	pop    ds
    31de:	c9                   	leave
    31df:	ca                   	.byte 0xca
    31e0:	0c                   	.byte 0xc
